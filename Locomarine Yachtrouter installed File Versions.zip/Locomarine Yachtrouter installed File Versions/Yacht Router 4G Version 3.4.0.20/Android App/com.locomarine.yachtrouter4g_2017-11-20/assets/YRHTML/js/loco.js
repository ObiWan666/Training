﻿$.extend({ getUrlVars: function () { var vars = [], hash; var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&'); for (var i = 0; i < hashes.length; i++) { hash = hashes[i].split('='); vars.push(hash[0]); vars[hash[0]] = hash[1]; } return vars; }, getUrlVar: function (name) { return $.getUrlVars()[name]; } });

var wanNetworksModel = Backbone.Model.extend({
    defaults: {
        name: "&nbsp;",
        selectedWan: "&nbsp;",
        internetAvailable: "checking",
        vesselNetworkHtmlID: "",
        available: false,
        lanWans: [
                            { title: "&nbsp;", action: "http://yachtrouter/#1081_etherWan1", usage: "", connection: "" },
                            { title: "&nbsp;", action: "http://yachtrouter/#1081_wanWIFI", usage: "", connection: "" },
        //                            { title: "peto", action: "http://yachtrouter/#1081_wan3", usage : "", connection : "" }
                ],
        mobileWans: [
                            { title: "&nbsp;", action: "http://yachtrouter/#1081_wan1", usage: "", connection: "" },
        //                            { title: "vip", action: "http://yachtrouter/#1081_wan2", usage : "", connection : "" },
        //                            { title: "bonded", action: "http://yachtrouter/#1081_wan3", usage : "", connection : "" }
                ],
        wifiWans: [
                            { title: "&nbsp;", action: "http://yachtrouter/#1081_wan1", usage: "", connection: "" }
                ]
    }
});

var diagnosticsScreenVesselNetworkModel = Backbone.Model.extend({
    defaults: {
        vesselNetworkHtmlID: "",
        selectedWan: "&nbsp;",
        name: "&nbsp;",
        selectedWanInternetAvailable: "checking",

        vesselNetworkBandwithControlLimitEnabled: "false",
        vesselNetworkBandwithControlLimit_RX: "-",
        vesselNetworkBandwithControlLimit_TX: "-",

        selectedWanBandwith_RX: "-",
        selectedWanBandwith_TX: "-",

        selectedWanUsage_RX: "-",
        selectedWanUsage_TX: "-",
        selectedWanUsageLimit: "-",
        selectedWanUsageLimitEnabled: "false",
        selectedWanUsageWarning: "-",
        selectedWanUsageWarningEnabled: "false",

        vesselNetworkWifiEnabled: "true",
        vesselNetworkWifiUsers: "-",

        vesselNetworkAutoswitchEnabled: "false",
        vesselNetworkAutoswitchScript: "-",
        vesselNetworkHotspotEnabled: "false",
        vesselNetworkHotspotUsersActive: "-",
        vesselNetworkHotspotUsersRegistered: "-"
    }
});

var SetupScreenModel = Backbone.Model.extend({
    defaults: {
        title: "pero",
        password: "",
        wifiPower: "",
        wifiPowerVN: "",
        wifiextenders: [
        //                            { serial: "23344324", ip: "", wifiEnabled: "True" },
        //                            { serial: "42434424", ip: "", wifiEnabled: "True" },
        //                            {serial: "Locating...", ip: "", wifiEnabled: "True" }
                        ],
        portForwards: [
        //                        { comment: "Port Forward 1",
        //                            cloudPort: "1001",
        //                            deviceIP: '10.81.250.200',
        //                            devicePort: '80',
        //                            wans: [
        //                                        { title: "Cloud SAT1", interface: "vpn_etherWAN1", enabled: 'True' },
        //                                  ]
        //                        }
                      ]
    }
});

var VesselNetworksModel = Backbone.Model.extend({
    defaults: {
        title: "pero",
        vesselNetworks: [
                            { name: "&nbsp;", vn: "1" },
                            { name: "&nbsp;", vn: "2" },
                            { name: "&nbsp;", vn: "3" }
                        ]
    }
});

var LockScreenModel = Backbone.Model.extend({
    defaults: {
        title: "",
        defaultPassword: "locomarinefactory",
        lockPassword: "",
        routerConnected: "False"
    }
});

var VesselNetworkModel = Backbone.Model.extend({
    defaults: {
        name: "",
        interfaceName: "interface name",
        wifi_enabled: "true",
        wifi_ssid: "",
        wifi_password: "",
        internetAvailable: "checking",
        lanCableWarning: "false",

        bandwithTXLimit: 0,
        bandwithRXLimit: 0,
        bandwithTXEnabled: 'false',
        bandwithRXEnabled: 'false',
        bandwithScale: "k",
        bandwithControlAvailable: "",

        hotspot_available: "false",
        hotspot_enabled: "disabled",

        hotspotUsers: [
            { name: "name 1", password: "password 1", timeUsed: "time used", timeLimit: "time limit", dataUsed: "data used", dataLimit: "data limit" },
            { name: "name 2", password: "password 2", timeUsed: "time used", timeLimit: "time limit", dataUsed: "data used", dataLimit: "data limit" },
            { name: "name 3", password: "password 3", timeUsed: "time used", timeLimit: "time limit", dataUsed: "data used", dataLimit: "data limit" }
        ],

        dhcpClients: [
        //                            { mac: "JDHSJDS", ip: "10.1.1.2", host: 'jere laptop', static: 'False' },
        //                            { mac: "JDHSJDS1", ip: "10.1.1.3", host: 'jere laptop 1', static: 'False' },
        //                            { mac: "JDHSJDS2", ip: "10.1.1.4", host: 'jere laptop 2', static: 'true' }

                     ],
        autoswtichingAvailable: "false",
        autoswtichingEnabled: "disabled",
        isolationAvailable: "false",
        isolationEnabled: "disabled",
        autoswtichingSelectedScript: "AllWans",
        autoswitchingScript: [
        //{ name: "AllWans" }, { name: "NoWifi" } 
                             ]
    }
});

var wanInterfaceConfigModel = Backbone.Model.extend({
    defaults: {
        name: "",
        interfaceName: "None",
        enabled: 'enabled',

        dhcp_enabled: false,
        ip: "",
        subnet: "",
        gateway: "",
        dns1: "",
        dns2: "",
        dhcpChecking: "False",

        wanwifinetworkssid: "",
        wanwifinetworkpassword: "",
        wanwifinetworkusewep: "False",
        wanwifiselectbandavailable: "False",
        wanwifiselectedband: "24",
        wanwifiwephidden: "True",

        wanUsage_RX: "0",
        wanUsage_TX: "0",
        wanUsageLimit: "0",
        wanUsageLimitEnabled: "false",
        wanUsageWarning: "0",
        wanUsageWarningEnabled: "false",
        wanUsageAutoresetEnabled: "false",
        wanUsageLastReset: "-",
        wanUsageScale: "g",
        wanUsageAvailable: "",

        cloudAvailable: "False",
        cloudEnabled: "enabled",
        cloudConnected: "",
        cloudTitle: "",

        showWifiScan: 'False',
        showMobileConfig: 'False',
        showDhcpConfig: 'False',

        apn: "apn",
        pin: "pin",
        user: "user",
        password: "password",
        phone: "phone",
        modeminit: "modeminit",
        keepalive: "true",
        networkMode: "auto",
        reloadsimavailable: "false",

        apn_list: [
{ countryoperator: "", apn: "", username: "", password: "" },
{ countryoperator: "AD - Andorra Telecom", apn: "internetand", username: "", password: "" },
{ countryoperator: "AD - STA", apn: "internet", username: "", password: "" },
{ countryoperator: "AE - Du", apn: "du", username: "du", password: "du" },
{ countryoperator: "AE - Etisalat", apn: "Etisalat.ae", username: "", password: "" },
{ countryoperator: "AF - AWCC", apn: "internet", username: "awcc", password: "1111" },
{ countryoperator: "AF - Etisalat", apn: "etisalat.af.web", username: "", password: "" },
{ countryoperator: "AF - MTN", apn: "internet.mtn.com.af", username: "", password: "" },
{ countryoperator: "AF - Roshan", apn: "internet", username: "", password: "" },
{ countryoperator: "AF - Salaam", apn: "salaam", username: "salaam", password: "salaam" },
{ countryoperator: "AG - Digicel", apn: "web", username: "", password: "" },
{ countryoperator: "AG - Lime", apn: "ppinternet", username: "", password: "" },
{ countryoperator: "AL - AMC", apn: "internet.amc", username: "", password: "" },
{ countryoperator: "AL - Eagle Mobile", apn: "internet", username: "", password: "" },
{ countryoperator: "AL - Plus", apn: "Plusweb", username: "", password: "" },
{ countryoperator: "AL - Vodafone", apn: "vodafoneweb", username: "", password: "" },
{ countryoperator: "AM - Beeline", apn: "internet.beeline.am", username: "internet", password: "internet" },
{ countryoperator: "AM - Orange (internet)", apn: "internet", username: "", password: "" },
{ countryoperator: "AM - Orange (Internet.orange)", apn: "Internet.orange", username: "", password: "" },
{ countryoperator: "AM - VivaCell", apn: "inet.vivacell.am", username: "", password: "" },
{ countryoperator: "AN - Chippoe", apn: "utsnet.uts.an", username: "netuser", password: "net123" },
{ countryoperator: "AN - Digicel", apn: "web.digicelcuracao.com", username: "", password: "" },
{ countryoperator: "AN - Telcell", apn: "internet.telcell.an", username: "TelCell", password: "0000" },
{ countryoperator: "AN - UTS", apn: "utsnet.uts.an", username: "", password: "" },
{ countryoperator: "AO - Movicel", apn: "internet.movicel.co.ao", username: "", password: "" },
{ countryoperator: "AO - Unitel", apn: "internet.unitel.co.ao", username: "", password: "" },
{ countryoperator: "AR - Claro", apn: "igprs.claro.com.ar", username: "clarogprs", password: "clarogprs999" },
{ countryoperator: "AR - CTI", apn: "internet.ctimovil.com.ar", username: "ctigprs", password: "ctigprs999" },
{ countryoperator: "AR - Movistar (grps.uniform.com.ar)", apn: "grps.uniform.com.ar", username: "wap", password: "wap" },
{ countryoperator: "AR - Movistar (internet.gprs.unifon.com.ar)", apn: "internet.gprs.unifon.com.ar", username: "internet", password: "internet" },
{ countryoperator: "AR - Movistar (internet.unifon)", apn: "internet.unifon", username: "wap", password: "wap" },
{ countryoperator: "AR - Movistar (wap.gprs.unifon.com.ar)", apn: "wap.gprs.unifon.com.ar", username: "wap", password: "wap" },
{ countryoperator: "AR - Personal (datos.personal.com)", apn: "datos.personal.com", username: "datos", password: "datos" },
{ countryoperator: "AR - Personal (gprs.personal.com)", apn: "gprs.personal.com", username: "gprs", password: "gprs" },
{ countryoperator: "AS - Blue Sky", apn: "internet", username: "", password: "" },
{ countryoperator: "AT - 3", apn: "drei.at", username: "", password: "" },
{ countryoperator: "AT - A1", apn: "A1.net", username: "ppp@a1plus.at", password: "ppp" },
{ countryoperator: "AT - AON", apn: "aon.at", username: "mobile@aon.at", password: "ppp" },
{ countryoperator: "AT - BOB", apn: "bob.at", username: "data@bob.at", password: "ppp" },
{ countryoperator: "AT - One", apn: "web.one.at", username: "web", password: "web" },
{ countryoperator: "AT - Orange (Fullspeed)", apn: "fullspeed", username: "", password: "" },
{ countryoperator: "AT - Orange (Smartphone)", apn: "orange.smartphone", username: "", password: "" },
{ countryoperator: "AT - Orange (Web)", apn: "orange.web", username: "web", password: "web" },
{ countryoperator: "AT - T-Mobile (Business)", apn: "business.gprsinternet", username: "", password: "" },
{ countryoperator: "AT - T-Mobile (Residential)", apn: "gprsinternet", username: "GPRS", password: "leer" },
{ countryoperator: "AT - Tele.Ring", apn: "web", username: "web@telering.at", password: "web" },
{ countryoperator: "AT - Vectone", apn: "mobile.barablu.com", username: "", password: "" },
{ countryoperator: "AT - VOLmobil", apn: "volmobil", username: "", password: "" },
{ countryoperator: "AT - Yesss", apn: "web.yesss.at", username: "", password: "" },
{ countryoperator: "AU - Adam", apn: "splns444A1", username: "", password: "" },
{ countryoperator: "AU - Aldi Mobile", apn: "mdata.net.au", username: "", password: "" },
{ countryoperator: "AU - Amaysim", apn: "internet", username: "", password: "" },
{ countryoperator: "AU - Apex Telecom", apn: "internet", username: "", password: "" },
{ countryoperator: "AU - AussieSIM", apn: "mobiledata", username: "", password: "" },
{ countryoperator: "AU - Beagle Internet", apn: "splns357", username: "", password: "" },
{ countryoperator: "AU - Bigpond", apn: "telstra.bigpond", username: "Yes", password: "Yes" },
{ countryoperator: "AU - BLiNK (NEW)", apn: "connect", username: "", password: "" },
{ countryoperator: "AU - BLiNK (OLD)", apn: "splns888a1", username: "", password: "" },
{ countryoperator: "AU - Crazy Johns", apn: "purtona.net", username: "", password: "" },
{ countryoperator: "AU - DoDo", apn: "dodolns1", username: "", password: "" },
{ countryoperator: "AU - Exetel", apn: "exetel1", username: "", password: "" },
{ countryoperator: "AU - Exetel (Optus)", apn: "YESINTERNET", username: "", password: "" },
{ countryoperator: "AU - Global Gossip", apn: "purtona.net", username: "", password: "" },
{ countryoperator: "AU - GlobalGig", apn: "mbb.voiamo.net", username: "", password: "" },
{ countryoperator: "AU - Gotalk", apn: "purtona.net", username: "", password: "" },
{ countryoperator: "AU - Highway1", apn: "splns357", username: "", password: "" },
{ countryoperator: "AU - iinet", apn: "internet", username: "", password: "" },
{ countryoperator: "AU - iinet (iiNet 3G)", apn: "iinet", username: "", password: "" },
{ countryoperator: "AU - iinet (iiNet 4G)", apn: "connect", username: "", password: "" },
{ countryoperator: "AU - iinet (Internode)", apn: "internode", username: "", password: "" },
{ countryoperator: "AU - iinet (Mobile Voice)", apn: "internet", username: "", password: "" },
{ countryoperator: "AU - iinet (TransACT)", apn: "vfinternet.au", username: "", password: "" },
{ countryoperator: "AU - iinet (Westnet 3G)", apn: "555a1", username: "", password: "" },
{ countryoperator: "AU - iinet (Westnet 4G)", apn: "connect", username: "", password: "" },
{ countryoperator: "AU - iinet (Westnet Mobile Voice)", apn: "internet", username: "", password: "" },
{ countryoperator: "AU - Internode", apn: "internode", username: "", password: "" },
{ countryoperator: "AU - Kiss Mobile", apn: "vfinternet.au", username: "", password: "" },
{ countryoperator: "AU - Kogan Mobile", apn: "mdata.net.au", username: "", password: "" },
{ countryoperator: "AU - Lebara", apn: "purtona.net", username: "", password: "" },
{ countryoperator: "AU - Live Connected", apn: "yesinternet", username: "", password: "" },
{ countryoperator: "AU - Lycamobile", apn: "data.lycamobile.com.au", username: "", password: "" },
{ countryoperator: "AU - Optus", apn: "internet", username: "", password: "" },
{ countryoperator: "AU - Optus (Business)", apn: "yesbusiness", username: "", password: "" },
{ countryoperator: "AU - Optus (connect)", apn: "connect", username: "", password: "" },
{ countryoperator: "AU - Optus (CONNECTME)", apn: "CONNECTME", username: "", password: "" },
{ countryoperator: "AU - Optus (Prepaid)", apn: "preconnect", username: "", password: "" },
{ countryoperator: "AU - PennyTel", apn: "vfinternet.au", username: "", password: "" },
{ countryoperator: "AU - Primus", apn: "primuslns1", username: "", password: "" },
{ countryoperator: "AU - Red Bull (Postpaid)", apn: "live.vodafone.com", username: "", password: "" },
{ countryoperator: "AU - Red Bull (Prepaid)", apn: "purtona.wap", username: "", password: "" },
{ countryoperator: "AU - RoamingSIM", apn: "speedidata", username: "speedidata", password: "speedidata" },
{ countryoperator: "AU - Telstra", apn: "telstra.internet", username: "", password: "" },
{ countryoperator: "AU - Telstra (telstra.extranet)", apn: "telstra.extranet", username: "", password: "" },
{ countryoperator: "AU - Three", apn: "3netaccess", username: "a", password: "a" },
{ countryoperator: "AU - TPG (internet)", apn: "internet", username: "", password: "" },
{ countryoperator: "AU - TPG (TPG)", apn: "TPG", username: "", password: "" },
{ countryoperator: "AU - Transact", apn: "vfinternet.au", username: "", password: "" },
{ countryoperator: "AU - TravelSim", apn: "send.ee", username: "", password: "" },
{ countryoperator: "AU - Truphone", apn: "truphone.com", username: "", password: "" },
{ countryoperator: "AU - Vaya (Data Only)", apn: "connect", username: "", password: "" },
{ countryoperator: "AU - Vaya (Voice/Data)", apn: "internet", username: "", password: "" },
{ countryoperator: "AU - Virgin (VirginBroadband)", apn: "VirginBroadband", username: "", password: "" },
{ countryoperator: "AU - Virgin (VirginInternet)", apn: "VirginInternet", username: "", password: "" },
{ countryoperator: "AU - Vodafone", apn: "vfinternet.au", username: "", password: "" },
{ countryoperator: "AU - Vodafone (iPad)", apn: "vfprepaymbb", username: "", password: "" },
{ countryoperator: "AU - Vodafone (live.vodafone.com)", apn: "live.vodafone.com", username: "", password: "" },
{ countryoperator: "AU - Westnet", apn: "splns555a1", username: "", password: "" },
{ countryoperator: "AU - Woolworths", apn: "internet", username: "", password: "" },
{ countryoperator: "AU - Yatango", apn: "YESINTERNET", username: "", password: "" },
{ countryoperator: "AU - Yes Internet", apn: "yesinternet", username: "", password: "" },
{ countryoperator: "AW - Setar", apn: "internet.setar.aw", username: "", password: "" },
{ countryoperator: "AZ - Azercell", apn: "internet", username: "", password: "" },
{ countryoperator: "AZ - Bakcell", apn: "gprs", username: "", password: "" },
{ countryoperator: "AZ - Nar Mobile", apn: "azerfon", username: "azerfon", password: "azerfon" },
{ countryoperator: "BA - BHMobile", apn: "active.bhmobile.ba", username: "", password: "" },
{ countryoperator: "BA - Eronet (Postpaid)", apn: "web.eronet.ba", username: "", password: "" },
{ countryoperator: "BA - Eronet (Prepaid)", apn: "gprs.eronet.ba", username: "", password: "" },
{ countryoperator: "BA - MTel (New)", apn: "Mtelsmart", username: "", password: "" },
{ countryoperator: "BA - MTel (Old)", apn: "mtelfriend", username: "", password: "" },
{ countryoperator: "BB - Digicel", apn: "web.digicelbarbados.com", username: "", password: "" },
{ countryoperator: "BD - Airtel", apn: "Internet", username: "", password: "" },
{ countryoperator: "BD - Banglalink", apn: "blweb", username: "", password: "" },
{ countryoperator: "BD - Grameenphone", apn: "gpinternet", username: "", password: "" },
{ countryoperator: "BE - Base", apn: "gprs.base.be", username: "base", password: "base" },
{ countryoperator: "BE - Dommel", apn: "Internet.bmbpartner.be", username: "", password: "" },
{ countryoperator: "BE - edpnet", apn: "web.be", username: "web", password: "web" },
{ countryoperator: "BE - Mobile Vikings", apn: "web.be", username: "web", password: "web" },
{ countryoperator: "BE - Mobistar", apn: "mworld.be", username: "", password: "" },
{ countryoperator: "BE - Ortel Mobile", apn: "web.be", username: "web", password: "web" },
{ countryoperator: "BE - Proximus", apn: "internet.proximus.be", username: "", password: "" },
{ countryoperator: "BE - Telenet", apn: "telenetwap.be", username: "", password: "" },
{ countryoperator: "BE - Tellink", apn: "mobinternet.be", username: "", password: "" },
{ countryoperator: "BG - GloBul", apn: "globul", username: "globul", password: "" },
{ countryoperator: "BG - Globul (OLD)", apn: "internet.globul.bg", username: "globul", password: "" },
{ countryoperator: "BG - MTEL", apn: "inet-gprs.mtel.bg", username: "", password: "" },
{ countryoperator: "BG - Vivacom", apn: "internet.vivacom.bg", username: "VIVACOM", password: "VIVACOM" },
{ countryoperator: "BG - Vivatel", apn: "internet.vivatel.bg", username: "vivatel", password: "vivatel" },
{ countryoperator: "BH - Batelco", apn: "internet.batelco.com", username: "", password: "" },
{ countryoperator: "BH - Viva", apn: "viva.bh", username: "", password: "" },
{ countryoperator: "BH - Zain", apn: "internet", username: "internet", password: "internet" },
{ countryoperator: "BI - Econet Wireless", apn: "mobile.econet.bi", username: "", password: "" },
{ countryoperator: "BI - Leo", apn: "ucnet", username: "", password: "" },
{ countryoperator: "BI - Tempo", apn: "internet", username: "", password: "" },
{ countryoperator: "BJ - Moov", apn: "moov", username: "", password: "" },
{ countryoperator: "BJ - MTN", apn: "internet.mtn.bj", username: "", password: "" },
{ countryoperator: "BM - CellOne", apn: "web.c1.bm", username: "", password: "" },
{ countryoperator: "BM - Digicel", apn: "web.digicelbermuda.com", username: "", password: "" },
{ countryoperator: "BN - BMobile", apn: "bmobilewap", username: "", password: "" },
{ countryoperator: "BN - DSTcom", apn: "dst.internet", username: "dst.internet", password: "internet" },
{ countryoperator: "BO - Movil", apn: "4g.entel", username: "", password: "" },
{ countryoperator: "BO - Nuevatel", apn: "internet.nuevatel.com", username: "", password: "" },
{ countryoperator: "BO - TIGO", apn: "internet.tigo.bo", username: "", password: "" },
{ countryoperator: "BR - Claro", apn: "claro.com.br", username: "claro", password: "claro" },
{ countryoperator: "BR - Claro (java.claro.com.br)", apn: "java.claro.com.br", username: "", password: "" },
{ countryoperator: "BR - Nextel 3G", apn: "datacard.nextel3g.net.br", username: "", password: "" },
{ countryoperator: "BR - Oi", apn: "gprs.oi.com.br", username: "oi", password: "oi" },
{ countryoperator: "BR - Telecom", apn: "brt.br", username: "brt", password: "brt" },
{ countryoperator: "BR - Telemig", apn: "gprs.telemigcelular.com.br", username: "celular", password: "celular" },
{ countryoperator: "BR - TIM", apn: "tim.br", username: "tim", password: "tim" },
{ countryoperator: "BR - VIVO", apn: "zap.vivo.com.br", username: "vivo", password: "vivo" },
{ countryoperator: "BR - VIVO (Play)", apn: "play.vivo.com.br", username: "vivo", password: "vivo" },
{ countryoperator: "BR - VIVO (Zap)", apn: "zap.vivo.com.br", username: "vivo", password: "vivo" },
{ countryoperator: "BS - BTC (Postpaid)", apn: "internet.btcbahamas.com", username: "", password: "" },
{ countryoperator: "BS - BTC (Prepaid)", apn: "ppinternet.btcbahamas.com", username: "", password: "" },
{ countryoperator: "BT - Bhutan Telecom", apn: "internet", username: "", password: "" },
{ countryoperator: "BW - Mascom", apn: "internet.mascom", username: "", password: "" },
{ countryoperator: "BW - Orange", apn: "orangeworld.orange.co.bw", username: "", password: "" },
{ countryoperator: "BWC - RU", apn: "inet.bwc.ru", username: "bwc", password: "bwc" },
{ countryoperator: "BY - Life", apn: "internet.life.com.by", username: "", password: "" },
{ countryoperator: "BY - MTS", apn: "mts", username: "mts", password: "mts" },
{ countryoperator: "BY - Velcom (vmi.velcom.by)", apn: "vmi.velcom.by", username: "vmi", password: "vmi" },
{ countryoperator: "BY - Velcom (web.velcom.by)", apn: "web.velcom.by", username: "web", password: "web" },
{ countryoperator: "BY - Velcom (web2.velcom.by)", apn: "web2.velcom.by", username: "web2", password: "web2" },
{ countryoperator: "BZ - Digicall (digicellbroadband)", apn: "digicellbroadband", username: "", password: "" },
{ countryoperator: "BZ - Digicell", apn: "www.btlgprs.bz", username: "", password: "" },
{ countryoperator: "CA - Bell", apn: "pda2.bell.ca", username: "", password: "" },
{ countryoperator: "CA - Bell (2)", apn: "inet.bell.ca", username: "", password: "" },
{ countryoperator: "CA - Bell (pda.bell.ca)", apn: "pda.bell.ca", username: "", password: "" },
{ countryoperator: "CA - Bell (proxy.bell.ca)", apn: "proxy.bell.ca", username: "", password: "" },
{ countryoperator: "CA - Chatr", apn: "chatrweb.apn", username: "", password: "" },
{ countryoperator: "CA - Eastlink Internet", apn: "wisp.mobi.eastlink.ca", username: "", password: "" },
{ countryoperator: "CA - Fido", apn: "internet.fido.ca", username: "fido", password: "fido" },
{ countryoperator: "CA - Fido (2)", apn: "fido-core-appl1.apn", username: "", password: "" },
{ countryoperator: "CA - Fido (LTE)", apn: "LTEMOBILE.APN", username: "", password: "" },
{ countryoperator: "CA - Koodo", apn: "sp.koodo.com", username: "", password: "" },
{ countryoperator: "CA - Kore Wireless", apn: "apn.zerogravitywireless.com", username: "", password: "" },
{ countryoperator: "CA - Microcell", apn: "internet.fido.ca", username: "", password: "" },
{ countryoperator: "CA - Mobilicity", apn: "wap.davewireless.com", username: "", password: "" },
{ countryoperator: "CA - MTS", apn: "sp.mts", username: "", password: "" },
{ countryoperator: "CA - PCMobile", apn: "sp.mb.com", username: "", password: "" },
{ countryoperator: "CA - Petro-Canada", apn: "goam.com", username: "wapuser1", password: "wap" },
{ countryoperator: "CA - Public Mobile", apn: "sp.mb.com", username: "", password: "" },
{ countryoperator: "CA - Rogers (internet.com)", apn: "internet.com", username: "wapuser1", password: "wap" },
{ countryoperator: "CA - Rogers (rogers-core-appl1.apn)", apn: "rogers-core-appl1.apn", username: "", password: "" },
{ countryoperator: "CA - Rogers (vpn.com)", apn: "vpn.com", username: "", password: "" },
{ countryoperator: "CA - Sasktel", apn: "inet.stm.sk.ca", username: "", password: "" },
{ countryoperator: "CA - Speakout", apn: "rogers-core-appl1.apn", username: "", password: "" },
{ countryoperator: "CA - Speakout (Old)", apn: "goam.com", username: "wapuser1", password: "wap" },
{ countryoperator: "CA - Telus", apn: "sp.telus.com", username: "", password: "" },
{ countryoperator: "CA - Telus (bb.telus.com)", apn: "bb.telus.com", username: "", password: "" },
{ countryoperator: "CA - Telus (isp.telus.com)", apn: "isp.telus.com", username: "", password: "" },
{ countryoperator: "CA - Telus (vpn.telus.com)", apn: "vpn.telus.com", username: "", password: "" },
{ countryoperator: "CA - Videotron", apn: "media.videotron", username: "", password: "" },
{ countryoperator: "CA - Videotron (ihvm)", apn: "ihvm.videotron", username: "", password: "" },
{ countryoperator: "CA - Virgin", apn: "inet.bell.ca", username: "", password: "" },
{ countryoperator: "CA - Vision Mobile", apn: "sp.mb.com", username: "", password: "" },
{ countryoperator: "CA - WIND", apn: "internet.windmobile.ca", username: "", password: "" },
{ countryoperator: "CD - Vodacom", apn: "vodanet", username: "vodalive", password: "" },
{ countryoperator: "CG - MTN", apn: "internet.mtn.cg", username: "", password: "" },
{ countryoperator: "CG - Warid", apn: "web.waridtel.cg", username: "", password: "" },
{ countryoperator: "CG - Zain", apn: "internet.cg.zain.com", username: "", password: "" },
{ countryoperator: "CH - Naka Mobile", apn: "chili", username: "", password: "" },
{ countryoperator: "CH - Orange (1)", apn: "internet", username: "", password: "" },
{ countryoperator: "CH - Orange (2)", apn: "click", username: "", password: "" },
{ countryoperator: "CH - Sunrise", apn: "internet", username: "", password: "" },
{ countryoperator: "CH - Swisscom", apn: "gprs.swisscom.ch", username: "", password: "" },
{ countryoperator: "CH - Swisscom (Corporate)", apn: "corporate.swisscom.ch", username: "testprofil", password: "temporary" },
{ countryoperator: "CI - MTN", apn: "web.mtn.ci", username: "", password: "" },
{ countryoperator: "CL - Claro (bam.clarochile.cl)", apn: "bam.clarochile.cl", username: "clarochile", password: "clarochile" },
{ countryoperator: "CL - Entelpcs", apn: "bam.entelpcs.cl", username: "entelpcs", password: "entelpcs" },
{ countryoperator: "CL - Movil Falabella", apn: "internet.movilfalabella.com", username: "", password: "" },
{ countryoperator: "CL - Movistar (wap.tmovil.cl)", apn: "wap.tmovil.cl", username: "wap", password: "wap" },
{ countryoperator: "CL - Movistar (web.tmovil.cl)", apn: "web.tmovil.cl", username: "web", password: "web" },
{ countryoperator: "CL - Virgin", apn: "imovil.virginmobile.cl", username: "", password: "" },
{ countryoperator: "CL - VTR", apn: "movil.vtr.com", username: "vtrmovil", password: "vtrmovil" },
{ countryoperator: "CM - MTN", apn: "INTERNET", username: "guest", password: "guest" },
{ countryoperator: "CM - Orange", apn: "orangecmgprs", username: "orange", password: "orange" },
{ countryoperator: "CN - 263SHCU", apn: "263a.shapn", username: "263", password: "263" },
{ countryoperator: "CN - CMCC", apn: "cmnet", username: "", password: "" },
{ countryoperator: "CN - Unicom (3gnet)", apn: "3gnet", username: "", password: "" },
{ countryoperator: "CN - Unicom (DRENET)", apn: "DRENET", username: "", password: "" },
{ countryoperator: "CO - Claro", apn: "internet.comcel.com.co", username: "comcelwap", password: "comcelwap" },
{ countryoperator: "CO - Colombia Mobile", apn: "web.colombiamovil.com.co", username: "web-cm1900", password: "web-cm1900" },
{ countryoperator: "CO - Comcel", apn: "internet.comcel.com.co", username: "COMCELWEB", password: "COMCELWEB" },
{ countryoperator: "CO - eTb", apn: "moviletb.net.co", username: "etb", password: "etb" },
{ countryoperator: "CO - Movil Exito", apn: "movilexito.net.co", username: "", password: "" },
{ countryoperator: "CO - Movistar", apn: "internet.movistar.com.co", username: "movistar", password: "movistar" },
{ countryoperator: "CO - Uff", apn: "www.uffmovil.com.co", username: "", password: "" },
{ countryoperator: "CO - UNE", apn: "www.une.net.co", username: "une", password: "une" },
{ countryoperator: "CO - Virgin Mobile", apn: "web.vmc.net.co", username: "", password: "" },
{ countryoperator: "CR - Claro", apn: "internet.ideasclaro", username: "", password: "" },
{ countryoperator: "CR - ICE (icecelular)", apn: "icecelular", username: "", password: "" },
{ countryoperator: "CR - ICE (kolbimundo)", apn: "kolimundo", username: "", password: "" },
{ countryoperator: "CR - Kolbi", apn: "kolbi3g", username: "", password: "" },
{ countryoperator: "CR - Movistar", apn: "internet.movistar.cr", username: "movistarcr", password: "movistarcr" },
{ countryoperator: "CR - Tuyo Móvil", apn: "tm7datos", username: "", password: "" },
{ countryoperator: "CU - Cubacel", apn: "nauta", username: "", password: "" },
{ countryoperator: "CW - Digicel", apn: "web.digicelcuracao.com", username: "", password: "" },
{ countryoperator: "CY - Cytamobile", apn: "cytamobile", username: "user", password: "pass" },
{ countryoperator: "CY - MTN", apn: "internet", username: "", password: "" },
{ countryoperator: "CZ - O2", apn: "internet", username: "", password: "" },
{ countryoperator: "CZ - T-Mobile", apn: "internet.t-mobile.cz", username: "wap", password: "wap" },
{ countryoperator: "CZ - Vodafone", apn: "internet", username: "", password: "" },
{ countryoperator: "DE - Aldi", apn: "internet.eplus.de", username: "eplus", password: "gprs" },
{ countryoperator: "DE - Alice", apn: "internet.partner1", username: "", password: "" },
{ countryoperator: "DE - Base", apn: "internet.eplus.de", username: "eplus", password: "internet" },
{ countryoperator: "DE - Blau", apn: "internet.eplus.de", username: "blau", password: "blau" },
{ countryoperator: "DE - Blauworld", apn: "internet.eplus.de ", username: "blauworld", password: "blauworld" },
{ countryoperator: "DE - Eplus", apn: "internet.eplus.de", username: "eplus", password: "gprs" },
{ countryoperator: "DE - FONIC", apn: "pinternet.interkom.de", username: "", password: "" },
{ countryoperator: "DE - Klarmobil", apn: "internet.t-d1.de", username: "", password: "" },
{ countryoperator: "DE - Lebara", apn: "internet.t-d1.de", username: "", password: "" },
{ countryoperator: "DE - O.TEL.O", apn: "data.otelo.de", username: "", password: "" },
{ countryoperator: "DE - O2 (Internet)", apn: "Internet", username: "", password: "" },
{ countryoperator: "DE - O2 (surfo2)", apn: "surfo2", username: "", password: "" },
{ countryoperator: "DE - Ortel Mobile", apn: "internet.eplus.de", username: "", password: "" },
{ countryoperator: "DE - Simyo", apn: "internet.eplus.de", username: "simyo", password: "simyo" },
{ countryoperator: "DE - sipgate", apn: "sipgate", username: "sipgate", password: "sipgate" },
{ countryoperator: "DE - T-Mobile", apn: "internet.t-mobile", username: "t-mobile", password: "tm" },
{ countryoperator: "DE - Tchibo", apn: "webmobil1", username: "", password: "" },
{ countryoperator: "DE - Truphone", apn: "truphone.com", username: "", password: "" },
{ countryoperator: "DE - Vodafone", apn: "web.vodafone.de", username: "vodafone", password: "vodafone" },
{ countryoperator: "DK - 3", apn: "data.tre.dk", username: "", password: "" },
{ countryoperator: "DK - BiBoB", apn: "Internet.bibob.dk", username: "", password: "" },
{ countryoperator: "DK - Oister", apn: "data.tre.dk", username: "", password: "" },
{ countryoperator: "DK - Orange", apn: "web.orange.dk", username: "", password: "" },
{ countryoperator: "DK - Sonofon", apn: "", username: "", password: "" },
{ countryoperator: "DK - TDC", apn: "internet", username: "", password: "" },
{ countryoperator: "DM - Telenor", apn: "Telenor", username: "", password: "" },
{ countryoperator: "DO - Claro", apn: "internet.ideasclaro.com.do", username: "", password: "" },
{ countryoperator: "DO - Orange", apn: "orangenet.com.do", username: "orange", password: "orange" },
{ countryoperator: "DO - Viva", apn: "edge.viva.net.do", username: "viva", password: "viva" },
{ countryoperator: "DZ - DJezzy", apn: "djezzy.internet", username: "", password: "" },
{ countryoperator: "DZ - Mobilis", apn: "internet", username: "internet", password: "internet" },
{ countryoperator: "DZ - Nedjma", apn: "WEB", username: "nedjma", password: "nedjma" },
{ countryoperator: "EC - Claro", apn: "internet.claro.com.ec", username: "", password: "" },
{ countryoperator: "EC - CNT", apn: "internet3gsp.alegro.net.ec", username: "", password: "" },
{ countryoperator: "EC - Movistar (internet)", apn: "internet.movistar.com.ec", username: "movistar", password: "movistar" },
{ countryoperator: "EC - Movistar (navega)", apn: "navega.movistar.ec", username: "movistar", password: "movistar" },
{ countryoperator: "EC - Porta", apn: "internet.porta.com.ec", username: "", password: "" },
{ countryoperator: "EE - Elisa", apn: "internet", username: "", password: "" },
{ countryoperator: "EE - EMT", apn: "internet.emt.ee", username: "", password: "" },
{ countryoperator: "EE - Tele2", apn: "internet.tele2.ee", username: "", password: "" },
{ countryoperator: "EG - Etisalat", apn: "etisalat", username: "", password: "" },
{ countryoperator: "EG - Mobinil", apn: "mobinilweb", username: "", password: "" },
{ countryoperator: "EG - Vodafone (internet.vodafone.net)", apn: "internet.vodafone.net", username: "internet", password: "internet" },
{ countryoperator: "EG - Vodafone (iphone.vodafone.com.eg)", apn: "iphone.vodafone.com.eg", username: "internet", password: "internet" },
{ countryoperator: "ES - Amena", apn: "orangeworld", username: "orange", password: "orange" },
{ countryoperator: "ES - Carrefour Movil", apn: "CARREFOURINTERNET", username: "", password: "" },
{ countryoperator: "ES - Digimobil", apn: "internet.digimobil.es", username: "digi", password: "digi" },
{ countryoperator: "ES - Eroski Movil", apn: "gprs.eroskimovil.es", username: "wap@wap", password: "wap125" },
{ countryoperator: "ES - Euskaltel", apn: "internet.euskaltel.mobi", username: "CLIENTE", password: "EUSKALTEL" },
{ countryoperator: "ES - Happy Movil", apn: "internettph", username: "", password: "" },
{ countryoperator: "ES - Hits Mobile (pc.hitsmobile.es)", apn: "pc.hitsmobile.es", username: "", password: "" },
{ countryoperator: "ES - Hits Mobile (tel.hitsmobile.es)", apn: "tel.hitsmobile.es", username: "", password: "" },
{ countryoperator: "ES - ION Mobile", apn: "inet.es", username: "", password: "" },
{ countryoperator: "ES - Jazztel", apn: "jazzinternet", username: "", password: "" },
{ countryoperator: "ES - Lebara", apn: "gprsmov.lebaramobile.es", username: "", password: "" },
{ countryoperator: "ES - Llamaya", apn: "moreinternet", username: "", password: "" },
{ countryoperator: "ES - Lycamobile", apn: "data.lycamobile.es", username: "", password: "" },
{ countryoperator: "ES - Masmovil (30MB)", apn: "int.socialmas", username: "", password: "" },
{ countryoperator: "ES - Masmovil (Standard)", apn: "internetmas", username: "", password: "" },
{ countryoperator: "ES - Movistar", apn: "movistar.es", username: "MOVISTAR", password: "MOVISTAR" },
{ countryoperator: "ES - Ono", apn: "internet.ono.com", username: "", password: "" },
{ countryoperator: "ES - Orange", apn: "internet", username: "orange", password: "orange" },
{ countryoperator: "ES - Ortel Mobile", apn: "ortelinternet", username: "", password: "" },
{ countryoperator: "ES - Pepephone", apn: "gprsmov.pepephone.com", username: "", password: "" },
{ countryoperator: "ES - R", apn: "internet.mundo-r.com", username: "", password: "" },
{ countryoperator: "ES - Simyo", apn: "gprs-service.com", username: "", password: "" },
{ countryoperator: "ES - Telecable", apn: "internet.telecable.es", username: "telecable", password: "telecable" },
{ countryoperator: "ES - Telstra", apn: "Internet", username: "", password: "" },
{ countryoperator: "ES - The Phone House", apn: "internettph", username: "", password: "" },
{ countryoperator: "ES - Truphone", apn: "truphone.com", username: "", password: "" },
{ countryoperator: "ES - Tuenti", apn: "tuenti.com", username: "tuenti", password: "tuenti" },
{ countryoperator: "ES - Vodafone", apn: "ac.vodafone.es", username: "vodafone", password: "vodafone" },
{ countryoperator: "ES - Yoigo", apn: "Internet", username: "", password: "" },
{ countryoperator: "ET - ETC", apn: "etc.com", username: "", password: "" },
{ countryoperator: "FI - DNA", apn: "internet", username: "", password: "" },
{ countryoperator: "FI - ELISA", apn: "internet", username: "", password: "" },
{ countryoperator: "FI - Saunalahti (Postpaid)", apn: "internet.saunalahti", username: "", password: "" },
{ countryoperator: "FI - Saunalahti (Prepaid)", apn: "internet", username: "", password: "" },
{ countryoperator: "FI - Sonera", apn: "internet", username: "", password: "" },
{ countryoperator: "FJ - Digicel", apn: "web.digicelpacific.com", username: "", password: "" },
{ countryoperator: "FJ - Vodafone (Postpaid)", apn: "vfinternet.fj", username: "", password: "" },
{ countryoperator: "FJ - Vodafone (Prepaid)", apn: "live.vodafone.com.fj", username: "", password: "" },
{ countryoperator: "FO - Vodafone", apn: "vmc.vodafone.fo", username: "", password: "" },
{ countryoperator: "FR - Bouygues", apn: "mmsbouygtel.com", username: "", password: "" },
{ countryoperator: "FR - Bouygues Pro", apn: "a2bouygtel", username: "a2b", password: "acces" },
{ countryoperator: "FR - Free", apn: "free", username: "", password: "" },
{ countryoperator: "FR - ISYS", apn: "netgprs.com", username: "tsl", password: "tsl" },
{ countryoperator: "FR - Laposte Mobile", apn: "wapdebitel", username: "", password: "" },
{ countryoperator: "FR - Lebara", apn: "fr.lebara.mobi", username: "wap", password: "" },
{ countryoperator: "FR - LeFrenchMobile", apn: "netgprs.com", username: "tsl", password: "tsl" },
{ countryoperator: "FR - NRJ (fnetnrj)", apn: "fnetnrj", username: "", password: "" },
{ countryoperator: "FR - NRJ (ofnewfr)", apn: "ofnew.fr", username: "orange", password: "orange" },
{ countryoperator: "FR - Numericable", apn: "numericable.fr", username: "", password: "" },
{ countryoperator: "FR - Orange", apn: "orange.fr", username: "orange", password: "orange" },
{ countryoperator: "FR - Orange (Business)", apn: "internet-entreprise", username: "orange", password: "orange" },
{ countryoperator: "FR - Orange (Mobicarte)", apn: "orange.fr", username: "orange", password: "orange" },
{ countryoperator: "FR - Ortel Mobile", apn: "gprs-service-fr.net", username: "", password: "" },
{ countryoperator: "FR - SFR (New)", apn: "websfr", username: "", password: "" },
{ countryoperator: "FR - SFR (OLD)", apn: "sl2sfr", username: "", password: "" },
{ countryoperator: "FR - Virgin", apn: "ofnew.fr", username: "orange", password: "orange" },
{ countryoperator: "FR - Zero Forfait", apn: "internet68", username: "", password: "" },
{ countryoperator: "GE - Geocell", apn: "internet", username: "", password: "" },
{ countryoperator: "GE - Magtigsm", apn: "3g.ge", username: "", password: "" },
{ countryoperator: "GH - EMT", apn: "internet.emt.ee", username: "", password: "" },
{ countryoperator: "GH - MTN", apn: "internet", username: "", password: "" },
{ countryoperator: "GH - Tigo", apn: "web.tigo.com.gh", username: "", password: "" },
{ countryoperator: "GH - Vodafone", apn: "browse", username: "", password: "" },
{ countryoperator: "GH - Zain", apn: "internet", username: "", password: "" },
{ countryoperator: "GM - Africell", apn: "africellnet", username: "", password: "" },
{ countryoperator: "GM - Gamcel", apn: "gamcellnet", username: "", password: "" },
{ countryoperator: "GM - Qcell", apn: "qcellnet", username: "", password: "" },
{ countryoperator: "GR - Cosmote", apn: "internet", username: "", password: "" },
{ countryoperator: "GR - Vodafone (internet.vodafone.gr)", apn: "internet.vodafone.gr", username: "", password: "" },
{ countryoperator: "GR - Vodafone (web.session)", apn: "web.session", username: "", password: "" },
{ countryoperator: "GR - Vodafone (webonly.vodafone.gr)", apn: "webonly.vodafone.gr", username: "", password: "" },
{ countryoperator: "GR - Wind (1)", apn: "gnet.b-online.gr", username: "", password: "" },
{ countryoperator: "GR - Wind (2)", apn: "gint.b-online.gr", username: "", password: "" },
{ countryoperator: "GT - Claro", apn: "internet.ideasclaro", username: "", password: "" },
{ countryoperator: "GT - Movistar", apn: "internet.movistar.gt", username: "movistargt", password: "movistargt" },
{ countryoperator: "GT - TIGO", apn: "broadband.tigo.gt", username: "", password: "" },
{ countryoperator: "GU - Docomo", apn: "internet", username: "", password: "" },
{ countryoperator: "GU - GTA", apn: "mpulse.GTA.net", username: "", password: "" },
{ countryoperator: "GU - iConnect", apn: "ican", username: "", password: "" },
{ countryoperator: "GU - IT&E", apn: "internet.ite.net", username: "", password: "" },
{ countryoperator: "GY - DigiCel", apn: "web.digicelgy.com", username: "web", password: "web" },
{ countryoperator: "GY - GT&T (portal.cellinkgy.com)", apn: "portal.cellinkgy.com", username: "gtt", password: "gtt" },
{ countryoperator: "GY - GT&T (wap.cellinkgy.com)", apn: "wap.cellinkgy.com", username: "gtt", password: "gtt" },
{ countryoperator: "HK - China Mobile", apn: "cmhk", username: "", password: "" },
{ countryoperator: "HK - CSL", apn: "internet", username: "", password: "" },
{ countryoperator: "HK - HKCSL (Postpaid)", apn: "hkcsl", username: "", password: "" },
{ countryoperator: "HK - HKCSL (Prepaid)", apn: "cslp2", username: "", password: "" },
{ countryoperator: "HK - New World", apn: "internet", username: "", password: "" },
{ countryoperator: "HK - Orange", apn: "web.orangehk.com", username: "", password: "" },
{ countryoperator: "HK - PCCW", apn: "pccw", username: "", password: "" },
{ countryoperator: "HK - Peoples", apn: "peoples.net", username: "", password: "" },
{ countryoperator: "HK - SmarTone", apn: "smartone", username: "", password: "" },
{ countryoperator: "HK - Sunday", apn: "internet", username: "", password: "" },
{ countryoperator: "HK - Three (iIpc.three.com.hk", apn: "ipc.three.com.hk", username: "", password: "" },
{ countryoperator: "HK - Three (imobile.three.com.hk)", apn: "imobile.three.com.hk", username: "", password: "" },
{ countryoperator: "HK - Three (LTE)", apn: "mobile.lte.three.com.uk", username: "", password: "" },
{ countryoperator: "HK - Three (mobile.three.com.hk)", apn: "mobile.three.com.hk", username: "", password: "" },
{ countryoperator: "HK - Three (web-g.three.com.hk)", apn: "web-g.three.com.hk", username: "", password: "" },
{ countryoperator: "HK - Truphone", apn: "truphone.com", username: "", password: "" },
{ countryoperator: "HN - Claro", apn: "internet.ideasclaro", username: "", password: "" },
{ countryoperator: "HN - Digicel", apn: "web.digicelhn.com", username: "", password: "" },
{ countryoperator: "HN - Tigo (3G)", apn: "broadband.tigo.hn", username: "", password: "" },
{ countryoperator: "HN - Tigo (Edge)", apn: "internet.tigo.hn", username: "", password: "" },
{ countryoperator: "HR - T-mobile", apn: "web.htgprs", username: "", password: "" },
{ countryoperator: "HR - Tele2", apn: "wap.tele2.hr", username: "", password: "" },
{ countryoperator: "HR - Tomato", apn: "tomato", username: "", password: "" },
{ countryoperator: "HR - VIPnet", apn: "data.vip.hr", username: "", password: "" },
{ countryoperator: "HT - Digicel", apn: "wap.digicelha.com", username: "", password: "" },
{ countryoperator: "HT - Natcom", apn: "natcom", username: "natcom", password: "1111" },
{ countryoperator: "HU - Pannon", apn: "net", username: "", password: "" },
{ countryoperator: "HU - T-Mobile", apn: "internet", username: "", password: "" },
{ countryoperator: "HU - Telenor", apn: "net", username: "", password: "" },
{ countryoperator: "HU - Telenor (Postpaid)", apn: "online", username: "", password: "" },
{ countryoperator: "HU - Vodafone", apn: "internet.vodafone.net", username: "", password: "" },
{ countryoperator: "ID - Axis", apn: "axis", username: "axis", password: "123456" },
{ countryoperator: "ID - IM3", apn: "www.indosat-m3.net", username: "gprs", password: "im3" },
{ countryoperator: "ID - Indosat", apn: "indosatgprs", username: "indosat", password: "indosat" },
{ countryoperator: "ID - Matrix", apn: "satelindogprs", username: "", password: "" },
{ countryoperator: "ID - Telkomsel", apn: "internet", username: "", password: "" },
{ countryoperator: "ID - Three", apn: "3data", username: "3data", password: "3data" },
{ countryoperator: "ID - XL", apn: "www.xlgprs.net", username: "xlgprs", password: "proxl" },
{ countryoperator: "ID - XL (xlunlimited)", apn: "xlunlimited", username: "", password: "" },
{ countryoperator: "IE - 48Months", apn: "48months.liffeytelecom.com", username: "", password: "" },
{ countryoperator: "IE - Blueface (Postpaid)", apn: "mbb.mobility.ie", username: "", password: "" },
{ countryoperator: "IE - Blueface (Prepaid)", apn: "mob.mobility.ie", username: "", password: "" },
{ countryoperator: "IE - EMobile", apn: "data.eircom.ie", username: "", password: "" },
{ countryoperator: "IE - iD Mobile", apn: "mbb.mobility.ie", username: "", password: "" },
{ countryoperator: "IE - Lyca Mobile", apn: "data.lycamobile.ie", username: "lmie", password: "plus" },
{ countryoperator: "IE - Meteor", apn: "data.mymeteor.ie", username: "", password: "" },
{ countryoperator: "IE - O2 (internet)", apn: "internet", username: "", password: "" },
{ countryoperator: "IE - O2 (open.internet)", apn: "open.internet", username: "", password: "" },
{ countryoperator: "IE - Tesco", apn: "tescomobile.liffeytelecom.com", username: "", password: "" },
{ countryoperator: "IE - Three", apn: "3ireland.ie", username: "", password: "" },
{ countryoperator: "IE - Vodafone (HSPDA)", apn: "hs.vodafone.ie", username: "vodafone", password: "vodafone" },
{ countryoperator: "IE - Vodafone (isp.vodafone.ie)", apn: "isp.vodafone.ie", username: "vodafone", password: "vodafone" },
{ countryoperator: "IE - Vodafone (live.vodafone.com)", apn: "live.vodafone.com", username: "", password: "" },
{ countryoperator: "IL - 012 Mobile", apn: "uwap.orange.co.il", username: "", password: "" },
{ countryoperator: "IL - AZI", apn: "netazi", username: "", password: "" },
{ countryoperator: "IL - Cellcom", apn: "internetg", username: "", password: "" },
{ countryoperator: "IL - Golan Telecom", apn: "internet.golantelecom.net.il", username: "", password: "" },
{ countryoperator: "IL - Home Cellular", apn: "hcminternet", username: "", password: "" },
{ countryoperator: "IL - Hotmobile", apn: "net.hotm", username: "", password: "" },
{ countryoperator: "IL - Orange", apn: "uinternet", username: "orange", password: "orange" },
{ countryoperator: "IL - Pelephone", apn: "internet.pelephone.net.il", username: "pcl@3g", password: "pcl" },
{ countryoperator: "IL - Rami Levy", apn: "internet.rl", username: "rl@3g", password: "rl" },
{ countryoperator: "IL - YouPhone", apn: "data.youphone.co.il", username: "", password: "" },
{ countryoperator: "IM - Manx", apn: "3gpronto", username: "", password: "" },
{ countryoperator: "IM - Sure", apn: "internet", username: "", password: "" },
{ countryoperator: "IN - Aircel (aircelgprs)", apn: "aircelgprs", username: "", password: "" },
{ countryoperator: "IN - Aircel (aircelnet)", apn: "aircelnet", username: "", password: "" },
{ countryoperator: "IN - Airtel", apn: "airtelgprs.com", username: "", password: "" },
{ countryoperator: "IN - BSNL", apn: "bsnlnet", username: "", password: "" },
{ countryoperator: "IN - Idea", apn: "internet", username: "", password: "" },
{ countryoperator: "IN - Loop", apn: "www", username: "loop", password: "loop" },
{ countryoperator: "IN - MTNL (Postpaid)", apn: "mtnl.net", username: "mtnl", password: "mtnl123" },
{ countryoperator: "IN - MTNL (Prepaid)", apn: "mtnl.net", username: "mtnl", password: "mtnl123" },
{ countryoperator: "IN - Reliance", apn: "rcomnet", username: "", password: "" },
{ countryoperator: "IN - Tata Docomo", apn: "TATA.DOCOMO.INTERNET", username: "", password: "" },
{ countryoperator: "IN - Tata Docomo (Unlimited)", apn: "TATA.DOCOMO.INTERNETHVC", username: "", password: "" },
{ countryoperator: "IN - Videocon", apn: "vinternet.com", username: "", password: "" },
{ countryoperator: "IN - Virgin", apn: "vinternet.in", username: "", password: "" },
{ countryoperator: "IN - Vodafone", apn: "www", username: "", password: "" },
{ countryoperator: "IN - Vodafone (iphone)", apn: "iphone", username: "", password: "" },
{ countryoperator: "IN - Vodafone (portalnmms)", apn: "portalnmms", username: "", password: "" },
{ countryoperator: "IQ - Asiacell", apn: "net.asiacell.com", username: "", password: "" },
{ countryoperator: "IQ - Zain", apn: "internet", username: "", password: "" },
{ countryoperator: "IR - MCI", apn: "mcinet", username: "", password: "" },
{ countryoperator: "IR - MT Irancell", apn: "mtnirancell", username: "", password: "" },
{ countryoperator: "IS - Hringdu", apn: "gprs.imc.is", username: "", password: "" },
{ countryoperator: "IS - Nova (internet.nova.is)", apn: "internet.nova.is", username: "", password: "" },
{ countryoperator: "IS - Nova (net.nova.is)", apn: "net.nova.is", username: "", password: "" },
{ countryoperator: "IS - Siminn", apn: "wap.simi.is", username: "", password: "" },
{ countryoperator: "IS - Tal", apn: "internet.tal.is", username: "", password: "" },
{ countryoperator: "IS - Vodafone", apn: "vmc.gprs.is", username: "", password: "" },
{ countryoperator: "IT - Bip Mobile", apn: "internet.vistream.it", username: "", password: "" },
{ countryoperator: "IT - BT Italia", apn: "Internet.btitalia.it", username: "", password: "" },
{ countryoperator: "IT - Erg Mobile", apn: "mobile.erg.it", username: "", password: "" },
{ countryoperator: "IT - Fastweb (apn.fastweb.it", apn: "apn.fastweb.it", username: "", password: "" },
{ countryoperator: "IT - Fastweb (datacard.fastweb.it)", apn: "datacard.fastweb.it", username: "", password: "" },
{ countryoperator: "IT - H3G", apn: "tre.it", username: "", password: "" },
{ countryoperator: "IT - Noverca", apn: "web.noverca.it", username: "", password: "" },
{ countryoperator: "IT - Postemobile (internet.postemobile.it)", apn: "internet.postemobile.it", username: "", password: "" },
{ countryoperator: "IT - Postemobile (wap.postemobile.it)", apn: "wap.postemobile.it", username: "", password: "" },
{ countryoperator: "IT - Tim (ibox)", apn: "ibox.tim.it", username: "", password: "" },
{ countryoperator: "IT - Tim (wap)", apn: "wap.tim.it", username: "", password: "" },
{ countryoperator: "IT - Tiscali Mobile", apn: "tiscalimobileinternet", username: "", password: "" },
{ countryoperator: "IT - Uno", apn: "web.unomobile.it", username: "", password: "" },
{ countryoperator: "IT - Vodafone (iPhone)", apn: "iPhone.vodafone.it", username: "", password: "" },
{ countryoperator: "IT - Vodafone (mobile.vodafone.it)", apn: "mobile.vodafone.it", username: "", password: "" },
{ countryoperator: "IT - Vodafone (Omnitel)", apn: "web.omnitel.it", username: "", password: "" },
{ countryoperator: "IT - Wind", apn: "internet.wind", username: "", password: "" },
{ countryoperator: "IT - Wind (Business)", apn: "internet.wind.biz", username: "", password: "" },
{ countryoperator: "JM - Cable & Wireless", apn: "wap", username: "", password: "" },
{ countryoperator: "JM - Claro", apn: "internet.ideasclaro.com.jm", username: "", password: "" },
{ countryoperator: "JM - Digicel (web)", apn: "web", username: "", password: "" },
{ countryoperator: "JM - Digicel (web.digiceljamaica.com)", apn: "web.digiceljamaica.com", username: "", password: "" },
{ countryoperator: "JM - Lime", apn: "ppinternet", username: "", password: "" },
{ countryoperator: "JO - Orange", apn: "net.orange.jo", username: "net", password: "net" },
{ countryoperator: "JO - Umniah", apn: "net", username: "", password: "" },
{ countryoperator: "JO - Zain", apn: "internet", username: "", password: "" },
{ countryoperator: "JP - Asahi NET (128K Dynamic)", apn: "lte.mobac.net", username: "d@x.asahinet.jp", password: "0000" },
{ countryoperator: "JP - Asahi NET (128K Fixed)", apn: "lte.mobac.net", username: "f@x.asahinet.jp", password: "0000" },
{ countryoperator: "JP - Asahi NET (1G Dynamic)", apn: "lte.mobac.net", username: "d@w.asahinet.jp", password: "0000" },
{ countryoperator: "JP - Asahi NET (1G Fixed)", apn: "lte.mobac.net", username: "f@w.asahinet.jp", password: "0000" },
{ countryoperator: "JP - Asahi NET (3G Dynamic)", apn: "3g.mobac.net", username: "d@y.asahinet.jp", password: "0000" },
{ countryoperator: "JP - Asahi NET (3G Fixed)", apn: "3g.mobac.net", username: "f@y.asahinet.jp", password: "0000" },
{ countryoperator: "JP - B-Mobile (bmobile@4g)", apn: "bmobile.ne.jp", username: "bmobile@4g", password: "bmobile" },
{ countryoperator: "JP - B-Mobile (bmobile@am)", apn: "bmobile.ne.jp", username: "bmobile@am", password: "bmobile" },
{ countryoperator: "JP - B-Mobile (bmobile@fr)", apn: "bmobile.ne.jp", username: "bmobile@fr", password: "bmobile" },
{ countryoperator: "JP - B-Mobile (bmobile@spd)", apn: "bmobile.ne.jp", username: "bmobile@spd", password: "bmobile" },
{ countryoperator: "JP - B-Mobile (bmobile@u300)", apn: "bmobile.ne.jp", username: "bmobile@u300", password: "bmobile" },
{ countryoperator: "JP - B-Mobile (bmobile@xsim)", apn: "bmobile.ne.jp", username: "bmobile@xsim", password: "bmobile" },
{ countryoperator: "JP - B-Mobile (bmobile@zsim)", apn: "bmobile.ne.jp", username: "bmobile@zsim", password: "bmobile" },
{ countryoperator: "JP - B-Mobile (Fair)", apn: "dm.jplat.net", username: "bmobile@fr", password: "bmobile" },
{ countryoperator: "JP - B-Mobile (Pair)", apn: "bmobile.ne.jp", username: "bmobile@zsim", password: "bmobile" },
{ countryoperator: "JP - B-Mobile (Talking Platinum)", apn: "dm.jplat.net", username: "bm@ios", password: "bm" },
{ countryoperator: "JP - B-Mobile (U-300)", apn: "dm.jplat.net", username: "bmobile@u300", password: "bmobile" },
{ countryoperator: "JP - BIGLOBE", apn: "biglobe.jp", username: "user", password: "0000" },
{ countryoperator: "JP - DTI", apn: "dream.jp", username: "user@dream.jp", password: "dti" },
{ countryoperator: "JP - DTI (OLD)", apn: "ybmbl.net", username: "user@3gd.ynmbl.net", password: "3gd" },
{ countryoperator: "JP - Hi-Ho", apn: "vmobile.jp", username: "lte@hi-ho", password: "hi-ho" },
{ countryoperator: "JP - IIJMIO", apn: "iijmio.jp", username: "mio@iij", password: "iij" },
{ countryoperator: "JP - NTT Docomo (mopera.net)", apn: "mopera.net", username: "", password: "" },
{ countryoperator: "JP - NTT Docomo (open.mopera.net)", apn: "open.mopera.net", username: "", password: "" },
{ countryoperator: "JP - NTT Docomo (spmode.net)", apn: "spmode.net", username: "", password: "" },
{ countryoperator: "JP - OCN", apn: "3g-d-2.ocn.ne.jp", username: "", password: "" },
{ countryoperator: "JP - Softbank", apn: "smile.world", username: "dna1trop", password: "so2t3k3m2a" },
{ countryoperator: "JP - Softbank (jpspir)", apn: "jpspir", username: "sirobit", password: "amstkoi" },
{ countryoperator: "JP - Softbank (Prepaid)", apn: "mailwebservice.softbank.ne.jp", username: "", password: "" },
{ countryoperator: "KE - Airtel", apn: "internet", username: "", password: "" },
{ countryoperator: "KE - Orange", apn: "bew.orange.co.ke", username: "", password: "" },
{ countryoperator: "KE - Safaricom", apn: "safaricom", username: "", password: "" },
{ countryoperator: "KG - Megacom", apn: "internet", username: "", password: "" },
{ countryoperator: "KH - Cellcard", apn: "cellcard", username: "mobitel", password: "mobitel" },
{ countryoperator: "KH - Hello", apn: "hellowww", username: "", password: "" },
{ countryoperator: "KH - Metfone", apn: "Metfone", username: "", password: "" },
{ countryoperator: "KH - Mobitel", apn: "cellcard", username: "mobitel", password: "mobitel" },
{ countryoperator: "KH - Smart Mobile", apn: "smart", username: "", password: "" },
{ countryoperator: "KH - Star-Cell", apn: "internet", username: "", password: "" },
{ countryoperator: "KO - iPKO", apn: "ipko", username: "", password: "" },
{ countryoperator: "KO - Vala", apn: "vala900-int", username: "", password: "" },
{ countryoperator: "KO - ZMobile", apn: "z-int", username: "", password: "" },
{ countryoperator: "KR - KT", apn: "alwayson.ktfwing.com", username: "", password: "" },
{ countryoperator: "KR - SK", apn: "web.sktelecom.com", username: "", password: "" },
{ countryoperator: "KW - MTC", apn: "pps", username: "pps", password: "pps" },
{ countryoperator: "KW - Viva", apn: "VIVA", username: "", password: "" },
{ countryoperator: "KW - Wataniya", apn: "action.wataniya.com", username: "", password: "" },
{ countryoperator: "KW - Zain", apn: "pps", username: "pps", password: "pps" },
{ countryoperator: "KW - Zain (apn01)", apn: "apn01", username: "", password: "" },
{ countryoperator: "KY - Digicel", apn: "isp.digicelcayman.com", username: "", password: "" },
{ countryoperator: "KY - Lime", apn: "ppinternet", username: "", password: "" },
{ countryoperator: "KZ - Activ", apn: "internet", username: "", password: "" },
{ countryoperator: "KZ - Beeline", apn: "internet.beeline.kz", username: "", password: "" },
{ countryoperator: "KZ - Cellular One", apn: "wap.cellular1.net", username: "", password: "" },
{ countryoperator: "KZ - K Cell", apn: "internet", username: "", password: "" },
{ countryoperator: "LA - ETL", apn: "etlnet", username: "", password: "" },
{ countryoperator: "LA - Lao Telecom", apn: "ltcnet", username: "", password: "" },
{ countryoperator: "LB - Alfa (internet.mic1.com.lb)", apn: "internet.mic1.com.lb", username: "mic1", password: "mic1" },
{ countryoperator: "LB - Alfa (usb.mic1.com.lb)", apn: "usb.mic1.com.lb", username: "", password: "" },
{ countryoperator: "LB - MTC Touch", apn: "gprs.mtctouch.com.lb", username: "", password: "" },
{ countryoperator: "LC - Cable & Wireless", apn: "internet", username: "", password: "" },
{ countryoperator: "LC - Digicel", apn: "bizapps.digiceloecs.com", username: "wapoecs", password: "wap03oecs" },
{ countryoperator: "LK - Dialog", apn: "dialogbb", username: "", password: "" },
{ countryoperator: "LK - Mobitel", apn: "isp", username: "", password: "" },
{ countryoperator: "LS - Vodacom", apn: "internet", username: "", password: "" },
{ countryoperator: "LT - Bite GSM", apn: "wap.biteplius.lt", username: "", password: "" },
{ countryoperator: "LT - Omnitel", apn: "omnitel", username: "omni", password: "omni" },
{ countryoperator: "LT - Tele2", apn: "internet.tele2.lt", username: "", password: "" },
{ countryoperator: "LU - LUXGSM", apn: "web.pt.lu", username: "", password: "" },
{ countryoperator: "LU - Orange", apn: "orange.lu", username: "", password: "" },
{ countryoperator: "LU - Tango", apn: "internet", username: "tango", password: "tango" },
{ countryoperator: "LU - VOXmobile", apn: "vox.lu", username: "", password: "" },
{ countryoperator: "LV - Bite", apn: "internet", username: "", password: "" },
{ countryoperator: "LV - LMT", apn: "internet.lmt.lv", username: "", password: "" },
{ countryoperator: "LV - Tele2", apn: "internet.tele2.lv", username: "", password: "" },
{ countryoperator: "LY - Almadar", apn: "almadar.net", username: "", password: "" },
{ countryoperator: "MA - INWI", apn: "www.wana.ma", username: "", password: "" },
{ countryoperator: "MA - Maroc Telecom (www.iamgprs1.ma)", apn: "www.iamgprs1.ma", username: "", password: "" },
{ countryoperator: "MA - Maroc Telecom (www.iamgprs2.ma)", apn: "www.iamgprs2.ma", username: "", password: "" },
{ countryoperator: "MA - Mor Meditel", apn: "internet1.meditel.ma", username: "MEDINET", password: "MEDINET" },
{ countryoperator: "MD - Moldcell", apn: "internet", username: "", password: "" },
{ countryoperator: "MD - Orange", apn: "wap.orange.md", username: "", password: "" },
{ countryoperator: "MD - Unite", apn: "internet3g.unite.md", username: "", password: "" },
{ countryoperator: "ME - Mtel ", apn: "www.mtel.me", username: "", password: "" },
{ countryoperator: "ME - T-Mobile (postpaid)", apn: "internet-postpaid", username: "", password: "" },
{ countryoperator: "ME - T-Mobile (prepaid)", apn: "internet-prepaid", username: "", password: "" },
{ countryoperator: "ME - Telenor", apn: "www.telenor.me", username: "", password: "" },
{ countryoperator: "MG - Orange (2G)", apn: "orangenet", username: "", password: "" },
{ countryoperator: "MG - Orange (3G)", apn: "im", username: "", password: "" },
{ countryoperator: "MG - Telma", apn: "internet", username: "", password: "" },
{ countryoperator: "MK - Albafone", apn: "albf-int", username: "", password: "" },
{ countryoperator: "MK - One (Datacard)", apn: "datacard", username: "", password: "" },
{ countryoperator: "MK - One (Postpaid)", apn: "internet", username: "", password: "" },
{ countryoperator: "MK - One (Prepaid)", apn: "ppinternet", username: "", password: "" },
{ countryoperator: "MK - T-Mobile", apn: "internet", username: "internet", password: "t-mobile" },
{ countryoperator: "MK - VIP", apn: "vipoperator", username: "vipoperator", password: "vipoperator" },
{ countryoperator: "MM - MPT", apn: "mptnet", username: "mptnet", password: "mptnet" },
{ countryoperator: "MN - Mobicom (internet)", apn: "internet", username: "", password: "" },
{ countryoperator: "MN - Mobicom (smart)", apn: "smart", username: "", password: "" },
{ countryoperator: "MN - Skytel", apn: "style", username: "", password: "" },
{ countryoperator: "MN - Unitel", apn: "net", username: "", password: "" },
{ countryoperator: "MT - Go Mobile (postpaid)", apn: "gosurfing", username: "", password: "" },
{ countryoperator: "MT - Go Mobile (prepaid)", apn: "rtgsurfing", username: "", password: "" },
{ countryoperator: "MT - Vodafone", apn: "Internet", username: "Internet", password: "Internet" },
{ countryoperator: "MU - Emtel", apn: "web", username: "", password: "" },
{ countryoperator: "MU - Orange", apn: "orange", username: "", password: "" },
{ countryoperator: "MV - Congstar", apn: "internet.t-mobile", username: "t-mobile", password: "tm" },
{ countryoperator: "MV - Dhiraagu", apn: "internet.dhimobile", username: "", password: "" },
{ countryoperator: "MV - Movistar", apn: "internet.movistar.sv", username: "movistarsv", password: "movistarsv" },
{ countryoperator: "MV - Wataniya", apn: "WataniyaNet", username: "", password: "" },
{ countryoperator: "MW - Airtel", apn: "internet", username: "", password: "" },
{ countryoperator: "MX - Cierto", apn: "internet.cierto.mx", username: "", password: "" },
{ countryoperator: "MX - DannyMobile", apn: "globaldata", username: "", password: "" },
{ countryoperator: "MX - iUSACELL", apn: "web.iusacellgsm.mx", username: "iusacellgsm", password: "iusacellgsm" },
{ countryoperator: "MX - Movistar", apn: "internet.movistar.mx", username: "movistar", password: "movistar" },
{ countryoperator: "MX - Telcel", apn: "internet.itelcel.com", username: "webgprs", password: "webgprs2002" },
{ countryoperator: "MX - Unefon", apn: "web.iusacellgsm.mx", username: "iusacellgsm", password: "iusacellgsm" },
{ countryoperator: "MX - Virgin Mobile", apn: "internet.virginmobile.mx", username: "virgin", password: "virgin" },
{ countryoperator: "MY - Celcom (3G)", apn: "celcom3g", username: "", password: "" },
{ countryoperator: "MY - Celcom (4G)", apn: "celcom4g", username: "", password: "" },
{ countryoperator: "MY - Digi (3gdgnet)", apn: "3gdgnet", username: "", password: "" },
{ countryoperator: "MY - Digi (diginet)", apn: "diginet", username: "", password: "" },
{ countryoperator: "MY - Maxis", apn: "unet", username: "", password: "" },
{ countryoperator: "MY - Maxis 3G", apn: "unet", username: "", password: "" },
{ countryoperator: "MY - Timecel", apn: "timenet.com.my", username: "", password: "" },
{ countryoperator: "MY - TM Touch", apn: "internet", username: "", password: "" },
{ countryoperator: "MY - U Mobile", apn: "my3g", username: "", password: "" },
{ countryoperator: "MY - Xpax Prepaid", apn: "celcom", username: "", password: "" },
{ countryoperator: "MZ - MCEL", apn: "isp.mcel.mz", username: "", password: "" },
{ countryoperator: "MZ - MTN", apn: "internet", username: "", password: "" },
{ countryoperator: "MZ - Zamtel", apn: "zamtel.net", username: "", password: "" },
{ countryoperator: "NA - MTC", apn: "ppsinternet", username: "", password: "" },
{ countryoperator: "NC - OPT KNC (limited)", apn: "internet", username: "", password: "" },
{ countryoperator: "NC - OPT KNC (unlimited)", apn: "3g", username: "", password: "" },
{ countryoperator: "NG - Airtel", apn: "internet.ng.airtel.com", username: "internet", password: "internet" },
{ countryoperator: "NG - Etisalat", apn: "etisalat", username: "", password: "" },
{ countryoperator: "NG - Glo (Postpaid)", apn: "gloflat", username: "flat", password: "flat" },
{ countryoperator: "NG - Glo (Prepaid)", apn: "glosecure", username: "gprs", password: "gprs" },
{ countryoperator: "NG - MTN", apn: "web.gprs.mtnnigeria.net", username: "web", password: "web" },
{ countryoperator: "NI - Claro", apn: "web.emovil", username: "webemovil", password: "webemovil" },
{ countryoperator: "NI - Movistar", apn: "internet.movistar.ni", username: "movistarni", password: "movistarni" },
{ countryoperator: "NL - 88Mobile (1000MB)", apn: "basic1000.internet.88mobile.data", username: "", password: "" },
{ countryoperator: "NL - 88Mobile (100MB)", apn: "basic100.internet.88mobile.data", username: "", password: "" },
{ countryoperator: "NL - 88Mobile (default)", apn: "basic.internet.88mobile.data", username: "", password: "" },
{ countryoperator: "NL - Ben (Postpaid)", apn: "internet.ben", username: "", password: "" },
{ countryoperator: "NL - Ben (Prepaid)", apn: "basic.internet.ben.data", username: "", password: "" },
{ countryoperator: "NL - Bliep", apn: "internet.arta", username: "", password: "" },
{ countryoperator: "NL - Delight Mobile", apn: "mobile.barablu.com", username: "", password: "" },
{ countryoperator: "NL - Ecofoon", apn: "basic.internet.ecofoon.data", username: "", password: "" },
{ countryoperator: "NL - ET Mobile (basic.data)", apn: "basic.data", username: "", password: "" },
{ countryoperator: "NL - ET Mobile (platinum.data)", apn: "platinum.data", username: "", password: "" },
{ countryoperator: "NL - Hollands Nieuwe", apn: "data.dataxs.mobi", username: "", password: "" },
{ countryoperator: "NL - KPN", apn: "portalmmm.nl", username: "", password: "" },
{ countryoperator: "NL - Lebara", apn: "multimedia.lebara.nl", username: "", password: "" },
{ countryoperator: "NL - Livv", apn: "basic.internet.thuisconnect.data", username: "", password: "" },
{ countryoperator: "NL - Lycamobile", apn: "data.lycamobile.nl", username: "lmnl", password: "plus" },
{ countryoperator: "NL - Orange", apn: "internet", username: "", password: "" },
{ countryoperator: "NL - Rabo", apn: "rabo", username: "", password: "" },
{ countryoperator: "NL - Simpel", apn: "internet.access.nl", username: "", password: "" },
{ countryoperator: "NL - Simyo", apn: "internet", username: "KPN", password: "gprs" },
{ countryoperator: "NL - T-Mobile", apn: "internet", username: "", password: "" },
{ countryoperator: "NL - Tele2", apn: "internet.tele2.nl", username: "", password: "" },
{ countryoperator: "NL - Telfort", apn: "internet", username: "", password: "" },
{ countryoperator: "NL - Truphone", apn: "truphone.com", username: "", password: "" },
{ countryoperator: "NL - Vodafone(prive)", apn: "live.vodafone.com", username: "vodafone", password: "vodafone" },
{ countryoperator: "NL - Vodafone(zakelijk)", apn: "office.vodafone.nl", username: "vodafone", password: "vodafone" },
{ countryoperator: "NL - Ziggo", apn: "ziggo.dataxs.mobi", username: "", password: "" },
{ countryoperator: "NO - Netcom", apn: "internet.netcom.no", username: "", password: "" },
{ countryoperator: "NO - Onecall", apn: "wap", username: "nwn", password: "wnw" },
{ countryoperator: "NO - Telenor", apn: "Telenor", username: "", password: "" },
{ countryoperator: "NP - Ncell", apn: "web", username: "", password: "" },
{ countryoperator: "NP - Nepal Telecom", apn: "ntnet", username: "", password: "" },
{ countryoperator: "NZ - 2Degrees", apn: "internet", username: "", password: "" },
{ countryoperator: "NZ - Black+White", apn: "www.m2.net.nz", username: "", password: "" },
{ countryoperator: "NZ - DigitalIsland", apn: "internet.telecom.co.nz", username: "", password: "" },
{ countryoperator: "NZ - Farmside", apn: "www.farmside.co.nz", username: "", password: "" },
{ countryoperator: "NZ - Orcon", apn: "www.orcon.net.nz", username: "", password: "" },
{ countryoperator: "NZ - Skinny", apn: "wapaccess.co.nz", username: "", password: "" },
{ countryoperator: "NZ - Slingshot", apn: "www.slingshot.net.nz", username: "", password: "" },
{ countryoperator: "NZ - Telecom", apn: "internet.telecom.co.nz", username: "", password: "" },
{ countryoperator: "NZ - Telecom (direct.telecom.co.nz)", apn: "direct.telecom.co.nz", username: "", password: "" },
{ countryoperator: "NZ - Telecom (One Office)", apn: "oa.telecom.co.nz", username: "", password: "" },
{ countryoperator: "NZ - TelstraClear", apn: "www.telstraclear.net.nz", username: "", password: "" },
{ countryoperator: "NZ - TravelSIM", apn: "Travelsim", username: "", password: "" },
{ countryoperator: "NZ - Vodafone", apn: "www.vodafone.net.nz", username: "", password: "" },
{ countryoperator: "OM - Nawras", apn: "isp.nawras.com.om", username: "", password: "" },
{ countryoperator: "OM - Oman Mobile (internet)", apn: "internet", username: "", password: "" },
{ countryoperator: "OM - Oman Mobile (taif)", apn: "taif", username: "taif", password: "taif" },
{ countryoperator: "PA - Cable & Wireless", apn: "apn01.cwpanama.com.pa", username: "", password: "" },
{ countryoperator: "PA - Claro", apn: "web.claro.com.pa", username: "claro", password: "claro" },
{ countryoperator: "PA - Digicel", apn: "web.digicelpanama.com", username: "", password: "" },
{ countryoperator: "PA - Movistar", apn: "internet.movistar.pa", username: "", password: "" },
{ countryoperator: "PE - Claro", apn: "claro.pe", username: "claro", password: "claro" },
{ countryoperator: "PE - Claro (ba.amx)", apn: "ba.amx", username: "amx", password: "amx" },
{ countryoperator: "PE - Movistar", apn: "movistar.pe", username: "movistar@datos", password: "movistar" },
{ countryoperator: "PE - Nextel", apn: "modem.nextel.com.pe", username: "", password: "" },
{ countryoperator: "PE - Nextel (iPad)", apn: "datacard.nextel.com.pe", username: "", password: "" },
{ countryoperator: "PF - Vini", apn: "internet", username: "", password: "" },
{ countryoperator: "PG - Digicel", apn: "internet.digicelpng.com", username: "", password: "" },
{ countryoperator: "PH - ABS-CBNmobile", apn: "internet.abs-cbn.com.ph", username: "", password: "" },
{ countryoperator: "PH - Globe (Postpay)", apn: "internet.globe.com.ph", username: "", password: "" },
{ countryoperator: "PH - Globe (Prepay)", apn: "http.globe.com.ph", username: "", password: "" },
{ countryoperator: "PH - MyGlobal Connect", apn: "www.globe.com.ph", username: "", password: "" },
{ countryoperator: "PH - PLDT-Smart", apn: "weroam", username: "pldt@weroam", password: "pldt" },
{ countryoperator: "PH - Red Mobile", apn: "redinternet", username: "", password: "" },
{ countryoperator: "PH - Smart (LTE Postpaid)", apn: "smartlte", username: "", password: "" },
{ countryoperator: "PH - Smart (Postpaid)", apn: "internet", username: "", password: "" },
{ countryoperator: "PH - Smart (Prepaid)", apn: "smart1", username: "", password: "" },
{ countryoperator: "PH - Sun Cellular (1399 Plan)", apn: "mbband", username: "", password: "" },
{ countryoperator: "PH - Sun Cellular (EasyBroadBand Plan)", apn: "fbband", username: "", password: "" },
{ countryoperator: "PH - Sun Cellular (Prepaid)", apn: "minternet", username: "", password: "" },
{ countryoperator: "PK - Mobilink (Postpaid)", apn: "connect.mobilinkworld.com", username: "", password: "" },
{ countryoperator: "PK - Mobilink (Prepaid)", apn: "jazzconnect.mobilinkworld.com", username: "", password: "" },
{ countryoperator: "PK - Telenor", apn: "internet", username: "Telenor", password: "Telenor" },
{ countryoperator: "PK - Ufone (Postpaid)", apn: "ufone.internet", username: "", password: "" },
{ countryoperator: "PK - Ufone (Prepaid)", apn: "ufone.pinternet", username: "", password: "" },
{ countryoperator: "PK - Warid", apn: "warid", username: "", password: "" },
{ countryoperator: "PK - Zong", apn: "zonginternet", username: "", password: "" },
{ countryoperator: "PL - Aero2", apn: "darmowy", username: "", password: "" },
{ countryoperator: "PL - Aster", apn: "aster.internet", username: "internet", password: "internet" },
{ countryoperator: "PL - Cyfrowy Polsat", apn: "internet.cp", username: "", password: "" },
{ countryoperator: "PL - ERA", apn: "erainternet", username: "erainternet", password: "erainternet" },
{ countryoperator: "PL - Heyah", apn: "heyah.pl", username: "heyah", password: "heyah" },
{ countryoperator: "PL - INEA", apn: "telogic.internet", username: "internet", password: "internet" },
{ countryoperator: "PL - mBank mobile", apn: "www.mobile.pl", username: "", password: "" },
{ countryoperator: "PL - MNI", apn: "mni.internet", username: "mni.internet", password: "" },
{ countryoperator: "PL - Njumobile", apn: "Internet", username: "Internet", password: "Internet" },
{ countryoperator: "PL - Orange", apn: "internet", username: "internet", password: "internet" },
{ countryoperator: "PL - Play", apn: "internet", username: "", password: "" },
{ countryoperator: "PL - PlusGSM", apn: "internet", username: "", password: "" },
{ countryoperator: "PL - PTK", apn: "intranet", username: "", password: "" },
{ countryoperator: "PL - T-Mobile", apn: "internet", username: "", password: "" },
{ countryoperator: "PL - TP", apn: "tp.pl", username: "", password: "" },
{ countryoperator: "PL - Truphone", apn: "truphone.com", username: "", password: "" },
{ countryoperator: "PR - AT&T", apn: "wap.cingular", username: "WAP@CINGULARGPRS.COM", password: "CINGULAR1" },
{ countryoperator: "PR - Claro (internet.claropr.com)", apn: "internet.claropr.com", username: "", password: "" },
{ countryoperator: "PR - Claro (lte.claropr.com)", apn: "lte.claropr.com", username: "", password: "" },
{ countryoperator: "PR - Claro (Prepay)", apn: "wap.claropr.com", username: "", password: "" },
{ countryoperator: "PR - T-Mobile", apn: "internet2.voicestream.com", username: "", password: "" },
{ countryoperator: "PS - Jawwall", apn: "wap", username: "", password: "" },
{ countryoperator: "PT - Lycamobile", apn: "data.lycamobile.pt", username: "lmpt", password: "plus" },
{ countryoperator: "PT - Optimus", apn: "umts", username: "", password: "" },
{ countryoperator: "PT - TMN", apn: "internet", username: "tmn", password: "tmnnet" },
{ countryoperator: "PT - Vodafone", apn: "internet.vodafone.pt", username: "", password: "" },
{ countryoperator: "PT - Vodafone (net2)", apn: "net2.vodafone.pt", username: "vodafone", password: "vodafone" },
{ countryoperator: "PT - Zon Multimedia", apn: "internet.zon.pt", username: "", password: "" },
{ countryoperator: "PY - Claro", apn: "igprs.claro.com.py", username: "", password: "" },
{ countryoperator: "PY - Personal", apn: "internet", username: "", password: "" },
{ countryoperator: "PY - Tigo (broadband)", apn: "broadband.tigo.py", username: "", password: "" },
{ countryoperator: "PY - Tigo (internet)", apn: "internet.tigo.py", username: "", password: "" },
{ countryoperator: "PY - VOX", apn: "vox.internet", username: "vox", password: "vox" },
{ countryoperator: "QA - QTel (gprs.qtel)", apn: "gprs.qtel", username: "", password: "" },
{ countryoperator: "QA - QTel (Web.qtel)", apn: "Web.qtel", username: "", password: "" },
{ countryoperator: "QA - Vodafone", apn: "web.vodafone.com.qa", username: "", password: "" },
{ countryoperator: "RE - SFR", apn: "sl2sfr", username: "", password: "" },
{ countryoperator: "RO - Cosmote (broadband)", apn: "broadband", username: "", password: "" },
{ countryoperator: "RO - Cosmote (internet)", apn: "internet", username: "", password: "" },
{ countryoperator: "RO - Cosmote (WnW)", apn: "wnw", username: "wnw", password: "wnw" },
{ countryoperator: "RO - DIGI.Mobil", apn: "internet", username: "", password: "" },
{ countryoperator: "RO - Indygen", apn: "net.indygen.ro", username: "", password: "" },
{ countryoperator: "RO - Orange", apn: "internet", username: "internet", password: "orange" },
{ countryoperator: "RO - Vodafone (internet.vodafone.ro)", apn: "internet.vodafone.ro", username: "internet.vodafone.ro", password: "vodafone" },
{ countryoperator: "RO - Vodafone (live.pre.vodafone.com)", apn: "live.pre.vodafone.com", username: "live", password: "vodafone" },
{ countryoperator: "RO - Vodafone (live.vodafone.com)", apn: "live.vodafone.com", username: "live", password: "vodafone" },
{ countryoperator: "RS - MTS", apn: "gprsinternet", username: "mts", password: "064" },
{ countryoperator: "RS - Telenor", apn: "internet", username: "telenor", password: "gprs" },
{ countryoperator: "RS - VIP", apn: "vipmobile", username: "vipmobile", password: "vipmobile" },
{ countryoperator: "RU - Akos", apn: "internet.akos.ru", username: "", password: "" },
{ countryoperator: "RU - Beeline", apn: "internet.beeline.ru", username: "beeline", password: "beeline" },
{ countryoperator: "RU - BWC", apn: "inet.bwc.ru", username: "", password: "" },
{ countryoperator: "RU - Enisey Telecom", apn: "internet.etk.ru", username: "etk", password: "etk" },
{ countryoperator: "RU - Life", apn: "internet", username: "", password: "" },
{ countryoperator: "RU - Megafon", apn: "internet", username: "", password: "" },
{ countryoperator: "RU - MTC", apn: "internet.mts.ru", username: "", password: "" },
{ countryoperator: "RU - NTC", apn: "internet.ntc", username: "", password: "" },
{ countryoperator: "RU - Tele2", apn: "internet.tele2.ru", username: "", password: "" },
{ countryoperator: "RU - U-tel", apn: "internet.usi.ru", username: "", password: "" },
{ countryoperator: "RW - MTN", apn: "internet.mtn", username: "", password: "" },
{ countryoperator: "RW - Tigo", apn: "web.tigo.rw", username: "", password: "" },
{ countryoperator: "SA - Mobily (postpaid)", apn: "web1", username: "", password: "" },
{ countryoperator: "SA - Mobily (prepaid)", apn: "web2", username: "", password: "" },
{ countryoperator: "SA - STC", apn: "jawalnet.com.sa", username: "", password: "" },
{ countryoperator: "SA - STC (afaqwireless.com)", apn: "afaqwireless.com", username: "", password: "" },
{ countryoperator: "SA - Zain", apn: "zain", username: "", password: "" },
{ countryoperator: "SB - Breeze", apn: "internet", username: "", password: "" },
{ countryoperator: "SC - Cable & Wireless", apn: "internet", username: "", password: "" },
{ countryoperator: "SD - Mobitel", apn: "internet", username: "", password: "" },
{ countryoperator: "SD - MTN", apn: "internet1", username: "", password: "" },
{ countryoperator: "SD - Sudani", apn: "sudaninet", username: "sudani", password: "sudani" },
{ countryoperator: "SD - Zain", apn: "internet", username: "", password: "" },
{ countryoperator: "SD - Zain (zsat)", apn: "zsat", username: "", password: "" },
{ countryoperator: "SE - Tele2 (internet.tele2.se)", apn: "internet.tele2.se", username: "", password: "" },
{ countryoperator: "SE - Tele2 (surf.tele2.se)", apn: "surf.tele2.se", username: "", password: "" },
{ countryoperator: "SE - Telia", apn: "online.telia.se", username: "", password: "" },
{ countryoperator: "SE - Telnor", apn: "services.telenor.se", username: "", password: "" },
{ countryoperator: "SG - M1 (Postpaid)", apn: "sunsurf", username: "65", password: "65" },
{ countryoperator: "SG - M1 (Prepaid)", apn: "prepaidbb", username: "", password: "" },
{ countryoperator: "SG - SingTel (hicard)", apn: "hicard", username: "", password: "" },
{ countryoperator: "SG - SingTel (Postpaid)", apn: "e-ideas", username: "65ideas", password: "65ideas" },
{ countryoperator: "SG - SingTel (Prepaid)", apn: "hi-internet", username: "", password: "" },
{ countryoperator: "SG - Starhub", apn: "shwap", username: "", password: "" },
{ countryoperator: "SG - Starhub (Prepaid)", apn: "shppd", username: "star", password: "hub" },
{ countryoperator: "SG - Starhub (shinternet)", apn: "shinternet", username: "", password: "" },
{ countryoperator: "SI - Africell", apn: "africell.sl", username: "", password: "" },
{ countryoperator: "SI - BOB", apn: "internet.bob.si", username: "bob", password: "internet" },
{ countryoperator: "SI - Mobitel", apn: "internet", username: "mobitel", password: "internet" },
{ countryoperator: "SI - Simobil", apn: "internet.simobil.si", username: "simobil", password: "internet" },
{ countryoperator: "SI - TUS Mobile", apn: "internet.tusmobil.si", username: "tusmobil", password: "internet" },
{ countryoperator: "SK - Globtel", apn: "internet", username: "", password: "" },
{ countryoperator: "SK - Orange", apn: "internet", username: "wap", password: "wap" },
{ countryoperator: "SK - T-Mobile", apn: "internet", username: "", password: "" },
{ countryoperator: "SK - Telefonia O2", apn: "o2internet", username: "", password: "" },
{ countryoperator: "SK - Telekom", apn: "internet", username: "", password: "" },
{ countryoperator: "SN - Expresso", apn: "expresso", username: "", password: "" },
{ countryoperator: "SR - Digicel", apn: "web.digicelsr.com", username: "", password: "" },
{ countryoperator: "SR - TeleG", apn: "win.teleg.sr", username: "", password: "" },
{ countryoperator: "SR - UNIQA", apn: "3Gprep.uniqa.sr", username: "", password: "" },
{ countryoperator: "SV - Claro", apn: "internet.ideasclaro", username: "", password: "" },
{ countryoperator: "SV - Digicel", apn: "web.digicelsv.com", username: "", password: "" },
{ countryoperator: "SV - Movistar", apn: "internet.movistar.sv", username: "movistarsv", password: "movistarsv" },
{ countryoperator: "SV - Tigo", apn: "internet.tigo.sv", username: "", password: "" },
{ countryoperator: "SY - MTN", apn: "Internet", username: "", password: "" },
{ countryoperator: "SY - Syriatel", apn: "net.syriatel.com", username: "", password: "" },
{ countryoperator: "SZ - MTN", apn: "internet", username: "", password: "" },
{ countryoperator: "SZ - MTN (mymtn.co.sz)", apn: "mymtn.co.sz", username: "", password: "" },
{ countryoperator: "TH - AIS", apn: "internet", username: "", password: "" },
{ countryoperator: "TH - AIS (Staff)", apn: "feb", username: "", password: "" },
{ countryoperator: "TH - DTAC", apn: "www.dtac.co.th", username: "", password: "" },
{ countryoperator: "TH - True Cell", apn: "internet", username: "true", password: "true" },
{ countryoperator: "TH - TrueMove", apn: "internet", username: "TRUE", password: "TRUE" },
{ countryoperator: "TH - TrueMove H", apn: "hinternet", username: "true", password: "true" },
{ countryoperator: "TJ - Beeline", apn: "internet.beeline.tj", username: "beeline", password: "beeline" },
{ countryoperator: "TM - Altyn Asyr", apn: "gprs.tmcell", username: "", password: "" },
{ countryoperator: "TM - Musl", apn: "net.mts.tm", username: "", password: "" },
{ countryoperator: "TN - Orange", apn: "weborange", username: "", password: "" },
{ countryoperator: "TN - Tunisiana", apn: "internet.tunisiana.com", username: "internet", password: "internet" },
{ countryoperator: "TN - Tunisie Telecom (internet.tn)", apn: "internet.tn", username: "gprs", password: "gprs" },
{ countryoperator: "TN - Tunisie Telecom (mobinet)", apn: "mobinet", username: "gprs", password: "gprs" },
{ countryoperator: "TR - Avea", apn: "internet", username: "", password: "" },
{ countryoperator: "TR - Aycell", apn: "aycell", username: "", password: "" },
{ countryoperator: "TR - Telsim", apn: "telsim", username: "", password: "" },
{ countryoperator: "TR - Turkcell", apn: "internet", username: "", password: "" },
{ countryoperator: "TR - Vodafone", apn: "vodafone", username: "", password: "" },
{ countryoperator: "TT - BMobile (Postpaid)", apn: "internet", username: "", password: "" },
{ countryoperator: "TT - BMobile (Prepaid)", apn: "bconnected", username: "", password: "" },
{ countryoperator: "TT - Digicel", apn: "web.digiceltt.com", username: "", password: "" },
{ countryoperator: "TW - Chunghwa", apn: "internet", username: "", password: "" },
{ countryoperator: "TW - Far EasTone (fetims)", apn: "fetims", username: "", password: "" },
{ countryoperator: "TW - Far EasTone (fetnet01)", apn: "fetnet01", username: "", password: "" },
{ countryoperator: "TW - Taiwan Mobile", apn: "Internet", username: "", password: "" },
{ countryoperator: "TZ - Airtel", apn: "internet", username: "", password: "" },
{ countryoperator: "TZ - Tigo", apn: "tigoweb", username: "", password: "" },
{ countryoperator: "TZ - Vodacom", apn: "Internet", username: "", password: "" },
{ countryoperator: "UA - Beeline", apn: "internet.beeline.ua", username: "", password: "" },
{ countryoperator: "UA - DJuice", apn: "www.djuice.com.ua", username: "", password: "" },
{ countryoperator: "UA - Kyivstar (Postpaid)", apn: "www.kyivstar.net", username: "", password: "" },
{ countryoperator: "UA - Kyivstar (Prepaid)", apn: "www.ab.kyivstar.net", username: "", password: "" },
{ countryoperator: "UA - Life", apn: "internet", username: "", password: "" },
{ countryoperator: "UA - MTS (internet)", apn: "internet", username: "", password: "" },
{ countryoperator: "UA - MTS (www.umc.ca)", apn: "www.umc.ua", username: "", password: "" },
{ countryoperator: "UA - Utel (3g.utel.ua)", apn: "3g.utel.ua", username: "", password: "" },
{ countryoperator: "UA - Utel (unlim.utel.ua)", apn: "unlim.utel.ua", username: "", password: "" },
{ countryoperator: "UG - Airtel", apn: "web.ug.zain.com", username: "", password: "" },
{ countryoperator: "UG - MTN", apn: "yellopix.mtn.co.ug", username: "", password: "" },
{ countryoperator: "UG - Orange", apn: "orange.ug", username: "", password: "" },
{ countryoperator: "UG - Uganda Telecom", apn: "utweb", username: "", password: "" },
{ countryoperator: "UG - Warid", apn: "web.waridtel.co.ug", username: "", password: "" },
{ countryoperator: "UK - abroadband", apn: "mdata.com", username: "mdata@mdata.com", password: "ppp" },
{ countryoperator: "UK - ASDA Mobile", apn: "asdamobiles.co.uk", username: "web", password: "web" },
{ countryoperator: "UK - Brightroam", apn: "data.uk", username: "user", password: "one2one" },
{ countryoperator: "UK - BT Mobile", apn: "btmobile.bt.com", username: "bt", password: "bt" },
{ countryoperator: "UK - BT OnePhone", apn: "internet.btonephone.com", username: "", password: "" },
{ countryoperator: "UK - CTEXcelbiz", apn: "netgprs.com", username: "tsl", password: "tsl" },
{ countryoperator: "UK - Delight Mobile", apn: "internet", username: "", password: "" },
{ countryoperator: "UK - Everything Everywhere", apn: "everywhere", username: "", password: "" },
{ countryoperator: "UK - GiffGaff", apn: "giffgaff.com", username: "giffgaff", password: "password" },
{ countryoperator: "UK - Lebara", apn: "uk.lebara.mobi", username: "web", password: "web" },
{ countryoperator: "UK - Lycamobile", apn: "data.lycamobile.co.uk", username: "lmuk", password: "plus" },
{ countryoperator: "UK - Maxroam", apn: "maxroam.com", username: "maxroam", password: "maxroam" },
{ countryoperator: "UK - Netfuse", apn: "mobiledata", username: "", password: "" },
{ countryoperator: "UK - Now Mobile", apn: "nowmobilenet", username: "", password: "" },
{ countryoperator: "UK - Now Mobile (unmoderated)", apn: "nowmobileplanet", username: "", password: "" },
{ countryoperator: "UK - O2 (Bypass)", apn: "mobile.o2.co.uk", username: "bypass", password: "password" },
{ countryoperator: "UK - O2 (idata.o2.co.uk))", apn: "idata.o2.co.uk", username: "vertigo", password: "password" },
{ countryoperator: "UK - O2 (Pay Monthly)", apn: "mobile.o2.co.uk", username: "", password: "" },
{ countryoperator: "UK - O2 (Payand GO)", apn: "payandgo.o2.co.uk", username: "vertigo", password: "password" },
{ countryoperator: "UK - Orange", apn: "orangeinternet", username: "", password: "" },
{ countryoperator: "UK - Orange (Business)", apn: "internetvpn", username: "", password: "" },
{ countryoperator: "UK - Orange (orangedata)", apn: "orangedata", username: "", password: "" },
{ countryoperator: "UK - Ovivo", apn: "ovivomobile.com", username: "", password: "" },
{ countryoperator: "UK - Piranha Mobile", apn: "openroamer.com", username: "", password: "" },
{ countryoperator: "UK - SimplyRoam", apn: "fast.m2m", username: "", password: "" },
{ countryoperator: "UK - T-mobile", apn: "general.t-mobile.uk", username: "user", password: "tm" },
{ countryoperator: "UK - Talk Talk", apn: "mobile.talktalk.co.uk", username: "", password: "" },
{ countryoperator: "UK - Talkmobile (Pay and Go)", apn: "payg.talkmobile.co.uk", username: "", password: "" },
{ countryoperator: "UK - Talkmobile (Pay Monthly)", apn: "talkmobile.co.uk", username: "", password: "" },
{ countryoperator: "UK - Tesco", apn: "prepay.tesco-mobile.com", username: "tescowap", password: "password" },
{ countryoperator: "UK - Three (3internet)", apn: "3internet", username: "", password: "" },
{ countryoperator: "UK - Three (three.co.uk)", apn: "three.co.uk", username: "guest", password: "guest" },
{ countryoperator: "UK - TPO (Pay As You Go)", apn: "tslpaygnet", username: "", password: "" },
{ countryoperator: "UK - TPO (Pay Monthly)", apn: "tslpaymnet", username: "", password: "" },
{ countryoperator: "UK - Truphone", apn: "truphone.com", username: "", password: "" },
{ countryoperator: "UK - Unicom", apn: "tslpaymoanet", username: "", password: "" },
{ countryoperator: "UK - Vectone", apn: "webuk.mundio.com", username: "", password: "" },
{ countryoperator: "UK - Virgin", apn: "goto.virginmobile.uk", username: "user", password: "" },
{ countryoperator: "UK - Vodafone", apn: "internet", username: "web", password: "web" },
{ countryoperator: "UK - Vodafone (Pay Go)", apn: "PPBUNDLE.INTERNET", username: "web", password: "web" },
{ countryoperator: "UK - Vodafone (PAYG Simply Price)", apn: "SMART", username: "web", password: "web" },
{ countryoperator: "UK - Vodafone (Phone)", apn: "pp.vodafone.co.uk", username: "web", password: "web" },
{ countryoperator: "UK - Wildlife Mobile", apn: "gprsconnect.com", username: "", password: "" },
{ countryoperator: "US - AIO", apn: "ndo", username: "", password: "" },
{ countryoperator: "US - Airfire Mobile", apn: "internet.air.net", username: "", password: "" },
{ countryoperator: "US - Airvoice", apn: "att.mvno", username: "", password: "" },
{ countryoperator: "US - AT&T", apn: "wap.cingular", username: "WAP@CINGULARGPRS.COM", password: "CINGULAR1" },
{ countryoperator: "US - AT&T (Blackberry)", apn: "blackberry.net", username: "", password: "" },
{ countryoperator: "US - AT&T (Blue)", apn: "proxy", username: "", password: "" },
{ countryoperator: "US - AT&T (Broadband)", apn: "Broadband", username: "", password: "" },
{ countryoperator: "US - AT&T (HSPA+)", apn: "phone", username: "", password: "" },
{ countryoperator: "US - AT&T (i2gold)", apn: "i2gold", username: "", password: "" },
{ countryoperator: "US - AT&T (isp.cingular)", apn: "isp.cingular", username: "", password: "" },
{ countryoperator: "US - AT&T (LTE)", apn: "pta", username: "", password: "" },
{ countryoperator: "US - AT&T (PAYG)", apn: "wap.cingular", username: "wap@cingulargprs.com", password: "CINGULAR1" },
{ countryoperator: "US - AT&T (wap.cingular)", apn: "wap.cingular", username: "", password: "" },
{ countryoperator: "US - AT&T MNVO (With Proxy)", apn: "att.mvno", username: "", password: "" },
{ countryoperator: "US - AT&T MVNO", apn: "att.mvno", username: "", password: "" },
{ countryoperator: "US - Black Wireless", apn: "att.mvno", username: "", password: "" },
{ countryoperator: "US - Cellular Abroad", apn: "mobiledata", username: "", password: "" },
{ countryoperator: "US - Centennial Wireless", apn: "private.centennialwireless.com", username: "privuser", password: "priv" },
{ countryoperator: "US - Cincinnati Bell", apn: "wap.gocbw.com", username: "cbw", password: "" },
{ countryoperator: "US - Cingular", apn: "wap.cingular", username: "wap@cingulargprs.com", password: "cingular1" },
{ countryoperator: "US - Cininnati Bell", apn: "web.gocbw.com", username: "", password: "" },
{ countryoperator: "US - Consumer Cellular", apn: "att.mvno", username: "", password: "" },
{ countryoperator: "US - Core Wireless", apn: "corrgprs", username: "", password: "" },
{ countryoperator: "US - ekit", apn: "mobiledata", username: "", password: "" },
{ countryoperator: "US - Fuzion Mobile", apn: "att.mvno", username: "", password: "" },
{ countryoperator: "US - GCI", apn: "web.gci", username: "", password: "" },
{ countryoperator: "US - Gigsky", apn: "openroamer.com", username: "", password: "" },
{ countryoperator: "US - Good2GoMobile", apn: "att.mvno", username: "", password: "" },
{ countryoperator: "US - GoPhone", apn: "wap.cingular", username: "WAP@CINGULARGPRS.COM", password: "CINGULAR1" },
{ countryoperator: "US - GoSmart", apn: "multibrand", username: "", password: "" },
{ countryoperator: "US - H2O Wireless", apn: "att.mvno", username: "", password: "" },
{ countryoperator: "US - Hawk Electronics", apn: "wap.cingular", username: "wap@cingulargprs.com", password: "cingular1" },
{ countryoperator: "US - Hoku Wireless", apn: "multibrand", username: "", password: "" },
{ countryoperator: "US - iwireless", apn: "i2.iwireless.com", username: "", password: "" },
{ countryoperator: "US - Jolt Mobile", apn: "att.mvno", username: "", password: "" },
{ countryoperator: "US - Kindle", apn: "kindleatt1.amazon.com", username: "", password: "" },
{ countryoperator: "US - Lycamobile", apn: "data.lycamobile.com", username: "", password: "" },
{ countryoperator: "US - MetroPCS", apn: "metropcs", username: "", password: "" },
{ countryoperator: "US - Net 10 (AT&T)", apn: "tfdata", username: "", password: "" },
{ countryoperator: "US - Net 10 (att.mvno)", apn: "att.mvno", username: "", password: "" },
{ countryoperator: "US - Net 10 (iPhone)", apn: "tfdata", username: "", password: "" },
{ countryoperator: "US - Net 10 (T-Mobile)", apn: "wap.tracfone", username: "", password: "" },
{ countryoperator: "US - Net 10 (tfdata)", apn: "tfdata", username: "", password: "" },
{ countryoperator: "US - Net 10 (wap.tracfone)", apn: "wap.tracfone", username: "", password: "" },
{ countryoperator: "US - NMU LTE", apn: "campus1bbu", username: "", password: "" },
{ countryoperator: "US - PlatinumTel", apn: "wholesale", username: "", password: "" },
{ countryoperator: "US - Puretalk", apn: "att.mvno", username: "", password: "" },
{ countryoperator: "US - ReadySIM", apn: "roam", username: "", password: "" },
{ countryoperator: "US - Red Pocket", apn: "att.mvno", username: "", password: "" },
{ countryoperator: "US - Red Pocket (LTE)", apn: "PRODATA", username: "", password: "" },
{ countryoperator: "US - Roam Mobility", apn: "roam", username: "", password: "" },
{ countryoperator: "US - Rogers (LTE)", apn: "ltemobile.apn", username: "", password: "" },
{ countryoperator: "US - Simple Mobile", apn: "simple", username: "", password: "" },
{ countryoperator: "US - Solavei", apn: "solavei", username: "", password: "" },
{ countryoperator: "US - Spotmobile", apn: "wholesale", username: "", password: "" },
{ countryoperator: "US - Sprint", apn: "ggsnint.nexteldata.com", username: "", password: "" },
{ countryoperator: "US - Sprint (LTE)", apn: "n.ispn", username: "", password: "" },
{ countryoperator: "US - Straight Talk (New)", apn: "tfdata", username: "", password: "" },
{ countryoperator: "US - Straight Talk (Old)", apn: "att.mvno", username: "", password: "" },
{ countryoperator: "US - T-Mobile", apn: "epc.tmobile.com", username: "", password: "" },
{ countryoperator: "US - T-Mobile (LTE)", apn: "fast.t-mobile.com", username: "", password: "" },
{ countryoperator: "US - T-Mobile (Old)", apn: "internet2.voicestream.com", username: "", password: "" },
{ countryoperator: "US - Telestial", apn: "mobiledata", username: "", password: "" },
{ countryoperator: "US - Telna", apn: "openroamer.com", username: "", password: "" },
{ countryoperator: "US - Tracfone", apn: "att.mnvo", username: "", password: "" },
{ countryoperator: "US - Truphone", apn: "truphone.com", username: "", password: "" },
{ countryoperator: "US - Ultra Mobile", apn: "wholesale", username: "", password: "" },
{ countryoperator: "US - Union Wireless", apn: "smart.com", username: "", password: "" },
{ countryoperator: "US - Verizon", apn: "emgsm.vzw3g.com", username: "", password: "" },
{ countryoperator: "US - Verizon (LTE)", apn: "vzwinternet", username: "", password: "" },
{ countryoperator: "US - Verizon West Area (Static IP)", apn: "we01.vzwstatic", username: "", password: "" },
{ countryoperator: "US - Viaero", apn: "internet.vedge.com", username: "", password: "" },
{ countryoperator: "US - Walmart Family (New)", apn: "fast.t-mobile.com", username: "", password: "" },
{ countryoperator: "US - Walmart Family (OLD)", apn: "web.omwtoday.com", username: "", password: "" },
{ countryoperator: "UY - Ancel (Postpaid)", apn: "gprs.ancel", username: "", password: "" },
{ countryoperator: "UY - Ancel (Prepaid)", apn: "prepago.ancel", username: "BAM", password: "BAM" },
{ countryoperator: "UY - Claro", apn: "igprs.claro.com.uy", username: "clarogprs", password: "clarogprs999" },
{ countryoperator: "UY - Movistar (apnumt)", apn: "apnumt.movistar.com.uy", username: "movistar", password: "movistar" },
{ countryoperator: "UY - Movistar (webapn)", apn: "webapn.movistar.com.uy", username: "movistar", password: "movistar" },
{ countryoperator: "UZ - Beeline", apn: "internet.beeline.uz", username: "beeline", password: "beeline" },
{ countryoperator: "UZ - MTS", apn: "net.mts.uz", username: "mts", password: "mts" },
{ countryoperator: "UZ - UCell", apn: "internet", username: "", password: "" },
{ countryoperator: "VE - Digitel", apn: "gprsweb.digitel.ve", username: "", password: "" },
{ countryoperator: "VE - Mobifone", apn: "m-i090", username: "", password: "" },
{ countryoperator: "VE - MovilNET", apn: "int.movilnet.com.ve", username: "", password: "" },
{ countryoperator: "VE - Movistar", apn: "internet.movistar.ve", username: "", password: "" },
{ countryoperator: "VG - Lime", apn: "pppinternet", username: "", password: "" },
{ countryoperator: "VN - Mobifone", apn: "m-wap", username: "mms", password: "mms" },
{ countryoperator: "VN - Vietnamobile", apn: "internet", username: "", password: "" },
{ countryoperator: "VN - Viettel", apn: "v-internet", username: "", password: "" },
{ countryoperator: "VN - Vinaphone", apn: "m3-world", username: "mms", password: "mms" },
{ countryoperator: "YE - MTN", apn: "fast-internet", username: "net", password: "net" },
{ countryoperator: "YE - Sabafon", apn: "internet", username: "internet", password: "internet" },
{ countryoperator: "YE - YMobile", apn: "ymobile", username: "ymobile", password: "ymobile" },
{ countryoperator: "ZA - Cell C", apn: "internet", username: "", password: "" },
{ countryoperator: "ZA - MTN", apn: "internet", username: "", password: "" },
{ countryoperator: "ZA - Virgin", apn: "vdata", username: "", password: "" },
{ countryoperator: "ZA - Vodacom", apn: "iphone.vodacom.za", username: "", password: "" },
{ countryoperator: "ZA - Vodacom (mobile.is.co.za)", apn: "mobile.is.co.za", username: "", password: "" },
{ countryoperator: "ZM - Airtel", apn: "internet", username: "", password: "" },
{ countryoperator: "ZW - Econet", apn: "econet.net", username: "", password: "" },
{ countryoperator: "ZW - Telecel", apn: "internet", username: "", password: "" }
        ]
    }
});

var wanInterfaceStatisticsConfigModel = Backbone.Model.extend({
    defaults: {
        disableRender: 'false',
        BytesSent: '',
        CurrentUploadSpeed: '',
        BytesReceived: '',
        CurrentDownloadSpeed: '',
        TotalTrafficWarningMB: '',

        modemstatus: 'not available',
        detailedStatusMobile: [{ title: "", data: "" },
                        { title: "", data: ""}],

        visibleWanWifiNetworks: [],
        status: "",
        dhcpStatus: "",
        detailedStatus: [{ title: "", data: "" },
                         { title: "", data: ""}]
    }
});

var SetupScreenView = Backbone.View.extend({
    initialize: function () {
        this.template = $('#list-template').children();
        this.model.bind('change', this.render, this);
    },
    el: '#container',
    events: {
        'click button': 'render'
    },
    render: function () {
        $('#password').val(this.model.get('password'));
        $('#wifiPower').val(this.model.get('wifiPower'));
        $('#wifiPowerVN').val(this.model.get('wifiPowerVN'));

        var wifiextenders = this.model.get('wifiextenders');
        var hrefTemplate = _.template('<div class="locoInGroupButton">Serial <%= serial %>  <%= ip %></div>');
        $('#wifiExtenders div').remove();
        for (var i = 0, l = wifiextenders.length; i < l; i++) {
            var link = hrefTemplate({ serial: wifiextenders[i].serial, ip: wifiextenders[i].ip });
            $('#wifiExtenders').append(link);
        }


        var hrefTemplatePortForward = _.template('<button type="button" class="btn btn-block btn-inverse" style="margin-top:5px;" data-toggle="collapse" data-target="#portForward<%= i %>" ><table style="width:100%"><tr><td style="width:99%; text-align:left"><%= comment %></td><td style="width:99%; text-align:right"><%= cloudPort %></td></tr></table></button><div class="collapse" id="portForward<%= i %>"><br /><table style="width:100%"><tr><td style="width:99%;"><%= deviceIP %>:<%= devicePort %></td><td><button class="btn btn-inverse" type="button" data-toggle="collapse" data-target="#portForwardDeleteConfirm<%= i %>"  >Delete</button></td></tr></table><div class="collapse" id="portForwardDeleteConfirm<%= i %>"><button class="btn btn-danger" type="button" onclick="javascript:DeletePortForward(\'<%= cloudPort %>\')" >Confirm </button></div><br /><table style="width:100%" id="tablePortForwardWans<%= i %>"></table></div>');

        var hrefTemplatePortForwardWANSEnabled = _.template('<tr><td style="width:80%"><%= title %></td><td><div class="btn-group" style="display: inline"><a href="javascript:SetPortForwardState(\'<%= interface %>\', \'<%= cloudPort %>\',  \'enable\')" class="btn btn-small btn-info" id="portForwardEnabled">On</a><a href="javascript:SetPortForwardState(\'<%= interface %>\', \'<%= cloudPort %>\', \'disable\')" class="btn btn-small btn-inverse" id="portForwardDisabled">Off</a></div></td></tr>');
        var hrefTemplatePortForwardWANSDisabled = _.template('<tr><td style="width:80%"><%= title %></td><td><div class="btn-group" style="display: inline"><a href="javascript:SetPortForwardState(\'<%= interface %>\', \'<%= cloudPort %>\',  \'enable\')" class="btn btn-small btn-inverse" id="portForwardEnabled">On</a><a href="javascript:SetPortForwardState(\'<%= interface %>\', \'<%= cloudPort %>\', \'disable\')" class="btn btn-small btn-info" id="portForwardDisabled">Off</a></div></td></tr>');

        $('#idPortForwards div').remove();
        $('#idPortForwards button').remove();


        var portForwards = this.model.get('portForwards');
        for (var i = 0; i < portForwards.length; i++) {
            var link = hrefTemplatePortForward({ i: i, comment: portForwards[i].comment, cloudPort: portForwards[i].cloudPort, deviceIP: portForwards[i].deviceIP, devicePort: portForwards[i].devicePort });
            $('#idPortForwards').append(link);
            for (var j = 0; j < portForwards[i].wans.length; j++) {
                var newRow = '';
                if (portForwards[i].wans[j].enabled == 'True') {
                    newRow = hrefTemplatePortForwardWANSEnabled({ title: portForwards[i].wans[j].title, cloudPort: portForwards[i].cloudPort, interface: portForwards[i].wans[j].interface });
                } else {
                    newRow = hrefTemplatePortForwardWANSDisabled({ title: portForwards[i].wans[j].title, cloudPort: portForwards[i].cloudPort, interface: portForwards[i].wans[j].interface });
                }

                $("#tablePortForwardWans" + i).append(newRow);
            }
        }
    }
});

var wanInterfaceStatisticsConfigView = Backbone.View.extend({
    initialize: function () {
        this.template = $('#list-template').children();
        this.model.bind('change', this.render, this);
    },
    el: '#container',
    events: {
        'click button': 'render'
    },
    render: function () {
        if (this.model.get('disableRender') == 'false') {
            $('#BytesSent').html(this.model.get('BytesSent') + " Bytes");
            $('#MegaBytesSent').html(Math.round(parseInt(this.model.get('BytesSent')) / 1024 / 1024) + " MegaBytes");
            $('#CurrentUploadSpeed').html(this.model.get('CurrentUploadSpeed'));
            $('#BytesReceived').html(this.model.get('BytesReceived') + " Bytes");
            $('#MegaBytesReceived').html(Math.round(parseInt(this.model.get('BytesReceived')) / 1024 / 1024) + " MegaBytes");
            $('#CurrentDownloadSpeed').html(this.model.get('CurrentDownloadSpeed'));
            $('#TotalTrafficWarningMB').html(this.model.get('TotalTrafficWarningMB'));

            $("#modemStatus").html(this.model.get('modemstatus'));
            $("#wifiStatus").html(decodeSSID(this.model.get('status')));
            $("#dhcpStatus").html(this.model.get('dhcpStatus'));

            UpdateWanWifiNetworks();
            UpdateWanWifiDetailedStatus();
            UpdateWanMobileDetailedStatus();
        }
    }
});

var LockScreenView = Backbone.View.extend({
    initialize: function () {
        this.template = $('#list-template').children();
        this.model.bind('change', this.render, this);
    },
    el: '#container',
    events: {
        'click button': 'render'
    },
    render: function () {
        //        alert(GetMetaValue("appBrand"));
        //        alert(GetMetaValue("originalTitle"));
        var ConnectedMessage = "Connected to " + GetMetaValue("appBrand");
        if (this.model.get('routerConnected') == "True") {
            SetLockPassword(this.model.get('lockPassword'), this.model.get('defaultPassword'));
            if ($('#connectingStatus').html() != ConnectedMessage) {
                $('#connectingStatus').html(ConnectedMessage);
                $('#loginButton').css("visibility", "visible");
                $('#recoveryShowButton').css("visibility", "collapse");
            }
        } else if (this.model.get('routerConnected') == "WanWifiMissing") {
            //            SetRecoveryPassword(this.model.get('lockPassword'), this.model.get('defaultPassword'));
            //            $('#recoveryShowButton').css("visibility", "visible");
            //            $('#connectingStatus').html("Vessel to Shore WIFI Booster<br />NOT FOUND<br /><br />Connecting...");
            //            $('#loginButton').css("visibility", "collapse");
            //            SetLockPassword(this.model.get('lockPassword'), this.model.get('defaultPassword'));
            if ($('#connectingStatus').html() != ConnectedMessage) {
                SetLockPassword(this.model.get('lockPassword'), this.model.get('defaultPassword'));
                $('#connectingStatus').html("Vessel to Shore WIFI Booster<br />NOT FOUND<br /><br />Connect anyway");
                $('#loginButton').css("visibility", "visible");
                $('#recoveryShowButton').css("visibility", "collapse");
            }
        } else if (this.model.get('routerConnected') == "MobileExpanderMissing") {
            //            SetRecoveryPassword(this.model.get('lockPassword'), this.model.get('defaultPassword'));
            //            $('#recoveryShowButton').css("visibility", "visible");
            //            $('#connectingStatus').html("Vessel to Shore WIFI Booster<br />NOT FOUND<br /><br />Connecting...");
            //            $('#loginButton').css("visibility", "collapse");
            //            SetLockPassword(this.model.get('lockPassword'), this.model.get('defaultPassword'));
            if ($('#connectingStatus').html() != ConnectedMessage) {
                SetLockPassword(this.model.get('lockPassword'), this.model.get('defaultPassword'));
                $('#connectingStatus').html("Mobile Expander <br />NOT FOUND<br /><br />Connect anyway");
                $('#loginButton').css("visibility", "visible");
                $('#recoveryShowButton').css("visibility", "collapse");
            }
        } else {
            $('#connectingStatus').html("Connecting...");
            $('#loginButton').css("visibility", "collapse");
            $('#recoveryShowButton').css("visibility", "collapse");
        }
    }
});


var wanInterfaceConfigView = Backbone.View.extend({
    initialize: function () {
        this.template = $('#list-template').children();
        this.model.bind('change', this.render, this);
    },
    el: '#container',
    events: {
        'click button': 'render'
    },
    render: function () {
        $('#wanInterfaceName').val(this.model.get('name'));

        if (this.model.get('internetAvailable') == "True") {
            $('#wanInternetAvailable').html("Available&nbsp;<i class='icon-refresh icon-white'></i>");
            //$('#wanInternetAvailable').attr("class", "label label-success");
            $('#wanInternetAvailable').attr("class", "btn btn-small btn-success");
        }
        if (this.model.get('internetAvailable') == "False") {
            $('#wanInternetAvailable').html("Unavailable&nbsp;<i class='icon-refresh icon-white'></i>");
            //$('#wanInternetAvailable').attr("class", "label label-warning");
            $('#wanInternetAvailable').attr("class", "btn btn-small btn-warning");
        }
        if (this.model.get('internetAvailable') == "checking") {
            $('#wanInternetAvailable').html("Checking...&nbsp;<i class='icon-time icon-white'></i>");
            //$('#wanInternetAvailable').attr("class", "label label-warning");
            $('#wanInternetAvailable').attr("class", "btn btn-small btn-inverse");
        }
        if (this.model.get('enabled') == 'enabled') {
            $('#wanEnabled').attr("class", "btn btn-small btn-info");
            $('#wanDisabled').attr("class", "btn btn-small btn-inverse");
        } else {
            $('#wanEnabled').attr("class", "btn btn-small btn-inverse");
            $('#wanDisabled').attr("class", "btn btn-small btn-info");
        }

        if (this.model.get('cloudAvailable').toLowerCase() == 'false') {
            $('#tableCloudControls').css("display", "none");
        } else {
            $('#tableCloudControls').css("display", "inline");
            if (this.model.get('cloudEnabled') == "enabled") {
                $('#cloudEnabled').attr("class", "btn btn-small btn-info");
                $('#cloudDisabled').attr("class", "btn btn-small btn-inverse");
                if (this.model.get('cloudConnected').toLowerCase() == "true") {
                    $('#idCloudTitle').attr("class", "label label-success");
                }
                if (this.model.get('cloudConnected').toLowerCase() == "false") {
                    $('#idCloudTitle').attr("class", "label label-warning");
                }
            } else {
                $('#cloudEnabled').attr("class", "btn btn-small btn-inverse");
                $('#cloudDisabled').attr("class", "btn btn-small btn-info");
            }

            $('#idCloudTitle').html(this.model.get("cloudTitle"));
        }
        $("#monitortext").html("Setting SSID from JS Cache: " + this.model.get('wanwifinetworkssid'));
        $('#WanWifiNetworkSSID').val(decodeSSID(this.model.get('wanwifinetworkssid')));
        $('#WanWifiNetworkPassword').val(this.model.get('wanwifinetworkpassword'));
        ShowWepState(this.model.get('wanwifinetworkusewep'));
        ShowKeepAliveState(this.model.get('keepalive'));

        ShowUseWIFIBand(this.model.get('wanwifiselectbandavailable'));
        ShowWIFIBand(this.model.get('wanwifiselectedband'));
        ShowWepHiddenState(this.model.get('wanwifiwephidden'));


        //alert($('#ip').val() + " " + this.model.get('ip'));
        $('#ip').val(this.model.get('ip'));
        $('#subnet').val(this.model.get('subnet'));
        $('#gateway').val(this.model.get('gateway'));
        $('#dns1').val(this.model.get('dns1'));
        $('#dns2').val(this.model.get('dns2'));

        $('#apn').val(this.model.get('apn'));
        $('#pin').val(this.model.get('pin'));
        $('#phone').val(this.model.get('phone'));
        $('#user').val(this.model.get('user'));
        $('#password').val(this.model.get('password'));
        $('#modeminit').val(this.model.get('modeminit'));

        if (this.model.get('modeminit') == "AT^SYSCONFIG=16,3,0,4") {
            ShowRoamingStatus("false");
        } else {
            ShowRoamingStatus("true");
        }

        if (this.model.get('reloadsimavailable') == "True") $('#reloadsimcard').css("visibility", "visible");
        else $('#reloadsimcard').css("visibility", "collapse");

        if (this.model.get('showWifiScan') == "True") $('#wifiscancontrols').css('display', 'block');
        else $('#wifiscancontrols').css('display', 'none');

        if (this.model.get('showMobileConfig') == "True") {
            $('#mobileArea').css('display', 'block');
            $('#updateStaticIpAddress').css("visibility", "collapse");
            $("#ip").prop("readonly", true);
            $("#subnet").prop("readonly", true);
            $("#gateway").prop("readonly", true);
            $("#dns1").prop("readonly", true);
            $("#dns2").prop("readonly", true);
            $("#ip").prop("disabled", true);
            $("#subnet").prop("disabled", true);
            $("#gateway").prop("disabled", true);
            $("#dns1").prop("disabled", true);
            $("#dns2").prop("disabled", true);
        } else {
            $('#mobileArea').css('display', 'none');
            $('#updateStaticIpAddress').css("visibility", "block");
            $("#ip").prop("readonly", false);
            $("#subnet").prop("readonly", false);
            $("#gateway").prop("readonly", false);
            $("#dns1").prop("readonly", false);
            $("#dns2").prop("readonly", false);
            $("#ip").prop("disabled", false);
            $("#subnet").prop("disabled", false);
            $("#gateway").prop("disabled", false);
            $("#dns1").prop("disabled", false);
            $("#dns2").prop("disabled", false);         
        }

        if (this.model.get('showDhcpConfig') == "True") $('#dhcpArea').css('display', 'block');
        else $('#dhcpArea').css('display', 'none');

        SetMobileNetworkModeButtons(this.model.get('networkMode'));

        if (this.model.get('dhcpChecking') == "False") {
            $('#dhcp_refresh').html("Refresh&nbsp;<i class='icon-refresh'></i>");
        } else {
            $('#dhcp_refresh').html("Checking...&nbsp;<i class='icon-time'></i>");
        }

        if (this.model.get('dhcp_enabled') == "True") {
            $('#dhcp_on').attr("class", "btn btn-info");
            $('#dhcp_off').attr("class", "btn btn-inverse");
        } else {
            $('#dhcp_on').attr("class", "btn btn-inverse");
            $('#dhcp_off').attr("class", "btn btn-info");
        }

        var wanUsageAvailable = this.model.get('wanUsageAvailable').toLowerCase();
        if (wanUsageAvailable == "true") {
            var wanUsageScaleMultiplier = 1;
            var wanUsageScaleSuffix = "B";

            if (this.model.get('wanUsageScale').toLowerCase() == "g") {
                wanUsageScaleMultiplier = 1024 * 1024 * 1024;
                $('#wanUsageScaleG').attr("class", "btn btn-small btn-info");
                $('#wanUsageScaleM').attr("class", "btn btn-small btn-inverse");
                $('#wanUsageScaleK').attr("class", "btn btn-small btn-inverse");
                wanUsageScaleSuffix = "GB";
            }else if (this.model.get('wanUsageScale').toLowerCase() == "m") {
                wanUsageScaleMultiplier = 1024 * 1024;
                $('#wanUsageScaleG').attr("class", "btn btn-small btn-inverse");
                $('#wanUsageScaleM').attr("class", "btn btn-small btn-info");
                $('#wanUsageScaleK').attr("class", "btn btn-small btn-inverse");
                wanUsageScaleSuffix = "MB";
            }else if (this.model.get('wanUsageScale').toLowerCase() == "k") {
                wanUsageScaleMultiplier = 1024;
                $('#wanUsageScaleG').attr("class", "btn btn-small btn-inverse");
                $('#wanUsageScaleM').attr("class", "btn btn-small btn-inverse");
                $('#wanUsageScaleK').attr("class", "btn btn-small btn-info");
                wanUsageScaleSuffix = "KB";
            }


            $('#wanUsageLastReset').html(this.model.get('wanUsageLastReset'));
            $('#wanUsage_RX').html(roundToTwo(this.model.get('wanUsage_RX') / wanUsageScaleMultiplier) + " " + wanUsageScaleSuffix);
            $('#wanUsage_TX').html(roundToTwo(this.model.get('wanUsage_TX') / wanUsageScaleMultiplier) + " " + wanUsageScaleSuffix);
            $('#wanUsageLimit').val(roundToTwo(this.model.get('wanUsageLimit') / wanUsageScaleMultiplier));
            $('#wanUsageWarning').val(roundToTwo(this.model.get('wanUsageWarning') / wanUsageScaleMultiplier));

            if (this.model.get('wanUsageLimitEnabled').toLowerCase() == 'true') {
                $('#wanLimitEnabled').attr("class", "btn btn-small btn-info");
                $('#wanLimitDisabled').attr("class", "btn btn-small btn-inverse");
            } else {
                $('#wanLimitEnabled').attr("class", "btn btn-small btn-inverse");
                $('#wanLimitDisabled').attr("class", "btn btn-small btn-info");
            }

            if (this.model.get('wanUsageWarningEnabled').toLowerCase() == 'true') {
                $('#wanWarningEnabled').attr("class", "btn btn-small btn-info");
                $('#wanWarningDisabled').attr("class", "btn btn-small btn-inverse");
            } else {
                $('#wanWarningEnabled').attr("class", "btn btn-small btn-inverse");
                $('#wanWarningDisabled').attr("class", "btn btn-small btn-info");
            }

            if (this.model.get('wanUsageAutoresetEnabled').toLowerCase() == 'true') {
                $('#wanLimitAutoresetEnabled').attr("class", "btn btn-small btn-info");
                $('#wanLimitAutoresetDisabled').attr("class", "btn btn-small btn-inverse");
            } else {
                $('#wanLimitAutoresetEnabled').attr("class", "btn btn-small btn-inverse");
                $('#wanLimitAutoresetDisabled').attr("class", "btn btn-small btn-info");
            }
            $('#trueTrafficArea').css("visibility", "inherit");
            $('#trueTrafficArea').css("display", "inherit");
            $('#trafficArea').css("visibility", "collapse");
            $('#trafficArea').css("display", "none");
        } else if (wanUsageAvailable == "false") {
            $('#trueTrafficArea').css("visibility", "collapse");
            $('#trueTrafficArea').css("display", "none");
            $('#trafficArea').css("visibility", "inherit");
            $('#trafficArea').css("display", "inherit");

        }



        var apn_list = this.model.get('apn_list');
        var apnListObj = document.getElementById('apnList');
        var apnCountryObj = document.getElementById('apnCountry');
        apnListObj.options.length = 0;
        apnCountryObj.options.length = 0;

        var lastCountry = "-";
        for (var i = 0; i < apn_list.length; i++) {
            var countryPart = apn_list[i].countryoperator.split("-")[0];
            if (lastCountry != countryPart) {
                lastCountry = countryPart;
                //apnListObj.options[apnListObj.options.length] = new Option(apn_list[i].countryoperator, apn_list[i].apn + "#" + apn_list[i].username + "#" + apn_list[i].password);
                apnCountryObj.options[apnCountryObj.options.length] = new Option(countryPart, countryPart);
            }
        }
    }
});

function roundToTwo(num) {
    return numberWithCommas(+(Math.round(num + "e+2") + "e-2"));
}

function numberWithCommas(x) {
    var parts = x.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
}

function ShowApnListForCountry(targetCountryPart) {
    var apn_list = wanNetworkConfig.get('apn_list');
    var apnListObj = document.getElementById('apnList');
    apnListObj.options.length = 0;

    apnListObj.options[apnListObj.options.length] = new Option("", "" + "#" + "" + "#" + "");
    for (var i = 0; i < apn_list.length; i++) {
        var countryPart = apn_list[i].countryoperator.split("-")[0];
        var networkPart = apn_list[i].countryoperator.substring(4);
        if (targetCountryPart == countryPart) {
            apnListObj.options[apnListObj.options.length] = new Option(networkPart, apn_list[i].apn + "#" + apn_list[i].username + "#" + apn_list[i].password);
            //apnCountryObj.options[apnCountryObj.options.length] = new Option(countryPart, countryPart);
        }
    }
}

function SetMobileNetworkModeButtons(networkMode) {

    if (networkMode == 'auto') {
        $('#mobileNetworkModeAuto').attr("class", "btn btn-info");
        $('#mobileNetworkModeLte').attr("class", "btn btn-inverse");
        $('#mobileNetworkMode3g').attr("class", "btn btn-inverse");
        $('#mobileNetworkModeGsm').attr("class", "btn btn-inverse");
    } else
        if (networkMode == 'lte') {
            $('#mobileNetworkModeAuto').attr("class", "btn btn-inverse");
            $('#mobileNetworkModeLte').attr("class", "btn btn-info");
            $('#mobileNetworkMode3g').attr("class", "btn btn-inverse");
            $('#mobileNetworkModeGsm').attr("class", "btn btn-inverse");
        } else
            if (networkMode == '3g') {
                $('#mobileNetworkModeAuto').attr("class", "btn btn-inverse");
                $('#mobileNetworkModeLte').attr("class", "btn btn-inverse");
                $('#mobileNetworkMode3g').attr("class", "btn btn-info");
                $('#mobileNetworkModeGsm').attr("class", "btn btn-inverse");
            } else
                if (networkMode == 'gsm') {
                    $('#mobileNetworkModeAuto').attr("class", "btn btn-inverse");
                    $('#mobileNetworkModeLte').attr("class", "btn btn-inverse");
                    $('#mobileNetworkMode3g').attr("class", "btn btn-inverse");
                    $('#mobileNetworkModeGsm').attr("class", "btn btn-info");
                }
}

var WanNetworksConfigView = Backbone.View.extend({
    initialize: function () {
        this.template = $('#list-template').children();
        this.model.bind('change', this.render, this);
    },
    el: '#container',
    events: {
        'click button': 'render'
    },
    render: function () {
        var targetID = this.model.get('vesselNetworkHtmlID');
        UpdateWanInfo(this.model, targetID, 0, 'lanWans');
        UpdateWanInfo(this.model, targetID, 0, 'mobileWans');
        UpdateWanInfo(this.model, targetID, 0, 'wifiWans');
    }
});

var VesselNetworksView = Backbone.View.extend({
    initialize: function () {
        this.template = $('#list-template').children();
        this.model.bind('change', this.render, this);
    },
    el: '#container',
    events: {
        'click button': 'render'
    },
    render: function () {
        var allVesselNetworks = this.model.get('vesselNetworks');
        // <a href="VesselNetworkSetup.html/1" class="btn btn-large btn-block btn-inverse">Owner</a>
        var hrefTemplate = _.template('<a href="javascript:NavigateToVesselNetworkSetup(\'<%= vn %>\')" class="btn btn-large btn-block btn-inverse"><%= name %></a>');
        $('#allVNs a').remove();
        for (var i = 0, l = allVesselNetworks.length; i < l; i++) {
            var link = hrefTemplate({ name: allVesselNetworks[i].name, vn: allVesselNetworks[i].vn });
            $('#allVNs').append(link);
        }
    }
});

function NavigateToVesselNetworkSetup(vn) {
    if (UpdateInProgress == true) return;
    document.location = "http://yachtrouter.com/default.html#SetVN?vn=" + vn;
    //document.location = "VesselNetworkSetup.html";
}
function NavigateToWanSetupScreen(wan) {
    if (UpdateInProgress == true) return;
    document.location = "http://yachtrouter.com/default.html#SetWAN?wan=" + wan;
    //document.location = "WanSetupScreen.html";
}

var VesselNetworkView = Backbone.View.extend({
    initialize: function () {
        this.template = $('#list-template').children();
        this.model.bind('change', this.render, this);
    },
    el: '#container',
    events: {
        'click button': 'render'
    },
    render: function () {
        var name = this.model.get('name');
        var wifi_enabled = this.model.get('wifi_enabled');
        var wifi_ssid = this.model.get('wifi_ssid');
        var wifi_password = this.model.get('wifi_password');
        var dhcpClients = this.model.get('dhcpClients');
        var hotspotUsers = this.model.get('hotspotUsers');

        var hotspot_enabled = this.model.get('hotspot_enabled');
        var hotspot_available = this.model.get('hotspot_available');

        var bandwithTXLimit = this.model.get('bandwithTXLimit');
        var bandwithRXLimit = this.model.get('bandwithRXLimit');
        var bandwithTXEnabled = this.model.get('bandwithTXEnabled');
        var bandwithRXEnabled = this.model.get('bandwithRXEnabled');
        var bandwithScale = this.model.get('bandwithScale');

        var autoswitching_available = this.model.get('autoswtichingAvailable');
        var autoswitching_enabled = this.model.get('autoswtichingEnabled');
        var isolation_enabled = this.model.get('isolationEnabled');
        var isolationAvailable = this.model.get('isolationAvailable').toString().toLowerCase();
        var autoswitching_scripts = this.model.get('autoswitchingScript');
        var autoswitching_selectedscript = this.model.get('autoswtichingSelectedScript');
        $('#name').val(name);
        $('#wifi_ssid').val(wifi_ssid);
        $('#wifi_password').val(wifi_password);


        var vesselNetworkBandwithControlAvailable = this.model.get('bandwithControlAvailable').toString().toLowerCase();
        if (vesselNetworkBandwithControlAvailable == "true") {
            if (bandwithTXEnabled.toLowerCase() == 'true') {
                $('#bandwithTXLimitEnabled').attr("class", "btn btn-small btn-info");
                $('#bandwithTXLimitDisabled').attr("class", "btn btn-small btn-inverse");
            } else {
                $('#bandwithTXLimitEnabled').attr("class", "btn btn-small btn-inverse");
                $('#bandwithTXLimitDisabled').attr("class", "btn btn-small btn-info");
            }

            if (bandwithRXEnabled.toLowerCase() == 'true') {
                $('#bandwithRXLimitEnabled').attr("class", "btn btn-small btn-info");
                $('#bandwithRXLimitDisabled').attr("class", "btn btn-small btn-inverse");
            } else {
                $('#bandwithRXLimitEnabled').attr("class", "btn btn-small btn-inverse");
                $('#bandwithRXLimitDisabled').attr("class", "btn btn-small btn-info");
            }

            if (bandwithScale.toLowerCase() == 'm') {
                $('#bandwithScaleM').attr("class", "btn btn-small btn-info");
                $('#bandwithScaleK').attr("class", "btn btn-small btn-inverse");
                $('#bandwithTXLimit').val(bandwithTXLimit / 1000);
                $('#bandwithRXLimit').val(bandwithRXLimit / 1000);
            } else {
                $('#bandwithScaleK').attr("class", "btn btn-small btn-info");
                $('#bandwithScaleM').attr("class", "btn btn-small btn-inverse");
                $('#bandwithTXLimit').val(bandwithTXLimit);
                $('#bandwithRXLimit').val(bandwithRXLimit);
            }
            $('#BandwithControl').css("display", "visible");
            $('#BandwithControl').css("visibility", "inherit");

        } else if (vesselNetworkBandwithControlAvailable == "false") {
            $('#BandwithControl').css("display", "none");
            $('#BandwithControl').css("visibility", "collapse");
        }

        if (wifi_enabled.toLowerCase() == 'true') {
            $('#wifiEnabled').attr("class", "btn btn-small btn-info");
            $('#wifiDisabled').attr("class", "btn btn-small btn-inverse");
        } else {
            $('#wifiEnabled').attr("class", "btn btn-small btn-inverse");
            $('#wifiDisabled').attr("class", "btn btn-small btn-info");
        }

        if (hotspot_available.toLowerCase() == "false") {
            $('#hotspotDetails').css('display', 'none');
        } else {
            $('#hotspotDetails').css('display', 'block');
        }


        if (this.model.get('interface') == "1") {
            $("#tableWifiEnabledDisabled").css("display", "none");
        } else {
            $("#tableWifiEnabledDisabled").css("display", "block");
        }

        //Client Isolation
        if (isolationAvailable == "false") {
            $("#tableVesselNetworkIsolation").css("display", "none");
        } else {
            $("#tableVesselNetworkIsolation").css("display", "block");
        }
        if (isolation_enabled == 'enabled') {
            $('#isolationEnabled').attr("class", "btn btn-small btn-info");
            $('#isolationDisabled').attr("class", "btn btn-small btn-inverse");
        } else {
            $('#isolationEnabled').attr("class", "btn btn-small btn-inverse");
            $('#isolationDisabled').attr("class", "btn btn-small btn-info");
        }




        //Autoswitcher ----------------------------------------------------------------------
        if (autoswitching_available.toLowerCase() == "false") {
            $("#tableAutoswitcherEnabledDisabled").css("display", "none");
            $("#autoSwitcher").css("display", "none");
        } else {
            $("#tableAutoswitcherEnabledDisabled").css("display", "block");
            $("#autoSwitcher").css("display", "inline");
        }

        if (autoswitching_enabled == 'enabled') {
            $('#autoswitchEnabled').attr("class", "btn btn-small btn-info");
            $('#autoswitchDisabled').attr("class", "btn btn-small btn-inverse");
        } else {
            $('#autoswitchEnabled').attr("class", "btn btn-small btn-inverse");
            $('#autoswitchDisabled').attr("class", "btn btn-small btn-info");
        }


        $('#autoswitcherList button').remove();
        $('#autoswitcherList a').remove();

        for (var i = 0; i < autoswitching_scripts.length; i++) {
            var link = "";
            if (autoswitching_scripts[i].name == autoswitching_selectedscript) {
                link = "<a href=\"javascript:SelectAutoswitchScript('" + autoswitching_scripts[i].name + "')\" class=\"btn btn-small btn-info btn-block\" >" + autoswitching_scripts[i].name + "</a>";
            } else {
                link = "<a href=\"javascript:SelectAutoswitchScript('" + autoswitching_scripts[i].name + "')\" class=\"btn btn-small btn-inverse btn-block\" >" + autoswitching_scripts[i].name + "</a>";
            }
            //alert(link);
            $('#autoswitcherList').append(link);
        }

        //HOTSPOT ----------------------------------------------------------------------
        SetHotspotEnabledButtonStyle(hotspot_enabled);

        var hrefTemplate = _.template('<button type="button" class="btn btn-block" style="margin-top:5px;" data-toggle="collapse" data-target="#user<%= i %>" ><%= name %></button><div class="collapse" id="user<%= i %>"><table style="width:100%"><tr><td>Password: </td><td align="right"><%= password %></td></tr><tr><td>Data usage: </td><td align="right"><%= dataUsed %> of <%= dataLimit %></td></tr><tr><td>Time usage: </td><td align="right"><%= timeUsed %> of <%= timeLimit %></td></tr><tr><td><button class="btn btn-danger" type="button" onclick="javascript:DeleteHotspotUser(\'<%= name %>\')" >Delete User</button></td><td align="right"><button class="btn btn-warning" onclick="javascript:ResetHotspotUserUsage(\'<%= name %>\')" >Reset Usage</button></td></tr></table></div>');

        $('#hotspotUsers button').remove();
        $('#hotspotUsers table').remove();
        $('#hotspotUsers div').remove();

        for (var i = 0; i < hotspotUsers.length; i++) {
            var link = hrefTemplate({ name: hotspotUsers[i].name, password: hotspotUsers[i].password, timeUsed: hotspotUsers[i].timeUsed, timeLimit: hotspotUsers[i].timeLimit, dataUsed: hotspotUsers[i].dataUsed, dataLimit: hotspotUsers[i].dataLimit, i: i });
            //alert(link);
            $('#hotspotUsers').append(link);
        }

        //PORT FORWARDING----------------------------------------------------------------------
        var hrefTemplate = _.template('<a href="#dummy" type="button" class="accordion-toggle" data-toggle="collapse" data-target="#demo<%= id %>"><table width="100%"><tr><td width="50%"><%= host %></td><td width="50%" align="right"><%= ip %></td></tr></table></a><div id="demo<%= id %>" class="collapse"><table width="100%"><tr><td width="50%" align="left"><%= mac %></td><td width="50%" align="right"><%= static %></td></tr></table><a href="javascript:MakeStatic(\'<%= ip%>\')" class="btn btn-warning" type="button">Lock IP</a><a href="javascript:Delete(\'<%= ip%>\')" class="btn btn-danger" type="button">Delete</a><table width="100%"><tr><td><span class="label label-info">Port Forward</span></td></tr><tr><td width="30%">Device Port<input class="locoInputButton" id="idDevicePort<%= id%>" type="text" value="" style="margin:0; display:block; width:90%" /></td><td width="30%" align="right">Public Port&nbsp;<input class="locoInputButton" id="idCloudPort<%= id%>" type="text" value="" style="margin:0; display:block" /></td><td width="40%"></td></tr><tr><td colspan="2" align="left">Comment<input class="locoInputButton" id="idCloudPortComment<%= id%>" type="text" value="" style="margin:0; display:block" /><td width="20%" align="right" valign="bottom"><button class="btn btn-warning" onclick="javascript:AddPortForward(\'<%= ip %>\', \'idDevicePort<%= id%>\', \'idCloudPort<%= id%>\', \'idCloudPortComment<%= id%>\')" >ADD</button></td></tr></table><br />');


        $('#dhcpClients a').remove();
        $('#dhcpClients div').remove();

        for (var i = 0; i < dhcpClients.length; i++) {
            var staticLabel = "";
            if (dhcpClients[i].static == "true") staticLabel = "Locked IP";
            var link = hrefTemplate({ host: dhcpClients[i].host, mac: dhcpClients[i].mac, ip: dhcpClients[i].ip, static: staticLabel, id: i });
            $('#dhcpClients').append(link);
        }

    }
});

var DiagnosticsScreenVesselNetworkWanView = Backbone.View.extend({
    initialize: function () {
        this.template = $('#list-template').children();
        this.model.bind('change', this.render, this);
        InitWanBandwithChart(1);
        InitWanBandwithChart(2);
        InitWanBandwithChart(3);
    },
    el: '#container',
    events: {
        'click button': 'render'
    },
    render: function () {

        var targetID = this.model.get('vesselNetworkHtmlID');
        if (targetID != "") {
            var selectedWan = this.model.get('selectedWan');
            var available = this.model.get('available');
            var name = this.model.get('name');

            var internetAvailable = this.model.get('selectedWanInternetAvailable');
            var internetAvailableIcon = '';
            if (internetAvailable == 'checking') internetAvailableIcon = '&nbsp;<i class="icon-time icon-white"></i>';
            if (internetAvailable == 'disabled') internetAvailableIcon = '';
            if (internetAvailable == 'connected') internetAvailableIcon = '';
            if (internetAvailable == 'nointernet') internetAvailableIcon = '';

            var newStatusClass = "btn btn-large btn-block btn-success";

            if (internetAvailable == 'checking') newStatusClass = "btn btn-large btn-block " + GetInternetStatusButtonColors(internetAvailable);
            if (internetAvailable == 'disabled') newStatusClass = "btn btn-large btn-block " + GetInternetStatusButtonColors(internetAvailable);
            if (internetAvailable == 'connected') newStatusClass = "btn btn-large btn-block " + GetInternetStatusButtonColors(internetAvailable);
            if (internetAvailable == 'nointernet') newStatusClass = "btn btn-large btn-block " + GetInternetStatusButtonColors(internetAvailable);

            $('#' + targetID + '_selectedWan').attr("class", newStatusClass);
            $('#' + targetID + '_name').html(name);
            $('#' + targetID + '_selectedWan').html(selectedWan + internetAvailableIcon);

            if (available == false) {
                $('#' + targetID + '_main').css('display', 'none');
            } else {
                $('#' + targetID + '_main').css('display', 'block');
            }

            $('#' + targetID + '_selectedWanBandwith_TX').html(ParseNetworkNumbers(this.model.get('selectedWanBandwith_TX'), "bit/s"));
            $('#' + targetID + '_selectedWanBandwith_RX').html(ParseNetworkNumbers(this.model.get('selectedWanBandwith_RX'), "bit/s"));

            $('#' + targetID + '_selectedWanUsage_TX').html(ParseNetworkNumbers(this.model.get('selectedWanUsage_TX'), "B"));
            $('#' + targetID + '_selectedWanUsage_RX').html(ParseNetworkNumbers(this.model.get('selectedWanUsage_RX'), "B"));

            if (this.model.get('selectedWanUsageWarningEnabled').toString().toLowerCase() == 'false') {
                $('#' + targetID + '_selectedWanUsageWarning').html('OFF');
            } else {
                $('#' + targetID + '_selectedWanUsageWarning').html(ParseNetworkNumbers(this.model.get('selectedWanUsageWarning'), "B"));
            }
            if (this.model.get('selectedWanUsageLimitEnabled').toString().toLowerCase() == 'false') {
                $('#' + targetID + '_selectedWanUsageLimit').html('OFF');
            } else {
                $('#' + targetID + '_selectedWanUsageLimit').html(ParseNetworkNumbers(this.model.get('selectedWanUsageLimit'), "B"));
            }

            if (this.model.get('vesselNetworkBandwithControlLimitEnabled').toString().toLowerCase() == 'false') {
                $('#' + targetID + '_vesselNetworkBandwithLimitTitle').html('unlimited');
                $('#' + targetID + '_vesselNetworkBandwithLimit_TX').html('');
                $('#' + targetID + '_vesselNetworkBandwithLimit_RX').html('');
            } else {
                $('#' + targetID + '_vesselNetworkBandwithLimitTitle').html('');
                $('#' + targetID + '_vesselNetworkBandwithLimit_TX').html('TX: ' + ParseNetworkNumbers(this.model.get('vesselNetworkBandwithControlLimit_TX'), "bit/s"));
                $('#' + targetID + '_vesselNetworkBandwithLimit_RX').html('RX: ' + ParseNetworkNumbers(this.model.get('vesselNetworkBandwithControlLimit_RX'), "bit/s"));
            }

            if (this.model.get('vesselNetworkAutoswitchEnabled').toString().toLowerCase() == 'false') {
                $('#' + targetID + '_vesselNetworkAutoswitchTitle').html('Status:');
                $('#' + targetID + '_vesselNetworkAutoswitchEnabled').html('OFF');
                $('#' + targetID + '_vesselNetworkAutoswitchScript').html('');
            } else {
                $('#' + targetID + '_vesselNetworkAutoswitchTitle').html('Method:');
                $('#' + targetID + '_vesselNetworkAutoswitchEnabled').html('');
                $('#' + targetID + '_vesselNetworkAutoswitchScript').html(this.model.get('vesselNetworkAutoswitchScript'));
            }

            if (this.model.get('vesselNetworkWifiEnabled').toString().toLowerCase() == 'false') {
                $('#' + targetID + '_vesselNetworkWifiTitle').html('Status:');
                $('#' + targetID + '_vesselNetworkWifiEnabled').html('OFF');
                $('#' + targetID + '_vesselNetworkWifiUsers').html('');
            } else {
                $('#' + targetID + '_vesselNetworkWifiTitle').html('Users:');
                $('#' + targetID + '_vesselNetworkWifiEnabled').html('');
                $('#' + targetID + '_vesselNetworkWifiUsers').html(this.model.get('vesselNetworkWifiUsers'));
            }

            if (this.model.get('vesselNetworkHotspotEnabled').toString().toLowerCase() == 'false') {
                $('#' + targetID + '_vesselNetworkHotspotTitle').html('Status:');
                $('#' + targetID + '_vesselNetworkHotspotEnabled').html('OFF');
                $('#' + targetID + '_vesselNetworkHotspotUsersActive').html('');
                $('#' + targetID + '_vesselNetworkHotspotUsersRegistered').html('');
            } else {
                $('#' + targetID + '_vesselNetworkHotspotTitle').html('Users:');
                $('#' + targetID + '_vesselNetworkHotspotEnabled').html('');
                $('#' + targetID + '_vesselNetworkHotspotUsersActive').html(this.model.get('vesselNetworkHotspotUsersActive'));
                $('#' + targetID + '_vesselNetworkHotspotUsersRegistered').html(' of ' + this.model.get('vesselNetworkHotspotUsersRegistered'));
            }
            //            InitWanBandwithChart(1);
            //            InitWanBandwithChart(2);
            //            InitWanBandwithChart(3);
        }
    }
});

function ParseNetworkNumbers(netNumber, suffix) {
    var response = "";
    if (isNaN(netNumber) || netNumber == "") return "";

    var curNumber = Number(netNumber);
    if (curNumber > 1000000000) {
        curNumber = Math.round(curNumber / 1000000000);
        response = curNumber.toString() + " G" + suffix;
    } else if (curNumber > 1000000) {
        curNumber = Math.round(curNumber / 1000000);
        response = curNumber.toString() + " M" + suffix;
    } else if (curNumber > 1000) {
        curNumber = Math.round(curNumber / 1000);
        response = curNumber.toString() + " K" + suffix;
    } else {
        response = curNumber.toString() + " " + suffix;
    }

    return response;
}


var vesselNetwork_selectedWanBandwithChartData = ['', '', '', ''];
var vesselNetwork_selectedWanBandwithChart = ['', '', '', ''];
var vesselNetwork_selectedWanBandwithChartSendData = [[], [], [], []];
var vesselNetwork_selectedWanBandwithChartReceiveData = [[], [], [], []];
var vesselNetwork_selectedWanBandwithChartLabels = [[], [], [], []];

function InitWanBandwithChart(vesselNetworkID) {
    vesselNetwork_selectedWanBandwithChartData[vesselNetworkID] = {
        labels: vesselNetwork_selectedWanBandwithChartLabels[vesselNetworkID],
        datasets: [
                    {
                        label: "send",
                        backgroundColor: "rgba(255,99,132,0.2)",
                        borderColor: "rgba(255,99,132,1)",
                        borderWidth: 1,
                        hoverBackgroundColor: "rgba(255,99,132,0.4)",
                        hoverBorderColor: "rgba(255,99,132,1)",
                        data: vesselNetwork_selectedWanBandwithChartSendData[vesselNetworkID]
                    },
                    {
                        label: "receive",
                        fill: false,
                        lineTension: 0.1,
                        backgroundColor: "rgba(75,192,192,0.4)",
                        borderColor: "rgba(75,192,192,1)",
                        borderCapStyle: 'butt',
                        borderDash: [],
                        borderDashOffset: 0.0,
                        borderJoinStyle: 'miter',
                        pointBorderColor: "rgba(75,192,192,1)",
                        pointBackgroundColor: "#fff",
                        pointBorderWidth: 1,
                        pointHoverRadius: 5,
                        pointHoverBackgroundColor: "rgba(75,192,192,1)",
                        pointHoverBorderColor: "rgba(220,220,220,1)",
                        pointHoverBorderWidth: 2,
                        pointRadius: 1,
                        pointHitRadius: 10,
                        data: vesselNetwork_selectedWanBandwithChartReceiveData[vesselNetworkID]
                    }
                ]
    };
    var ctx = document.getElementById('vesselNetwork' + vesselNetworkID + '_selectedWanBandwithChartCanvas').getContext('2d');
    vesselNetwork_selectedWanBandwithChart[vesselNetworkID] = new Chart(ctx, {
        type: 'line',
        data: vesselNetwork_selectedWanBandwithChartData[vesselNetworkID],
        options: {
            xAxes: [{
                display: false
            }]
        }
    });

}

function AddSelectedWanBandwithChartData(vesselNetworkID, newSendData, newReceiveData, newLabel) {
    vesselNetwork_selectedWanBandwithChartSendData[vesselNetworkID].push(newSendData);
    vesselNetwork_selectedWanBandwithChartReceiveData[vesselNetworkID].push(newReceiveData);
    vesselNetwork_selectedWanBandwithChartLabels[vesselNetworkID].push(newLabel);
    if (vesselNetwork_selectedWanBandwithChartSendData[vesselNetworkID].length > 30) {
        vesselNetwork_selectedWanBandwithChartSendData[vesselNetworkID].shift();
        vesselNetwork_selectedWanBandwithChartReceiveData[vesselNetworkID].shift();
        vesselNetwork_selectedWanBandwithChartLabels[vesselNetworkID].shift();
    }
    vesselNetwork_selectedWanBandwithChart[vesselNetworkID].update();
}

var VesselNetworkWanView = Backbone.View.extend({
    initialize: function () {
        this.template = $('#list-template').children();
        this.model.bind('change', this.render, this);
    },
    el: '#container',
    events: {
        'click button': 'render'
    },
    render: function () {
        var targetID = this.model.get('vesselNetworkHtmlID');
        if (targetID != "") {
            var selectedWan = this.model.get('selectedWan');
            var available = this.model.get('available');
            var name = this.model.get('name');

            var internetAvailable = this.model.get('internetAvailable');
            var internetAvailableIcon = '';
            if (internetAvailable == 'checking') internetAvailableIcon = '&nbsp;<i class="icon-time icon-white"></i>';
            if (internetAvailable == 'disabled') internetAvailableIcon = '';
            if (internetAvailable == 'connected') internetAvailableIcon = '';
            if (internetAvailable == 'nointernet') internetAvailableIcon = '';

            //            if (internetAvailable == 'checking') internetAvailableIcon = '&nbsp;<i class="icon-time icon-white"></i>';
            //            if (internetAvailable == 'disabled') internetAvailableIcon = '&nbsp;<i class="icon-remove-sign icon-white"></i>';
            //            if (internetAvailable == 'connected') internetAvailableIcon = '&nbsp;<i class="icon-ok icon-white"></i>';
            //            if (internetAvailable == 'nointernet') internetAvailableIcon = '&nbsp;<i class="icon-minus-sign icon-white"></i>';

            var newStatusClass = "btn btn-large btn-block btn-success";

            if (internetAvailable == 'checking') newStatusClass = "btn btn-large btn-block " + GetInternetStatusButtonColors(internetAvailable);
            if (internetAvailable == 'disabled') newStatusClass = "btn btn-large btn-block " + GetInternetStatusButtonColors(internetAvailable);
            if (internetAvailable == 'connected') newStatusClass = "btn btn-large btn-block " + GetInternetStatusButtonColors(internetAvailable);
            if (internetAvailable == 'nointernet') newStatusClass = "btn btn-large btn-block " + GetInternetStatusButtonColors(internetAvailable);

            $('#' + targetID + '_selectedWan').attr("class", newStatusClass);

            $('#' + targetID + '_name').html(name);
            $('#' + targetID + '_selectedWan').html(selectedWan + internetAvailableIcon);

            if (available == false) {
                $('#' + targetID + '_main').css('display', 'none');
            } else {
                $('#' + targetID + '_main').css('display', 'block');
            }

            if (this.model.get('lanWans').length == 0) {
                $('#' + targetID + '_lanWans').css('display', 'none');
                //            } else {
                //                $('#' + targetID +'_lanWans').css('display', 'inline');
            }
            UpdateWanInfoWans(this.model, targetID, selectedWan, 'lanWans');
            UpdateWanInfoWans(this.model, targetID, selectedWan, 'mobileWans');
            UpdateWanInfoWans(this.model, targetID, selectedWan, 'wifiWans');
        }
    }
});

function GetInternetStatusButtonColors(internetAvailable) {
    if (internetAvailable == '') return "btn-inverse";
    if (internetAvailable == 'checking') return "btn-inverse";
    if (internetAvailable == 'disabled') return "btn-danger";
    if (internetAvailable == 'connected') return "btn-success";
    if (internetAvailable == 'nointernet') return "btn-warning";
}

function UpdateWanInfo(model, targetID, selectedWan, TypeOfWan) {
    $('#' + targetID + '_selectedWan').html(selectedWan);

    UpdateWanInfoWans(model, targetID, selectedWan, TypeOfWan);
}

function UpdateWanInfoWans(model, targetID, selectedWan, TypeOfWan) {
    var lanWans = model.get(TypeOfWan);

    var hrefTemplate = _.template('<a href="<%= action %>" class="btn btn-large btn-block <%= status %> "><%= title %> <%= usage %></a>');
    $('#' + targetID + '_' + TypeOfWan + ' > a').remove();
    for (var i = 0, l = lanWans.length; i < l; i++) {
        var connectionStatus = GetInternetStatusButtonColors(lanWans[i].connection);
        var link = hrefTemplate({ title: lanWans[i].title, action: lanWans[i].action, usage: lanWans[i].usage, status: connectionStatus });
        $('#' + targetID + '_' + TypeOfWan).append(link);
    }
}

function encodeSSID(ssid) {
    return encodeURIComponent(ssid).replace(/'/g, "%27").replace(/"/g, "%22");
}
function decodeSSID(encodedSsid) {
    return decodeURIComponent(encodedSsid.replace(/\+/g, " "));
}

function UpdateWanWifiNetworks() {
    var wifiNetworks = wanNetworkStatisticsConfig.get('visibleWanWifiNetworks');
    var hrefTemplateL = _.template('<tr><td><a href="<%= action %>" class="btn btn-small btn-default" ><%= title %></a>&nbsp;<i class="icon-ok-circle icon-white"></td><td><span class="label label-important"><%= signal %></span></td></tr>');
    var hrefTemplateM = _.template('<tr><td><a href="<%= action %>" class="btn btn-small btn-default" ><%= title %></a>&nbsp;<i class="icon-ok-circle icon-white"></td><td><span class="label label-inverse"><%= signal %></span></td></tr>');
    var hrefTemplateH = _.template('<tr><td><a href="<%= action %>" class="btn btn-small btn-default" ><%= title %></a>&nbsp;<i class="icon-ok-circle icon-white"></td><td><span class="label label-success"><%= signal %></span></td></tr>');
    var hrefTemplateL_locked = _.template('<tr><td><a href="<%= action %>" class="btn btn-small btn-inverse" ><%= title %></a></td><td><span class="label label-important"><%= signal %></span></td></tr>');
    var hrefTemplateM_locked = _.template('<tr><td><a href="<%= action %>" class="btn btn-small btn-inverse" ><%= title %></a></td><td><span class="label label-inverse"><%= signal %></span></td></tr>');
    var hrefTemplateH_locked = _.template('<tr><td><a href="<%= action %>" class="btn btn-small btn-inverse" ><%= title %></a></td><td><span class="label label-success"><%= signal %></span></td></tr>');
    $('#VisibleNetworksArea table').remove();

    var newTable = "<table id='VisibleWanWifiNetworks' class='table table-condensed'>";
    for (var i = 0, l = wifiNetworks.length; i < l; i++) {
        var actionLink = "javascript:SelectWifiNetwork('" + wifiNetworks[i].ssid + "', 'locked' )";
        var actionLinkOpen = "javascript:SelectWifiNetwork('" + wifiNetworks[i].ssid + "', 'open')";

        var pureSingalNumber = wifiNetworks[i].signal;
        pureSingalNumber = pureSingalNumber.replace("signal:", "");
        pureSingalNumber = pureSingalNumber.replace("dBm", "");
        pureSingalNumber = pureSingalNumber.replace("dB", "");
        var pureSignalNumber = parseInt(pureSingalNumber);
        var link = "";
        if (wifiNetworks[i].locked == "no") {
            if (pureSignalNumber > 21) link = hrefTemplateH({ title: decodeSSID(wifiNetworks[i].ssid), signal: wifiNetworks[i].signal, action: actionLinkOpen });
            else link = hrefTemplateL({ title: decodeSSID(wifiNetworks[i].ssid), signal: wifiNetworks[i].signal, action: actionLink });
        } else {
            if (pureSignalNumber > 21) link = hrefTemplateH_locked({ title: decodeSSID(wifiNetworks[i].ssid), signal: wifiNetworks[i].signal, action: actionLink });
            else link = hrefTemplateL_locked({ title: decodeSSID(wifiNetworks[i].ssid), signal: wifiNetworks[i].signal, action: actionLink });
        }
        newTable += link;
    }
    newTable += "</table>";
    $('#VisibleNetworksArea').html(newTable);
}

function UpdateWanWifiDetailedStatus() {
    var detailedStatuses = wanNetworkStatisticsConfig.get('detailedStatus');
    var hrefTemplate = _.template('<tr><td><span class="label label-inverse"><%= title %></span></td><td><span class="label label-info"><%= data %></span></td></tr>');
    //$('#detailedStatusContainer children').remove();

    var allStatsues = "";
    for (var i = 0, l = detailedStatuses.length; i < l; i++) {
        if (detailedStatuses[i].title == "ssid") {
            allStatsues += hrefTemplate({ title: detailedStatuses[i].title, data: decodeSSID(detailedStatuses[i].data) });
        } else {
            allStatsues += hrefTemplate({ title: detailedStatuses[i].title, data: detailedStatuses[i].data });
        }
    }
    $('#detailedStatusContainer').html("<table>" + allStatsues + "</table>");
}

function UpdateWanMobileDetailedStatus() {
    var detailedStatuses = wanNetworkStatisticsConfig.get('detailedStatusMobile');
    var hrefTemplate = _.template('<tr><td><span class="label label-inverse"><%= title %></span></td><td><span class="label label-info"><%= data %></span></td></tr>');
    //$('#detailedStatusContainer children').remove();

    var allStatsues = "";
    for (var i = 0, l = detailedStatuses.length; i < l; i++) {
        allStatsues += hrefTemplate({ title: detailedStatuses[i].title, data: detailedStatuses[i].data });
    }
    $('#detailedStatusMobileContainer').html("<table>" + allStatsues + "</table>");
}

//Depending on data, we may need to parse JSON
function SetVesselNetworkModelArray(dataName, dataValue) {
    vesselNetwork.set(dataName, jQuery.parseJSON(dataValue));
}
//Depending on data, we may need to parse JSON
function SetVesselNetworkModelSingle(dataName, dataValue) {
    vesselNetwork.set(dataName, dataValue);
}
//Depending on data, we may need to parse JSON
function SetVesselNetworksVNsArray(dataName, dataValue) {
    vesselNetworksVNs.set(dataName, jQuery.parseJSON(dataValue));
}
//Depending on data, we may need to parse JSON
function SetVesselNetworksVNsSingle(dataName, dataValue) {
    vesselNetworksVNs.set(dataName, dataValue);
}


//Depending on data, we may need to parse JSON
function SetVesselNetworkDataArray(vesselNetworkID, dataName, dataValue) {
    vesselNetworks[vesselNetworkID].set(dataName, jQuery.parseJSON(dataValue));
}
//Depending on data, we may need to parse JSON
function SetVesselNetworkDataSingle(vesselNetworkID, dataName, dataValue) {
    vesselNetworks[vesselNetworkID].set(dataName, dataValue);
}

//Depending on data, we may need to parse JSON
function SetDiagnosticsVesselNetworkDataSingle(vesselNetworkID, dataName, dataValue) {
    diagnosticsScreenVesselNetworks[vesselNetworkID].set(dataName, dataValue);
}

//Wan Configuration Update JS
function SetWanConfigDataSingle(dataName, dataValue) {
    wanNetworkConfig.set(dataName, dataValue);
}
//Wan Configuration Update JS
function SetWanConfigDataArray(dataName, dataValue) {
    wanNetworkConfig.set(dataName, jQuery.parseJSON(dataValue));
}

//Wan Configuration Update JS
function SetWanStatisticsConfigDataSingle(dataName, dataValue) {
    wanNetworkStatisticsConfig.set(dataName, dataValue);
}
//Wan Configuration Update JS
function SetWanStatisticsConfigDataArray(dataName, dataValue) {
    wanNetworkStatisticsConfig.set(dataName, jQuery.parseJSON(dataValue));
}

//Wan Configuration Update JS
function SetSetupScreenDataSingle(dataName, dataValue) {
    setupScreenData.set(dataName, dataValue);
}

//Wan Configuration Update JS
function SetSetupScreenDataArray(dataName, dataValue) {
    //alert(dataName + " " + dataValue);
    setupScreenData.set(dataName, jQuery.parseJSON(dataValue));
}

function SetLockScreenSingle(dataName, dataValue) {
    lockScreen.set(dataName, dataValue);
}

function SetDocumentLocation(newLocation) {
    document.location = newLocation;
}

function ShowChangeOnButton(targetButton, newClass) {
    $("#" + targetButton).attr("class", newClass);
}

function TogleContainer(targetContainer) {
    if ($("#" + targetContainer).css("display") == "none") {
        $("#" + targetContainer).css("display", "inline");
    } else {
        $("#" + targetContainer).css("display", "none");
    }
}

var UpdateInProgress = false;
//var originalPageTitle = "";
function SetGeneralInfoMessage(info) {
    if (info == "PLEASE WAIT START") {
        UpdateInProgress = true;
        $("#pagetitle").text("PLEASE WAIT");
    } else if (info == "PLEASE WAIT END") {
        UpdateInProgress = false;
        $("#pagetitle").text(GetOriginalPageTitle());
    } else {
        $("#pagetitle").text(info);
    }

    //        if (info != "") UpdateInProgress = true;
    //        else UpdateInProgress = false;
    //        $("#generalInfo").html(info);

    //        if (info + "" == "")
    //        {
    //            $("#pagetitle").text(originalPageTitle);
    //        } else
    //        {
    //            $("#pagetitle").text("PLEASE WAIT");
    //        }


    //    if (info != "") UpdateInProgress = true;
    //    else UpdateInProgress = false;
    //    $("#generalInfo").html(info);

    //    if (originalPageTitle == "")
    //    {
    //        originalPageTitle = $("#pagetitle").text();
    //    }
    //    if (info + "" == "")
    //    {
    //        $("#pagetitle").text(originalPageTitle);
    //    } else
    //    {
    //        $("#pagetitle").text("PLEASE WAIT");
    //    }
}

$(document).ready(function () {
    //    $("div.span4").css("border", "thin solid #555");
    //    $("div.span6").css("background", "#222");
});

function fnValidateIPAddress(ipaddr, AllowSubnet) {
    if (ipaddr == "") return true;
    //Remember, this function will validate only Class C IP.
    //change to other IP Classes as you need
    ipaddr = ipaddr.replace(/\s/g, "") //remove spaces for checking
    var re = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/; //regex. check for digits and in
    //all 4 quadrants of the IP
    if (re.test(ipaddr)) {
        //split into units with dots "."
        var parts = ipaddr.split(".");
        //if the first unit/quadrant of the IP is zero
        if (parseInt(parseFloat(parts[0])) == 0) {
            return false;
        }
        if (AllowSubnet == false) {
            //if the fourth unit/quadrant of the IP is zero
            if (parseInt(parseFloat(parts[3])) == 0) {
                return false;
            }
        }
        //if any part is greater than 255
        for (var i = 0; i < parts.length; i++) {
            if (parseInt(parseFloat(parts[i])) > 255) {
                return false;
            }
        }
        return true;
    } else {
        return false;
    }
}

function GetMetaValue(meta_name) {
    var my_arr = document.getElementsByTagName("meta");
    for (var counter = 0; counter < my_arr.length; counter++) {
        console.log(my_arr[counter].getAttribute('property'));

        if (my_arr[counter].getAttribute('property') == meta_name) {
            return my_arr[counter].content;
        }
    }
    return "";
}

function GetOriginalPageTitle() {
    return GetMetaValue("originalTitle");
}
