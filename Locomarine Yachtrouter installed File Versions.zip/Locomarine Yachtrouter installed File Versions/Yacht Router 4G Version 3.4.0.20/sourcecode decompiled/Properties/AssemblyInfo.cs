using Android.Runtime;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: ResourceDesigner("YR.Core.Android.Resource", IsApplication = false)]
[assembly: AssemblyVersion("0.0.0.0")]
