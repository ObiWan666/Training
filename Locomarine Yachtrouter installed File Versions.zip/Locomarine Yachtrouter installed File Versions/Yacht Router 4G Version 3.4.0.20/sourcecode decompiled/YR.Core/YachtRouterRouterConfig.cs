using System;

namespace YR.Core
{
	[Serializable]
	public class YachtRouterRouterConfig
	{
		private string _RouterID = string.Empty;

		private string _RouterIP = "0.0.0.0";

		public string RouterID
		{
			get
			{
				return this._RouterID;
			}
			set
			{
				this._RouterID = value;
			}
		}

		public string RouterIP
		{
			get
			{
				return this._RouterIP;
			}
			set
			{
				this._RouterIP = value;
			}
		}
	}
}
