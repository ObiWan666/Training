using System.Threading;

namespace YR.Core
{
	public class ReaderWriterLockSlim
	{
		private Mutex curLock = new Mutex();

		private string _owner = string.Empty;

		private bool _physicalLock;

		private yrLogger _yrLogger;

		public ReaderWriterLockSlim(string Owner, yrLogger yrLogger)
		{
			this._owner = Owner;
			this._yrLogger = yrLogger;
		}

		public void ExitWriteLock(string context)
		{
			this._physicalLock = false;
			this._owner = string.Empty;
		}

		public void EnterWriteLock(string context)
		{
			int num = 100;
			while (num-- > 0)
			{
				if (!this._physicalLock)
				{
					this._owner = context;
					this._physicalLock = true;
					return;
				}
				Thread.Sleep(100);
			}
			this._owner = context;
		}
	}
}
