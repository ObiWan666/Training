using System;

namespace YR.Core
{
	[Serializable]
	public class YachtRouterConfigStatisticInterface
	{
		private string _InterfaceName = string.Empty;

		private string _VisibleName = string.Empty;

		private string _RouterID = string.Empty;

		public string InterfaceName
		{
			get
			{
				return this._InterfaceName;
			}
			set
			{
				this._InterfaceName = value;
			}
		}

		public string VisibleName
		{
			get
			{
				return this._VisibleName;
			}
			set
			{
				this._VisibleName = value;
			}
		}

		public string RouterID
		{
			get
			{
				return this._RouterID;
			}
			set
			{
				this._RouterID = value;
			}
		}
	}
}
