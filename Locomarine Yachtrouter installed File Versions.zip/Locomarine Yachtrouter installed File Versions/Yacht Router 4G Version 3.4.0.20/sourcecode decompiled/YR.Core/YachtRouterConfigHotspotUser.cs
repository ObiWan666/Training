using System;

namespace YR.Core
{
	[Serializable]
	public class YachtRouterConfigHotspotUser
	{
		public string Name
		{
			get;
			set;
		}

		public string Password
		{
			get;
			set;
		}

		public string TimeLimit
		{
			get;
			set;
		}

		public string ByteLimit
		{
			get;
			set;
		}

		public string UsedTimeLimit
		{
			get;
			set;
		}

		public string UsedByteLimit
		{
			get;
			set;
		}

		public bool ResetUsage
		{
			get;
			set;
		}

		public bool DeleteUser
		{
			get;
			set;
		}
	}
}
