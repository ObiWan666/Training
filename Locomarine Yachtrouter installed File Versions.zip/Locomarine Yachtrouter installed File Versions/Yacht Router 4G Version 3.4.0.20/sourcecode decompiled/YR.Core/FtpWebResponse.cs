using System;
using System.IO;
using System.Net;

namespace YR.Core
{
	public class FtpWebResponse : WebResponse
	{
		private int _StatusCode;

		private string _StatusDescription;

		private string _ContentType;

		private string _Log;

		private Stream _ResponseStream;

		public override string ContentType
		{
			get
			{
				return this._ContentType;
			}
			set
			{
				throw new NotSupportedException("This property cannot be set");
			}
		}

		public int Status
		{
			get
			{
				return this._StatusCode;
			}
		}

		public string StatusDescription
		{
			get
			{
				return this._StatusDescription;
			}
		}

		public string TransactionLog
		{
			get
			{
				return this._Log;
			}
		}

		internal FtpWebResponse()
		{
			this._StatusCode = -1;
			this._StatusDescription = null;
			this._ResponseStream = null;
			this._Log = null;
		}

		internal FtpWebResponse(int StatusCode, string StatusDescription, string Log)
		{
			this._StatusCode = StatusCode;
			this._StatusDescription = StatusDescription;
			this._Log = Log;
			this._ResponseStream = Stream.Null;
		}

		public override Stream GetResponseStream()
		{
			if (this._ResponseStream == null)
			{
				throw new ApplicationException("No response stream for this kind of method");
			}
			return this._ResponseStream;
		}

		internal void SetDownloadStream(Stream datastream)
		{
			this._ResponseStream = datastream;
			this._ResponseStream.Position = 0L;
		}
	}
}
