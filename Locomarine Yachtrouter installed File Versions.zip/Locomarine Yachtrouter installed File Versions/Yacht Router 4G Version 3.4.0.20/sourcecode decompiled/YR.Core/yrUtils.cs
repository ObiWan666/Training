using System;
using System.Linq;

namespace YR.Core
{
	public class yrUtils
	{
		public static string ExtractInfo(string info, string InfoKey)
		{
			try
			{
				if (InfoKey[0] != '=')
				{
					InfoKey = '=' + InfoKey;
				}
				if (info.IndexOf(InfoKey) != -1)
				{
					string text = info.Substring(info.IndexOf(InfoKey) + 1);
					text = text.Substring(text.IndexOf('=') + 1);
					if (text.IndexOf('=') != -1)
					{
						text = text.Substring(0, text.IndexOf('='));
					}
					if (text.IndexOf(".tag") != -1)
					{
						text = text.Substring(0, text.LastIndexOf(".tag"));
					}
					return text;
				}
			}
			catch
			{
			}
			return string.Empty;
		}

		public static bool IsUpgradeRequired(string downloadableVersion, string AssemblyVersion)
		{
			ulong num = 0uL;
			if (!string.IsNullOrEmpty(downloadableVersion))
			{
				num = yrUtils.ConvertVersionStringToULong(downloadableVersion, 4);
			}
			ulong num2 = yrUtils.ConvertVersionStringToULong(AssemblyVersion, 4);
			return num > num2;
		}

		public static bool IsUpgradeRequiredFromApplication(string RouterVersion, string AssemblyVersion)
		{
			ulong num = 0uL;
			if (!string.IsNullOrEmpty(RouterVersion))
			{
				num = yrUtils.ConvertVersionStringToULong(RouterVersion, 4);
			}
			ulong num2 = yrUtils.ConvertVersionStringToULong(AssemblyVersion, 4);
			return num < num2;
		}

		public static ulong ConvertVersionStringToULong(string version, int digitExpansion = 4)
		{
			string[] array = version.Trim().Split(',', '.');
			string text = string.Empty;
			string[] array2 = array;
			foreach (string text2 in array2)
			{
				text += text2.PadLeft(4, '0');
			}
			return Convert.ToUInt64(text);
		}

		public static string ExtractInfoSpecialAtCommand(string info, string InfoKey)
		{
			try
			{
				string[] source = new string[14]
				{
					"!re",
					".id=",
					"name",
					"mtu",
					"mac-address",
					"apn",
					"modem-init",
					"network-mode",
					"authentication",
					"running",
					"disabled",
					"comment",
					"user",
					"password"
				};
				if (InfoKey[0] != '=')
				{
					InfoKey = '=' + InfoKey;
				}
				if (info.IndexOf(InfoKey) != -1)
				{
					string text = info.Substring(info.IndexOf(InfoKey) + 1);
					text = text.Substring(text.IndexOf('=') + 1);
					if (text.IndexOf('=') != -1)
					{
						string[] array = text.Split('=');
						text = string.Empty;
						string[] array2 = array;
						foreach (string text2 in array2)
						{
							if (source.Contains(text2))
							{
								break;
							}
							text = text + text2 + "=";
						}
						text = text.TrimEnd('=');
					}
					if (text.IndexOf(".tag") != -1)
					{
						text = text.Substring(0, text.LastIndexOf(".tag"));
					}
					return text;
				}
			}
			catch
			{
			}
			return string.Empty;
		}

		public static string ExtractUrlParamInfo(string inputUrl, string Param)
		{
			try
			{
				string[] array = inputUrl.Split('&', '?');
				string[] array2 = array;
				foreach (string text in array2)
				{
					string[] array3 = text.Split('=');
					if (array3.Length == 2)
					{
						if (array3[0] == Param)
						{
							return array3[1];
						}
					}
					else if (array3.Length == 3)
					{
						return array3[1] + "=" + array3[2];
					}
				}
			}
			catch
			{
			}
			return string.Empty;
		}

		public static string encodeSSID(string ssid)
		{
			string text = Uri.EscapeUriString(ssid);
			text = text.Replace("\"", "%22");
			return text.Replace("'", "%27");
		}
	}
}
