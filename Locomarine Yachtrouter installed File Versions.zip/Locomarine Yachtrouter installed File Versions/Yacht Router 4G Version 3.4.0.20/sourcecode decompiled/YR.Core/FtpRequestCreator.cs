using System;
using System.Net;

namespace YR.Core
{
	public class FtpRequestCreator : IWebRequestCreate
	{
		public WebRequest Create(Uri Url)
		{
			return new FtpWebRequest(Url);
		}
	}
}
