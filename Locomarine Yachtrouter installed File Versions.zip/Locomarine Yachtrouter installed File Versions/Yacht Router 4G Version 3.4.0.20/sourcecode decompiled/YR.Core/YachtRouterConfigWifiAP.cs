using System;

namespace YR.Core
{
	[Serializable]
	public class YachtRouterConfigWifiAP : YachtRouterConfigInterfaceBase
	{
		public int WiFiNumber
		{
			get;
			set;
		}

		public string WiFiAPN
		{
			get;
			set;
		}

		public string WiFiSecurityProfile
		{
			get;
			set;
		}

		public string WiFiSecurityPassword
		{
			get;
			set;
		}

		public bool HotspotAvailable
		{
			get;
			set;
		}

		public bool HotspotEnabled
		{
			get;
			set;
		}

		public bool WiFiEnabled
		{
			get;
			set;
		}

		public bool AutoswitchAvailable
		{
			get;
			set;
		}

		public bool AutoswitchEnabled
		{
			get;
			set;
		}

		public string AutoswitchScript
		{
			get;
			set;
		}

		public bool ClientIsolationEnabled
		{
			get;
			set;
		}

		public bool ClientIsolationAvailable
		{
			get;
			set;
		}

		public YachtRouterConfigWifiAP()
		{
			this.ClientIsolationAvailable = false;
			this.HotspotAvailable = false;
			this.AutoswitchAvailable = false;
		}
	}
}
