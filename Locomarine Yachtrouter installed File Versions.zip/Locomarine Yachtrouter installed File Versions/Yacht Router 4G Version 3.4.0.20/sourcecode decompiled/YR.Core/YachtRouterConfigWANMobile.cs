using System;

namespace YR.Core
{
	[Serializable]
	public class YachtRouterConfigWANMobile : YachtRouterConfigWANBase
	{
		public string MobileNetworkOperator
		{
			get;
			set;
		}

		public bool MobileNetworkEnableRoaming
		{
			get;
			set;
		}

		public string MobileNetworkSIMCardPin
		{
			get;
			set;
		}

		public string MobileNetworkSIMCardPuk
		{
			get;
			set;
		}

		public string MobileNetworkAPN
		{
			get;
			set;
		}

		public string MobileNetworkPhoneNumber
		{
			get;
			set;
		}

		public string MobileNetworkUsername
		{
			get;
			set;
		}

		public string MobileNetworkPassword
		{
			get;
			set;
		}

		public string MobileNetworkModemInit
		{
			get;
			set;
		}

		public string MobileNetworkDialCommand
		{
			get;
			set;
		}

		public bool DirectIP
		{
			get;
			set;
		}

		public string NetworkMode
		{
			get;
			set;
		}

		public bool BondedInterface
		{
			get;
			set;
		}

		public bool ReloadSimAvailable
		{
			get;
			set;
		}

		public int ReloadSimBus
		{
			get;
			set;
		}
	}
}
