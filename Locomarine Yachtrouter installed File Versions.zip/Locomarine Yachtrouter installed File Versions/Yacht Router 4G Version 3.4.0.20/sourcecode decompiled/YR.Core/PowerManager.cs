using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace YR.Core
{
	public class PowerManager : IDisposable
	{
		public enum SystemPowerStates : uint
		{
			On = 0x10000,
			Off = 0x20000,
			Critical = 0x40000,
			Boot = 0x80000,
			Idle = 0x100000,
			Suspend = 0x200000,
			Reset = 0x800000
		}

		public enum PowerReqFlags : uint
		{
			POWER_NAME = 1u,
			POWER_FORCE = 0x1000
		}

		public enum DevicePowerStates
		{
			PwrDeviceUnspecified = -1,
			FullOn,
			D0 = 0,
			LowOn,
			D1 = 1,
			StandBy,
			D2 = 2,
			Sleep,
			D3 = 3,
			Off,
			D4 = 4,
			PwrDeviceMaximum
		}

		[Flags]
		public enum MessageTypes : uint
		{
			Transition = 1u,
			Resume = 2u,
			Change = 4u,
			Status = 8u
		}

		public enum ACLineStatus : byte
		{
			Offline,
			OnLine,
			Unknown = 0xFF
		}

		[Flags]
		public enum BatteryFlags : byte
		{
			High = 1,
			Low = 2,
			Critical = 4,
			Charging = 8,
			Reserved1 = 0x10,
			Reserved2 = 0x20,
			Reserved3 = 0x40,
			NoBattery = 0x80,
			Unknown = 0xFF
		}

		private enum Wait : uint
		{
			Object,
			Abandoned = 0x80,
			Failed = 0xFFFFFFFF
		}

		private struct MessageQueueOptions
		{
			public uint Size;

			public uint Flags;

			public uint MaxMessages;

			public uint MaxMessage;

			public uint ReadAccess;
		}

		public struct PowerInfo
		{
			public MessageTypes Message;

			public SystemPowerStates Flags;

			public uint Length;

			public uint NumLevels;

			public uint BatteryLifeTime;

			public uint BatteryFullLifeTime;

			public uint BackupBatteryLifeTime;

			public uint BackupBatteryFullLifeTime;

			public ACLineStatus ACLineStatus;

			public BatteryFlags BatteryFlag;

			public byte BatteryLifePercent;

			public byte BackupBatteryFlag;

			public byte BackupBatteryLifePercent;
		}

		private const uint POWER_NOTIFY_ALL = 4294967295u;

		private const int INFINITE = -1;

		private const int MSGQUEUE_NOPRECOMMIT = 1;

		private AutoResetEvent powerThreadAbort;

		private bool abortPowerThread;

		private bool powerThreadRunning;

		private Queue powerQueue;

		private IntPtr hMsgQ = IntPtr.Zero;

		private IntPtr hReq = IntPtr.Zero;

		private bool bDisposed;

		public event EventHandler PowerNotify
		{
			add
			{
				EventHandler eventHandler = this.PowerNotify;
				EventHandler eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.PowerNotify, (EventHandler)Delegate.Combine(eventHandler2, value), eventHandler);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler eventHandler = this.PowerNotify;
				EventHandler eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.PowerNotify, (EventHandler)Delegate.Remove(eventHandler2, value), eventHandler);
				}
				while (eventHandler != eventHandler2);
			}
		}

		~PowerManager()
		{
			this.Dispose();
		}

		public void Dispose()
		{
			if (!this.bDisposed)
			{
				this.DisableNotifications();
				this.bDisposed = true;
				GC.SuppressFinalize(this);
			}
		}

		public int SetSystemPowerState(SystemPowerStates systemState)
		{
			uint num = 0u;
			return (int)PowerManager.CESetSystemPowerState(IntPtr.Zero, (uint)systemState, 0u);
		}

		public int GetSystemPowerState(StringBuilder systemStateName, out SystemPowerStates systemState)
		{
			uint num = 0u;
			return (int)PowerManager.CEGetSystemPowerState(systemStateName, (uint)systemStateName.Capacity, out systemState);
		}

		public int DevicePowerNotify(string deviceName, DevicePowerStates deviceState)
		{
			uint num = 0u;
			return (int)PowerManager.CEDevicePowerNotify(deviceName, (uint)deviceState, 1u);
		}

		public void EnableNotifications()
		{
			MessageQueueOptions structure = default(MessageQueueOptions);
			structure.Size = (uint)Marshal.SizeOf(structure);
			structure.Flags = 1u;
			structure.MaxMessages = 32u;
			structure.MaxMessage = 512u;
			structure.ReadAccess = 1u;
			this.hMsgQ = PowerManager.CECreateMsgQueue("PowerNotifications", ref structure);
			this.hReq = PowerManager.CERequestPowerNotifications(this.hMsgQ, 4294967295u);
			if (this.hMsgQ != IntPtr.Zero && this.hReq != IntPtr.Zero)
			{
				this.powerQueue = new Queue();
				this.powerThreadAbort = new AutoResetEvent(false);
				new Thread(this.PowerNotifyThread).Start();
			}
		}

		public void DisableNotifications()
		{
			if (this.powerThreadRunning)
			{
				if (this.hReq != IntPtr.Zero)
				{
					PowerManager.CEStopPowerNotifications(this.hReq);
				}
				this.abortPowerThread = true;
				this.powerThreadAbort.Set();
				int num = 0;
				while (this.powerThreadRunning)
				{
					Thread.Sleep(100);
					if (num++ > 50)
					{
						break;
					}
				}
			}
		}

		public PowerInfo GetNextPowerInfo()
		{
			lock (this.powerQueue.SyncRoot)
			{
				return (PowerInfo)this.powerQueue.Dequeue();
			}
		}

		private void PowerNotifyThread()
		{
			this.powerThreadRunning = true;
			while (!this.abortPowerThread)
			{
				IntPtr[] array = new IntPtr[2]
				{
					this.hMsgQ,
					this.powerThreadAbort.Handle
				};
				Wait wait = (Wait)PowerManager.CEWaitForMultipleObjects((uint)array.Length, array, false, -1);
				if (this.abortPowerThread)
				{
					break;
				}
				switch (wait)
				{
				case Wait.Abandoned:
					this.abortPowerThread = true;
					break;
				case Wait.Failed:
					Thread.Sleep(500);
					break;
				case Wait.Object:
				{
					PowerInfo powerInfo = default(PowerInfo);
					uint buffSize = (uint)Marshal.SizeOf(powerInfo);
					uint num = 0u;
					uint num2 = 0u;
					if (PowerManager.CEReadMsgQueue(this.hMsgQ, ref powerInfo, buffSize, ref num, 0u, ref num2))
					{
						if (powerInfo.BatteryLifePercent < 0 || powerInfo.BatteryLifePercent > 100)
						{
							powerInfo.BatteryLifePercent = 0;
						}
						if (powerInfo.BackupBatteryLifePercent < 0 || powerInfo.BackupBatteryLifePercent > 100)
						{
							powerInfo.BackupBatteryLifePercent = 0;
						}
						lock (this.powerQueue.SyncRoot)
						{
							this.powerQueue.Enqueue(powerInfo);
						}
						if (this.PowerNotify != null)
						{
							this.PowerNotify(this, null);
						}
					}
					break;
				}
				}
			}
			if (this.hMsgQ != IntPtr.Zero)
			{
				PowerManager.CECloseMsgQueue(this.hMsgQ);
			}
			this.powerThreadRunning = false;
		}

		[DllImport("coredll.dll", EntryPoint = "RequestPowerNotifications")]
		private static extern IntPtr CERequestPowerNotifications(IntPtr hMsgQ, uint Flags);

		[DllImport("coredll.dll", EntryPoint = "StopPowerNotifications")]
		private static extern bool CEStopPowerNotifications(IntPtr hReq);

		[DllImport("coredll.dll", EntryPoint = "SetDevicePower")]
		private static extern uint CESetDevicePower(string Device, uint dwDeviceFlags, uint DeviceState);

		[DllImport("coredll.dll", EntryPoint = "GetDevicePower")]
		private static extern uint CEGetDevicePower(string Device, uint dwDeviceFlags, uint DeviceState);

		[DllImport("coredll.dll", EntryPoint = "DevicePowerNotify")]
		private static extern uint CEDevicePowerNotify(string Device, uint DeviceState, uint Flags);

		[DllImport("coredll.dll", EntryPoint = "SetSystemPowerState")]
		private static extern uint CESetSystemPowerState(IntPtr sState, uint StateFlags, uint Options);

		[DllImport("coredll.dll", EntryPoint = "GetSystemPowerState")]
		private static extern uint CEGetSystemPowerState(StringBuilder Buffer, uint Length, out SystemPowerStates Flags);

		[DllImport("coredll.dll", EntryPoint = "CreateMsgQueue")]
		private static extern IntPtr CECreateMsgQueue(string Name, ref MessageQueueOptions Options);

		[DllImport("coredll.dll", EntryPoint = "CloseMsgQueue")]
		private static extern bool CECloseMsgQueue(IntPtr hMsgQ);

		[DllImport("coredll.dll", EntryPoint = "ReadMsgQueue")]
		private static extern bool CEReadMsgQueue(IntPtr hMsgQ, ref PowerInfo Power, uint BuffSize, ref uint BytesRead, uint Timeout, ref uint Flags);

		[DllImport("coredll.dll", EntryPoint = "WaitForMultipleObjects", SetLastError = true)]
		private static extern int CEWaitForMultipleObjects(uint nCount, IntPtr[] lpHandles, bool fWaitAll, int dwMilliseconds);
	}
}
