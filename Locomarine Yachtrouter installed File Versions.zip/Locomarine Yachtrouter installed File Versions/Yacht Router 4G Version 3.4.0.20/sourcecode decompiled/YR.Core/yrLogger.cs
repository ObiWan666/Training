using System;
using System.IO;

namespace YR.Core
{
	public class yrLogger
	{
		private string YACHTROUTER_DESKTOP_FILENAME = ".\\YachtRouterLog.txt";

		private yrEngine _yrEngine;

		private bool _workingInDeviceMode;

		private bool _outputLogFile;

		public bool OutputLogFile
		{
			get
			{
				return this._outputLogFile;
			}
			set
			{
				this._outputLogFile = value;
				if (this._outputLogFile)
				{
					try
					{
						File.Delete(this.YACHTROUTER_DESKTOP_FILENAME);
					}
					catch
					{
					}
				}
			}
		}

		public void InitLogger(yrEngine yrEngine, bool WorkingInDeviceMode)
		{
			this._workingInDeviceMode = WorkingInDeviceMode;
			this._yrEngine = yrEngine;
		}

		public void LogMessage(string Message)
		{
			if (Message.IndexOf("LOCK") != -1)
			{
				return;
			}
		}

		public void LogException(Exception ex)
		{
			if (ex.Message.IndexOf("HRESULT") != -1)
			{
				return;
			}
		}

		private void AppendLogFile(string Message)
		{
		}
	}
}
