namespace YR.Core
{
	public enum FtpCommandType
	{
		FtpControlCommand = 1,
		FtpDataReceiveCommand,
		FtpDataSendCommand,
		FtpCommandNotSupported
	}
}
