using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace YR.Core
{
	public class MK
	{
		public delegate void NewTorchLine(string newLine);

		private yrLogger _curLogger;

		private Stream routerStream;

		private TcpClient routerConnection;

		private string _routerIP = string.Empty;

		private string _user = string.Empty;

		private string _password = string.Empty;

		public ReaderWriterLockSlim AccessToRouterLock;

		private MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();

		private string curRouterModelName;

		private string HighSpeedSSIDSuffix = " AC";

		private bool _SuspendUpdates;

		private string curMobileModemName;

		private bool StopGettingTorchDataFlag;

		public string RouterIP
		{
			get
			{
				return this._routerIP;
			}
		}

		public string RouterID
		{
			get;
			set;
		}

		public bool ConnectedToRouter
		{
			get
			{
				if (this.routerConnection != null)
				{
					return this.routerConnection.Client.Connected;
				}
				return false;
			}
		}

		public bool SuspendUpdates
		{
			get
			{
				return this._SuspendUpdates;
			}
			set
			{
				this._SuspendUpdates = value;
				this._curLogger.LogMessage("Suspend Updates: " + value);
			}
		}

		public event RouterNewInfo OnRouterNewInfo
		{
			add
			{
				RouterNewInfo routerNewInfo = this.OnRouterNewInfo;
				RouterNewInfo routerNewInfo2;
				do
				{
					routerNewInfo2 = routerNewInfo;
					routerNewInfo = Interlocked.CompareExchange<RouterNewInfo>(ref this.OnRouterNewInfo, (RouterNewInfo)Delegate.Combine(routerNewInfo2, value), routerNewInfo);
				}
				while (routerNewInfo != routerNewInfo2);
			}
			remove
			{
				RouterNewInfo routerNewInfo = this.OnRouterNewInfo;
				RouterNewInfo routerNewInfo2;
				do
				{
					routerNewInfo2 = routerNewInfo;
					routerNewInfo = Interlocked.CompareExchange<RouterNewInfo>(ref this.OnRouterNewInfo, (RouterNewInfo)Delegate.Remove(routerNewInfo2, value), routerNewInfo);
				}
				while (routerNewInfo != routerNewInfo2);
			}
		}

		public event NewTorchLine OnNewTorchLine
		{
			add
			{
				NewTorchLine newTorchLine = this.OnNewTorchLine;
				NewTorchLine newTorchLine2;
				do
				{
					newTorchLine2 = newTorchLine;
					newTorchLine = Interlocked.CompareExchange<NewTorchLine>(ref this.OnNewTorchLine, (NewTorchLine)Delegate.Combine(newTorchLine2, value), newTorchLine);
				}
				while (newTorchLine != newTorchLine2);
			}
			remove
			{
				NewTorchLine newTorchLine = this.OnNewTorchLine;
				NewTorchLine newTorchLine2;
				do
				{
					newTorchLine2 = newTorchLine;
					newTorchLine = Interlocked.CompareExchange<NewTorchLine>(ref this.OnNewTorchLine, (NewTorchLine)Delegate.Remove(newTorchLine2, value), newTorchLine);
				}
				while (newTorchLine != newTorchLine2);
			}
		}

		public MK(string RouterID, string routerIP, yrLogger Logger, string newHighSpeedSSIDSuffix)
		{
			this._curLogger = Logger;
			this.RouterID = RouterID;
			this._routerIP = routerIP;
			this.HighSpeedSSIDSuffix = newHighSpeedSSIDSuffix;
			this.AccessToRouterLock = new ReaderWriterLockSlim(RouterID, Logger);
		}

		private void FireNewInfo(string newInfo)
		{
			if (this.OnRouterNewInfo != null)
			{
				this.OnRouterNewInfo(this._routerIP, newInfo);
			}
		}

		public bool InitializeRouter(string user, string password)
		{
			try
			{
				this._user = user;
				this._password = password;
				return this.EnsureConnection();
			}
			catch
			{
			}
			return false;
		}

		public void Close()
		{
			try
			{
				if (this.routerStream != null)
				{
					this.routerStream.Close();
				}
				this.routerStream = null;
			}
			catch
			{
			}
			try
			{
				if (this.routerConnection != null)
				{
					this.routerConnection.Close();
				}
				this.routerConnection = null;
			}
			catch
			{
			}
		}

		public bool Login(string username, string password)
		{
			this.Send("/login", true);
			List<string> list = this.Read();
			string hash = list[0].Split('=')[2];
			this.Send("/login");
			this.Send("=name=" + username);
			this.Send("=response=00" + this.EncodePassword(password, hash), true);
			list = this.Read();
			if (list[0] == "!done")
			{
				return true;
			}
			return this.FixOldAccessPassword(username, password);
		}

		private bool FixOldAccessPassword(string username, string newPassword)
		{
			foreach (string routerConfig_PasswordOld in yrEngine.RouterConfig_PasswordOlds)
			{
				this.ConnectStreamsToRouter(true);
				this.Send("/login", true);
				List<string> list = this.Read();
				string hash = list[0].Split('=')[2];
				this.Send("/login");
				this.Send("=name=" + username);
				this.Send("=response=00" + this.EncodePassword(routerConfig_PasswordOld, hash), true);
				list = this.Read();
				if (list[0] == "!done")
				{
					this.Send("/user/set");
					this.Send("=.id=loco");
					this.Send("=password=" + newPassword, true);
					List<string> list2 = this.Read();
					if (list2[0] == "!done")
					{
						return true;
					}
					return false;
				}
			}
			return false;
		}

		public bool Send(string co)
		{
			try
			{
				byte[] bytes = Encoding.ASCII.GetBytes(co.ToCharArray());
				byte[] array = this.EncodeLength(bytes.Length);
				this.routerStream.Write(array, 0, array.Length);
				this.routerStream.Write(bytes, 0, bytes.Length);
				return true;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				this.Close();
			}
			return false;
		}

		public void Send(string co, bool endsentence)
		{
			if (this.Send(co))
			{
				this.routerStream.WriteByte(0);
			}
		}

		public bool EnsureConnection()
		{
			if (this.routerConnection != null && this.routerConnection.Client.Connected && this.EnsureConnectionPhysicalConnectedTest())
			{
				return true;
			}
			try
			{
				this.ConnectStreamsToRouter(true);
				if (!this.Login(this._user, this._password))
				{
					this._curLogger.LogMessage("Ensure Connection Login failed: " + this.RouterIP);
					this.Close();
					return false;
				}
				this._curLogger.LogMessage("Ensure Connection Login Succedded: " + this.RouterIP);
				return true;
			}
			catch (Exception ex)
			{
				this._curLogger.LogMessage("Ensure Connection Exception");
				this._curLogger.LogException(ex);
			}
			finally
			{
			}
			return false;
		}

		private void ConnectStreamsToRouter(bool useSecureCommunication = true)
		{
			try
			{
				if (this.routerConnection != null && !this.EnsureConnectionPhysicalConnectedTest())
				{
					this.Close();
				}
				if (!useSecureCommunication)
				{
					this.routerConnection = new TcpClient();
					this.routerConnection.Connect(this._routerIP, 8728);
					this.routerConnection.ReceiveTimeout = 5000;
					this.routerStream = this.routerConnection.GetStream();
				}
				else
				{
					this.routerConnection = new TcpClient();
					this.routerConnection.Connect(this._routerIP, 8729);
					this.routerConnection.ReceiveTimeout = 5000;
					this.routerStream = new SslStream(this.routerConnection.GetStream(), false, MK.ValidateServerCertificate, null);
					((SslStream)this.routerStream).AuthenticateAsClient(this._routerIP);
				}
			}
			catch (Exception)
			{
				if (useSecureCommunication)
				{
					this.ConnectStreamsToRouter(false);
				}
			}
		}

		private static bool ValidateServerCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
		{
			return true;
		}

		private bool EnsureConnectionPhysicalConnectedTest()
		{
			try
			{
				this.routerStream.Write(new byte[0], 0, 0);
				return true;
			}
			catch
			{
			}
			return false;
		}

		public List<string> Read()
		{
			return this.Read(false, 0);
		}

		public List<string> Read(bool StreamingOutput, int CountOfResults)
		{
			List<string> list;
			if (this.routerConnection != null && this.routerConnection.Client.Connected)
			{
				list = new List<string>();
				if (!StreamingOutput)
				{
					goto IL_0032;
				}
				goto IL_0032;
			}
			return new List<string>();
			IL_0032:
			List<string> list2 = new List<string>();
			string text = string.Empty;
			byte[] array = new byte[4];
			try
			{
				while (true)
				{
					array[3] = (byte)this.routerStream.ReadByte();
					if (array[3] == 0)
					{
						list2.Add(text);
						if (StreamingOutput)
						{
							list.Add(text);
							if (list.Count >= CountOfResults)
							{
								return list;
							}
						}
						if (text.Length >= 5 && text.Substring(0, 5) == "!done")
						{
							return list2;
						}
						text = string.Empty;
					}
					else
					{
						long num;
						if (array[3] < 128)
						{
							num = (int)array[3];
						}
						else if (array[3] < 192)
						{
							int num2 = BitConverter.ToInt32(new byte[4]
							{
								(byte)this.routerStream.ReadByte(),
								array[3],
								0,
								0
							}, 0);
							num = (num2 ^ 0x8000);
						}
						else if (array[3] < 224)
						{
							array[2] = (byte)this.routerStream.ReadByte();
							int num3 = BitConverter.ToInt32(new byte[4]
							{
								(byte)this.routerStream.ReadByte(),
								array[2],
								array[3],
								0
							}, 0);
							num = (num3 ^ 0xC00000);
						}
						else if (array[3] < 240)
						{
							array[2] = (byte)this.routerStream.ReadByte();
							array[1] = (byte)this.routerStream.ReadByte();
							int num4 = BitConverter.ToInt32(new byte[4]
							{
								(byte)this.routerStream.ReadByte(),
								array[1],
								array[2],
								array[3]
							}, 0);
							num = (num4 ^ 3758096384u);
						}
						else
						{
							if (array[3] != 240)
							{
								break;
							}
							array[3] = (byte)this.routerStream.ReadByte();
							array[2] = (byte)this.routerStream.ReadByte();
							array[1] = (byte)this.routerStream.ReadByte();
							array[0] = (byte)this.routerStream.ReadByte();
							num = BitConverter.ToInt32(array, 0);
						}
						for (int i = 0; i < num; i++)
						{
							text += (char)this.routerStream.ReadByte();
						}
					}
				}
				return list2;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return list2;
			}
		}

		private byte[] EncodeLength(int delka)
		{
			if (delka < 128)
			{
				byte[] bytes = BitConverter.GetBytes(delka);
				return new byte[1]
				{
					bytes[0]
				};
			}
			if (delka < 16384)
			{
				byte[] bytes2 = BitConverter.GetBytes(delka | 0x8000);
				return new byte[2]
				{
					bytes2[1],
					bytes2[0]
				};
			}
			if (delka < 2097152)
			{
				byte[] bytes3 = BitConverter.GetBytes(delka | 0xC00000);
				return new byte[3]
				{
					bytes3[2],
					bytes3[1],
					bytes3[0]
				};
			}
			if (delka < 268435456)
			{
				byte[] bytes4 = BitConverter.GetBytes(delka | 3758096384u);
				return new byte[4]
				{
					bytes4[3],
					bytes4[2],
					bytes4[1],
					bytes4[0]
				};
			}
			byte[] bytes5 = BitConverter.GetBytes(delka);
			return new byte[5]
			{
				240,
				bytes5[3],
				bytes5[2],
				bytes5[1],
				bytes5[0]
			};
		}

		public string EncodePassword(string Password, string hash)
		{
			byte[] array = new byte[hash.Length / 2];
			for (int i = 0; i <= hash.Length - 2; i += 2)
			{
				array[i / 2] = byte.Parse(hash.Substring(i, 2), NumberStyles.HexNumber);
			}
			byte[] array2 = new byte[1 + Password.Length + array.Length];
			array2[0] = 0;
			Encoding.ASCII.GetBytes(Password.ToCharArray()).CopyTo(array2, 1);
			array.CopyTo(array2, 1 + Password.Length);
			byte[] array3 = this.md5.ComputeHash(array2);
			string text = string.Empty;
			byte[] array4 = array3;
			for (int j = 0; j < array4.Length; j++)
			{
				byte b = array4[j];
				text += b.ToString("x2");
			}
			return text;
		}

		public List<string> CheckWanMobileInfo(string WanMobileInterface)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CheckWanMobileInfo");
				this.Send("/interface/ppp-client/info");
				this.Send("=number=" + WanMobileInterface);
				this.Send(".tag=3", true);
				List<string> result = this.Read(true, 3);
				this.Send("/cancel");
				this.Send(".tag=3", true);
				List<string> list = this.Read();
				List<string> list2 = this.Read();
				return result;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CheckWanMobileInfo");
			}
		}

		public List<string> CheckWanWiFiInfo(string WifiWanInterface)
		{
			try
			{
				this._curLogger.LogMessage("CheckWanWiFiInfo Starting");
				this.AccessToRouterLock.EnterWriteLock("CheckWanWiFiInfo");
				this.Send("/interface/wireless/monitor");
				this.Send("=.id=" + WifiWanInterface);
				this.Send(".tag=5", true);
				List<string> result = this.Read(true, 1);
				this.Send("/cancel");
				this.Send(".tag=5", true);
				List<string> list = this.Read();
				List<string> list2 = this.Read();
				return result;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CheckWanWiFiInfo");
			}
		}

		public string CheckShipWiFiInfo(string WifiAPInterface)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CheckShipWiFiInfo");
				this.Send("/interface/wireless/print", true);
				list = this.Read();
				if (list.Last() != "!done")
				{
					list = this.Read();
				}
				for (int i = 0; i < list.Count; i++)
				{
					if (list[i].IndexOf("name=" + WifiAPInterface) != -1)
					{
						return yrUtils.ExtractInfo(list[i], "ssid=");
					}
				}
				return "Error";
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CheckShipWiFiInfo");
			}
		}

		public void UpdateRoutesToDHCPClientData(YachtRouterConfigWANBase curWan)
		{
			string empty = string.Empty;
			string empty2 = string.Empty;
			string empty3 = string.Empty;
			string empty4 = string.Empty;
			string empty5 = string.Empty;
			if (curWan.UseDHCPClient)
			{
				string[] dHCPAddresses = this.GetDHCPAddresses(curWan.InterfaceName);
				empty = dHCPAddresses[0];
				empty2 = dHCPAddresses[1];
				empty3 = dHCPAddresses[2];
				empty4 = dHCPAddresses[3];
				empty5 = dHCPAddresses[4];
			}
			else
			{
				empty = curWan.IP;
				empty2 = curWan.Subnet;
				empty3 = curWan.GatewayAddress;
				empty4 = curWan.DNS1Address;
				empty5 = curWan.DNS2Address;
			}
			this.SetIPAddress(curWan.InterfaceName, empty, empty2);
			this.SetDNSes(new string[2]
			{
				empty4,
				empty5
			});
		}

		public void GetAlwaysOnStatus(YachtRouterConfigWANLan curConfig)
		{
			string interfaceName = yrEngine.virtualApPrefix + curConfig.InterfaceName;
			string wirelessSecurityProfile = yrEngine.virtualApSecurityProfilePrefix + yrEngine.virtualApPrefix + curConfig.InterfaceName;
			curConfig.AlwaysOnEnabled = this.CheckIsInterfaceEnabledPhysicalByInterface(interfaceName);
			string[] wifiApSsidAndPassword = this.GetWifiApSsidAndPassword(interfaceName, wirelessSecurityProfile);
			curConfig.AlwaysOnSSID = wifiApSsidAndPassword[0];
			curConfig.AlwaysOnPassword = wifiApSsidAndPassword[1];
		}

		public List<string> ScanWANWiFi(string WanWifiInterface)
		{
			List<string> result = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("ScanWANWiFi");
				if (this.EnsureConnection())
				{
					this.Send("/interface/wireless/scan");
					this.Send("=.id=" + WanWifiInterface);
					this.Send(".tag=5", true);
					result = this.Read(true, 80);
					this.Send("/cancel");
					this.Send(".tag=5", true);
					List<string> list = this.Read();
					List<string> list2 = this.Read();
					return result;
				}
				return result;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return result;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("ScanWANWiFi");
			}
		}

		public YachtRouterConfigWANWifi GetWanWifiConfiguration(string InterfaceName, YachtRouterConfigWANWifi config)
		{
			try
			{
				config.IsEnabled = this.CheckIsInterfaceEnabledPhysicalByInterface(config.InterfaceName);
				config.Name = this.GetWanInterfaceTitle(config.InterfaceName);
				if (this.EnsureConnection())
				{
					string[] wifiApSsidAndPassword = this.GetWifiApSsidAndPassword(InterfaceName, config.WiFiSecurityProfile);
					config.WiFiAPN = wifiApSsidAndPassword[0];
					config.WiFiSecurityPassword = wifiApSsidAndPassword[1];
					config.WIFISelectedBand = this.GetInterfaceBand(InterfaceName);
					config.WIFISelectBandAvailable = this.GetIsWIFIBandSelectorAvailable();
					if (wifiApSsidAndPassword[2] == "wpa")
					{
						config.WiFiUseWep = false;
					}
					else if (wifiApSsidAndPassword[2] == "wep")
					{
						config.WiFiUseWep = true;
					}
					config.UseDHCPClient = this.GetIsDHCPClientEnabled(config.InterfaceName);
					if (config.UseDHCPClient)
					{
						string[] dHCPAddresses = this.GetDHCPAddresses(config.InterfaceName);
						config.IP = dHCPAddresses[0];
						config.Subnet = dHCPAddresses[1];
						config.GatewayAddress = dHCPAddresses[2];
						config.DNS1Address = dHCPAddresses[3];
						config.DNS2Address = dHCPAddresses[4];
						return config;
					}
					string[] iPAddress = this.GetIPAddress(config.InterfaceName);
					config.IP = iPAddress[0];
					config.Subnet = iPAddress[1];
					string[] dNSes = this.GetDNSes();
					config.DNS1Address = dNSes[0];
					config.DNS2Address = dNSes[1];
					config.GatewayAddress = this.GetGatewayFromRoute(config.InterfaceName);
					return config;
				}
				return config;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return config;
			}
		}

		public bool GetIsWIFIBandSelectorAvailable()
		{
			if (this.curRouterModelName == null)
			{
				this.curRouterModelName = this.GetRouterModelName();
			}
			if (this.curRouterModelName == "Metal G-52SHPacn")
			{
				return true;
			}
			return false;
		}

		public YachtRouterConfigWANMobile GetWanIpConfiguration(string InterfaceName, YachtRouterConfigWANMobile config)
		{
			try
			{
				config.Name = this.GetWanInterfaceTitle(config.InterfaceName);
				if (this.EnsureConnection())
				{
					config.UseDHCPClient = this.GetIsDHCPClientEnabled(config.InterfaceName);
					if (config.UseDHCPClient)
					{
						string[] dHCPAddresses = this.GetDHCPAddresses(config.InterfaceName);
						config.IP = dHCPAddresses[0];
						config.Subnet = dHCPAddresses[1];
						config.GatewayAddress = dHCPAddresses[2];
						config.DNS1Address = dHCPAddresses[3];
						config.DNS2Address = dHCPAddresses[4];
						return config;
					}
					string[] iPAddress = this.GetIPAddress(config.InterfaceName);
					config.IP = iPAddress[0];
					config.Subnet = iPAddress[1];
					string[] dNSes = this.GetDNSes();
					config.DNS1Address = dNSes[0];
					config.DNS2Address = dNSes[1];
					config.GatewayAddress = this.GetGatewayFromRoute(config.InterfaceName);
					return config;
				}
				return config;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return config;
			}
		}

		private string[] GetWifiApSsidAndPassword(string InterfaceName, string WirelessSecurityProfile)
		{
			string[] array = new string[3];
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetWifiApSsidAndPassword");
				this.Send("/interface/wireless/security-profiles/print", true);
				List<string> list = this.Read();
				int num = 0;
				while (num < list.Count)
				{
					if (list[num].IndexOf(WirelessSecurityProfile) == -1)
					{
						num++;
						continue;
					}
					if (yrUtils.ExtractInfo(list[num], "mode=") == "static-keys-optional")
					{
						array[1] = yrUtils.ExtractInfo(list[num], "static-key-0=");
						array[2] = "wep";
					}
					else
					{
						array[1] = yrUtils.ExtractInfo(list[num], "wpa-pre-shared-key=");
						array[2] = "wpa";
					}
					break;
				}
				array[0] = this.GetInterfaceSSID(InterfaceName);
				return array;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return array;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetWifiApSsidAndPassword");
			}
		}

		public bool[] GetWirelessInterfaceEnabledAndVisibleStatus(string InterfaceName)
		{
			bool[] result = new bool[2];
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetWirelessInterfaceEnabledAndVisibleStatus");
				this.Send("/interface/wireless/print", true);
				List<string> list = this.Read();
				for (int i = 0; i < list.Count; i++)
				{
					if (list[i].IndexOf(InterfaceName) != -1)
					{
						return new bool[2]
						{
							(byte)(list[i].Contains("=hide-ssid=false") ? 1 : 0) != 0,
							(byte)(list[i].Contains("=disabled=false") ? 1 : 0) != 0
						};
					}
				}
				return result;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return result;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetWirelessInterfaceEnabledAndVisibleStatus");
			}
		}

		private string GetInterfaceSSID(string InterfaceName)
		{
			List<string> list = new List<string>();
			this.Send("/interface/wireless/print", true);
			list = this.Read();
			for (int i = 0; i < list.Count; i++)
			{
				if (yrUtils.ExtractInfo(list[i], "name=") == InterfaceName)
				{
					return yrUtils.ExtractInfo(list[i], "ssid=");
				}
			}
			return string.Empty;
		}

		private string GetInterfaceBand(string InterfaceName)
		{
			List<string> list = new List<string>();
			this.Send("/interface/wireless/print", true);
			list = this.Read();
			for (int i = 0; i < list.Count; i++)
			{
				if (yrUtils.ExtractInfo(list[i], "name=") == InterfaceName)
				{
					string text = yrUtils.ExtractInfo(list[i], "band=");
					if (text.Contains("2ghz"))
					{
						return "24";
					}
					return "5";
				}
			}
			return string.Empty;
		}

		public string SetInterfaceBand(string InterfaceName, string Band)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("SetInterfaceBand");
				if (this.EnsureConnection())
				{
					List<string> list = new List<string>();
					this.Send("/interface/wireless/print", true);
					list = this.Read();
					int num = 0;
					while (num < list.Count)
					{
						if (!(yrUtils.ExtractInfo(list[num], "name=") == InterfaceName))
						{
							num++;
							continue;
						}
						string str = yrUtils.ExtractInfo(list[num], ".id");
						this.Send("/interface/wireless/set");
						this.Send("=.id=" + str);
						if (Band == "24")
						{
							this.Send("=band=2ghz-b/g/n", true);
						}
						if (Band == "5")
						{
							this.Send("=band=5ghz-a/n/ac", true);
						}
						List<string> list2 = this.Read();
						break;
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("SetInterfaceBand");
			}
			return string.Empty;
		}

		public void SetWanWifiConfiguration(string InterfaceName, YachtRouterConfigWANWifi config)
		{
			this._SetWanWifiConfiguration(InterfaceName, config);
		}

		private void _SetWanWifiConfiguration(string InterfaceName, YachtRouterConfigWANWifi config)
		{
			try
			{
				this.SetWifiInterfacePassword(config.WiFiSecurityProfile, config.WiFiSecurityPassword, config.WiFiUseWep);
				this.SetWifiInterfaceSSID(InterfaceName, config.WiFiAPN);
				this.SetWanInterfaceTitle(InterfaceName, config.Name);
				this.SetWanInterfaceAccessRules(config);
				this.SetIsDHCPClientEnabled(InterfaceName, config.UseDHCPClient);
				this.EnableDisableIPAddress(InterfaceName, !config.UseDHCPClient);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public YachtRouterConfigWANLan GetWanLanConfiguration(string lanWANName, YachtRouterConfigWANLan curConfig)
		{
			try
			{
				curConfig.IsEnabled = this.CheckIsInterfaceEnabledPhysicalByInterface(curConfig.InterfaceName);
				curConfig.UseDHCPClient = this.GetIsDHCPClientEnabled(curConfig.InterfaceName);
				curConfig.Name = this.GetWanInterfaceTitle(curConfig.InterfaceName);
				this.GetWanInterfaceAccessRules(curConfig);
				if (curConfig.UseDHCPClient)
				{
					string[] dHCPAddresses = this.GetDHCPAddresses(curConfig.InterfaceName);
					curConfig.IP = dHCPAddresses[0];
					curConfig.Subnet = dHCPAddresses[1];
					curConfig.GatewayAddress = dHCPAddresses[2];
					curConfig.DNS1Address = dHCPAddresses[3];
					curConfig.DNS2Address = dHCPAddresses[4];
					return curConfig;
				}
				string[] iPAddress = this.GetIPAddress(curConfig.InterfaceName);
				curConfig.IP = iPAddress[0];
				curConfig.Subnet = iPAddress[1];
				string[] dNSes = this.GetDNSes();
				curConfig.DNS1Address = dNSes[0];
				curConfig.DNS2Address = dNSes[1];
				curConfig.GatewayAddress = this.GetGatewayFromRoute(curConfig.InterfaceName);
				return curConfig;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return curConfig;
			}
		}

		public void SetWanLanConfiguration(string InterfaceName, YachtRouterConfigWANLan config)
		{
			this._SetWanLanConfiguration(InterfaceName, config);
		}

		private void _SetWanLanConfiguration(string InterfaceName, YachtRouterConfigWANLan config)
		{
			try
			{
				this.SetWanInterfaceTitle(InterfaceName, config.Name);
				this.SetWanInterfaceAccessRules(config);
				this.SetIsDHCPClientEnabled(InterfaceName, config.UseDHCPClient);
				this.EnableDisableIPAddress(InterfaceName, !config.UseDHCPClient);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public YachtRouterConfigWANMobile GetWanMobileConfiguration(string WanMobileInterface, YachtRouterConfigWANMobile curConfig)
		{
			try
			{
				curConfig.IsEnabled = this.CheckIsInterfaceEnabledPhysicalByInterface(curConfig.InterfaceName);
				curConfig.Name = this.GetWanInterfaceTitle(curConfig.InterfaceName);
				curConfig.ReloadSimAvailable = this.GetIsReloadSimAvailable();
				if (curConfig.BondedInterface)
				{
					return curConfig;
				}
				curConfig.MobileNetworkSIMCardPin = this.GetYachtRouterStoredCommentInfo("YachtRouterWanModemPIN");
				curConfig.MobileNetworkSIMCardPuk = this.GetYachtRouterStoredCommentInfo("YachtRouterWanModemPUK");
				string yachtRouterStoredCommentInfo = this.GetYachtRouterStoredCommentInfo("PermitRoaming_" + WanMobileInterface);
				if (yachtRouterStoredCommentInfo == "false")
				{
					curConfig.MobileNetworkEnableRoaming = false;
				}
				else if (yachtRouterStoredCommentInfo == "true")
				{
					curConfig.MobileNetworkEnableRoaming = true;
				}
				else
				{
					this.SetYachtRouterStoredCommentInfo("PermitRoaming_" + WanMobileInterface, "false");
					curConfig.MobileNetworkEnableRoaming = false;
				}
				this.GetWanInterfaceAccessRules(curConfig);
				this.AccessToRouterLock.EnterWriteLock("GetWanMobileConfiguration");
				if (this.EnsureConnection())
				{
					if (!curConfig.BondedInterface && !curConfig.DirectIP)
					{
						this.Send("/interface/ppp-client/print", true);
						List<string> list = this.Read();
						for (int i = 0; i < list.Count; i++)
						{
							if (list[i].IndexOf("=name=" + WanMobileInterface) != -1)
							{
								curConfig.MobileNetworkAPN = yrUtils.ExtractInfo(list[i], "apn=");
								curConfig.MobileNetworkPhoneNumber = yrUtils.ExtractInfo(list[i], "phone=");
								curConfig.MobileNetworkUsername = yrUtils.ExtractInfo(list[i], "user=");
								curConfig.MobileNetworkPassword = yrUtils.ExtractInfo(list[i], "password=");
								curConfig.MobileNetworkModemInit = yrUtils.ExtractInfoSpecialAtCommand(list[i], "modem-init=");
								curConfig.MobileNetworkDialCommand = yrUtils.ExtractInfo(list[i], "dial-command=");
								return curConfig;
							}
						}
					}
					if (!curConfig.BondedInterface && curConfig.DirectIP)
					{
						this.Send("/interface/lte/print");
						this.Send("=detail=", true);
						List<string> list2 = this.Read();
						for (int j = 0; j < list2.Count; j++)
						{
							if (list2[j].IndexOf("=name=" + WanMobileInterface) != -1)
							{
								curConfig.MobileNetworkAPN = yrUtils.ExtractInfo(list2[j], "apn=");
								curConfig.MobileNetworkPhoneNumber = yrUtils.ExtractInfo(list2[j], "phone=");
								curConfig.MobileNetworkUsername = yrUtils.ExtractInfo(list2[j], "user=");
								curConfig.MobileNetworkPassword = yrUtils.ExtractInfo(list2[j], "password=");
								curConfig.MobileNetworkModemInit = yrUtils.ExtractInfoSpecialAtCommand(list2[j], "modem-init=").Trim();
								curConfig.MobileNetworkDialCommand = yrUtils.ExtractInfo(list2[j], "dial-command=");
								curConfig.MobileNetworkSIMCardPin = yrUtils.ExtractInfo(list2[j], "pin=");
								curConfig.NetworkMode = yrUtils.ExtractInfo(list2[j], "network-mode=");
								return curConfig;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetWanMobileConfiguration");
			}
			return new YachtRouterConfigWANMobile();
		}

		public void SetWanMobileConfiguration(string WanMobileInterface, YachtRouterConfigWANMobile curConfig, bool IsRecycleNeeded)
		{
			this._SetWanMobileConfiguration(WanMobileInterface, curConfig, IsRecycleNeeded);
		}

		private void _SetWanMobileConfiguration(string WanMobileInterface, YachtRouterConfigWANMobile curConfig, bool IsRecycleNeeded)
		{
			try
			{
				this.SetWanInterfaceTitle(WanMobileInterface, curConfig.Name);
				this.SetYachtRouterStoredCommentInfo("YachtRouterWanModemPIN", curConfig.MobileNetworkSIMCardPin);
				this.SetYachtRouterStoredCommentInfo("YachtRouterWanModemPUK", curConfig.MobileNetworkSIMCardPuk);
				this.SetWanInterfaceAccessRules(curConfig);
				this.AccessToRouterLock.EnterWriteLock("_SetWanMobileConfiguration");
				if (this.EnsureConnection())
				{
					if (!curConfig.BondedInterface && !curConfig.DirectIP)
					{
						List<string> list = new List<string>();
						this.Send("/interface/ppp-client/set");
						this.Send("=.id=" + WanMobileInterface);
						this.Send("=apn=" + curConfig.MobileNetworkAPN);
						this.Send("=phone=" + curConfig.MobileNetworkPhoneNumber);
						this.Send("=user=" + curConfig.MobileNetworkUsername);
						this.Send("=password=" + curConfig.MobileNetworkPassword);
						this.Send("=modem-init=" + curConfig.MobileNetworkModemInit);
						this.Send("=dial-command=" + curConfig.MobileNetworkDialCommand, true);
						list = this.Read();
					}
					if (!curConfig.BondedInterface && curConfig.DirectIP)
					{
						List<string> list2 = new List<string>();
						this.Send("/interface/lte/set");
						this.Send("=.id=" + WanMobileInterface);
						this.Send("=apn=" + curConfig.MobileNetworkAPN);
						this.Send("=pin=" + curConfig.MobileNetworkSIMCardPin);
						this.Send("=user=" + curConfig.MobileNetworkUsername);
						this.Send("=password=" + curConfig.MobileNetworkPassword);
						this.Send("=network-mode=" + curConfig.NetworkMode);
						this.Send("=modem-init=" + curConfig.MobileNetworkModemInit.Trim(), true);
						list2 = this.Read();
						if (curConfig.NetworkMode.ToLower() == "auto")
						{
							this.Send("/interface/lte/set");
							this.Send("=.id=" + WanMobileInterface);
							this.Send("=apn=" + curConfig.MobileNetworkAPN);
							this.Send("=pin=" + curConfig.MobileNetworkSIMCardPin);
							this.Send("=user=" + curConfig.MobileNetworkUsername);
							this.Send("=password=" + curConfig.MobileNetworkPassword);
							this.Send("=network-mode=gsm,3g,lte");
							this.Send("=modem-init=" + curConfig.MobileNetworkModemInit.Trim(), true);
							list2 = this.Read();
						}
						if (curConfig.MobileNetworkModemInit.Contains("SYS"))
						{
							curConfig.MobileNetworkEnableRoaming = false;
						}
						else
						{
							curConfig.MobileNetworkEnableRoaming = true;
						}
						if (curConfig.MobileNetworkEnableRoaming)
						{
							this.SetYachtRouterStoredCommentInfo("PermitRoaming_" + WanMobileInterface, "true");
						}
						else
						{
							this.SetYachtRouterStoredCommentInfo("PermitRoaming_" + WanMobileInterface, "false");
						}
						this.Send("/system/script/print", true);
						list2 = this.Read();
						int num = 0;
						while (num < list2.Count)
						{
							if (list2[num].IndexOf("=name=scriptRecovery_" + WanMobileInterface + "_ModemInit") == -1)
							{
								num++;
								continue;
							}
							this.Send("/system/script/run");
							this.Send("=.id=" + yrUtils.ExtractInfo(list2[num], "=.id"), true);
							List<string> list3 = this.Read();
							break;
						}
					}
				}
				bool flag = this.CheckIsInterfaceEnabledPhysicalByInterface(WanMobileInterface);
				if (IsRecycleNeeded && flag)
				{
					this.EnableDisableInterfacePhysical(WanMobileInterface, false);
					this.EnableDisableInterfacePhysical(WanMobileInterface, true);
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("_SetWanMobileConfiguration");
			}
		}

		internal string GetMobileModemName(string interfaceName)
		{
			if (this.curMobileModemName != null)
			{
				return this.curMobileModemName;
			}
			bool flag = false;
			List<string> list = new List<string>();
			string text = "Modem_" + interfaceName;
			int num = 10;
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetMobileModemName");
				if (this.EnsureConnection())
				{
					string yachtRouterStoredCommentInfo = this.GetYachtRouterStoredCommentInfo(text);
					if (!string.IsNullOrEmpty(yachtRouterStoredCommentInfo))
					{
						return yachtRouterStoredCommentInfo;
					}
					this.Send("/interface/lte/print", true);
					list = this.Read();
					do
					{
						try
						{
							this.Send("/interface/lte/info");
							this.Send("=.id=" + interfaceName);
							this.Send(".tag=15", true);
							this.Send("/interface/lte/print", true);
							list = this.Read();
							this.Send("/cancel");
							this.Send(".tag=15", true);
							List<string> list2 = this.Read();
							list.AddRange(list2);
							if (!list2.Contains("!done.tag=15"))
							{
								list.AddRange(this.Read());
							}
							for (int i = 0; i < list.Count; i++)
							{
								if (list[i].Contains("manufacturer"))
								{
									this.curMobileModemName = yrUtils.ExtractInfo(list[i], "model=");
									if (!(this.curMobileModemName == string.Empty))
									{
										this.CreateBridge(text);
										this.EnableDisableInterfacePhysical(text, false);
										this.SetYachtRouterStoredCommentInfo(text, this.curMobileModemName);
										return this.curMobileModemName;
									}
								}
							}
							bool flag2 = false;
							foreach (string item in list)
							{
								if (item.Contains("!trap.tag=15=message=no such item"))
								{
									flag2 = true;
									break;
								}
								if (item.Contains("!trap.tag=15=message=failure"))
								{
									flag2 = true;
									flag = true;
									break;
								}
							}
							if (flag2)
							{
								if (flag)
								{
									this.EnableDisableInterfacePhysical(interfaceName, false);
								}
								continue;
							}
						}
						catch (Exception ex)
						{
							this._curLogger.LogException(ex);
						}
						Thread.Sleep(500);
					}
					while (num-- > 0);
				}
			}
			catch (Exception ex2)
			{
				this._curLogger.LogException(ex2);
			}
			finally
			{
				if (flag)
				{
					this.EnableDisableInterfacePhysical(interfaceName, true);
				}
				this.AccessToRouterLock.ExitWriteLock("GetMobileModemName");
			}
			return string.Empty;
		}

		public bool GetIsReloadSimAvailable()
		{
			string routerModelName = this.GetRouterModelName();
			if (!string.IsNullOrEmpty(routerModelName) && routerModelName.StartsWith("4"))
			{
				return false;
			}
			return true;
		}

		public bool GetIsHighSpeedWIFISSIDisAvailable()
		{
			string routerModelName = this.GetRouterModelName();
			if (!string.IsNullOrEmpty(routerModelName) && !routerModelName.ToLower().StartsWith("922UAGS-5HPacD".ToLower()))
			{
				return false;
			}
			return true;
		}

		public bool GetIsDualFrequencyWIFISSIDisAvailable()
		{
			string routerModelName = this.GetRouterModelName();
			if (!string.IsNullOrEmpty(routerModelName) && !routerModelName.ToLower().Contains("962uigs-5hact2hnt".ToLower()))
			{
				return false;
			}
			return true;
		}

		public string GetRouterModelName()
		{
			if (this.curRouterModelName != null)
			{
				return this.curRouterModelName;
			}
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetRouterModelName");
				int num;
				if (this.EnsureConnection())
				{
					this.Send("/system/routerboard/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					num = 0;
					goto IL_008d;
				}
				goto end_IL_0018;
				IL_008d:
				if (num < list.Count)
				{
					return this.curRouterModelName = yrUtils.ExtractInfo(list[num], "model=");
				}
				goto end_IL_0018;
				IL_0089:
				num++;
				goto IL_008d;
				end_IL_0018:;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetRouterModelName");
			}
			return string.Empty;
		}

		public string GetRouterSerial()
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetRouterSerial");
				int num;
				if (this.EnsureConnection())
				{
					this.Send("/system/routerboard/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					num = 0;
					goto IL_0068;
				}
				goto end_IL_0006;
				IL_0068:
				if (num < list.Count)
				{
					return list[num];
				}
				goto end_IL_0006;
				IL_0064:
				num++;
				goto IL_0068;
				end_IL_0006:;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetRouterSerial");
			}
			return string.Empty;
		}

		public RouterStatuses CheckAndResolveModemPin()
		{
			try
			{
				this.EnableDisablePortRemoteAccess("usb2", true);
				IPEndPoint iPEndPoint = new IPEndPoint(IPAddress.Parse(this._routerIP), 10000);
				TcpClient tcpClient = new TcpClient(this._routerIP, 10000);
				NetworkStream stream = tcpClient.GetStream();
				string yachtRouterStoredCommentInfo = this.GetYachtRouterStoredCommentInfo("YachtRouterWanModemPIN");
				string yachtRouterStoredCommentInfo2 = this.GetYachtRouterStoredCommentInfo("YachtRouterWanModemPUK");
				try
				{
					string text;
					do
					{
						text = this.Send3gModemCommand(stream, "AT+CPIN?");
						if (text.IndexOf("+CPIN: READY") != -1)
						{
							text = this.Send3gModemCommand(stream, "AT+COPS=0,1");
							return RouterStatuses.MobilePinOk;
						}
						if (text.IndexOf("+CME ERROR") != -1)
						{
							return RouterStatuses.MobileSimCardNotPresent;
						}
						if (text.IndexOf("+CPIN: SIM PIN") != -1)
						{
							text = this.Send3gModemCommand(stream, "AT+CPIN=\"" + yachtRouterStoredCommentInfo + "\"");
							text = this.Send3gModemCommand(stream, "AT+CPIN?");
							do
							{
								Thread.Sleep(500);
								text = this.Send3gModemCommand(stream, "AT+CPIN?");
							}
							while (text.IndexOf("SIM busy") != -1);
							if (text.IndexOf("+CPIN: READY") != -1)
							{
								text = this.Send3gModemCommand(stream, "AT+COPS=0,1");
								return RouterStatuses.MobilePinOk;
							}
							if (text.IndexOf("+CPIN: SIM PUK") != -1)
							{
								return RouterStatuses.MobilePukError;
							}
							if (text.IndexOf("+CPIN: SIM PIN") == -1 && text.IndexOf("ERROR") == -1)
							{
								text = this.Send3gModemCommand(stream, "AT+COPS=0,1");
								return RouterStatuses.MobilePinOk;
							}
							return RouterStatuses.MobilePinError;
						}
					}
					while (text.IndexOf("+CPIN: SIM PUK") == -1);
					text = this.Send3gModemCommand(stream, "AT+CPIN=\"" + yachtRouterStoredCommentInfo2 + "\",\"" + yachtRouterStoredCommentInfo + "\"");
					text = this.Send3gModemCommand(stream, "AT+CPIN?");
					text = this.Send3gModemCommand(stream, "AT+CPIN?");
					if (text.IndexOf("+CPIN: SIM PUK") != -1)
					{
						return RouterStatuses.MobilePukError;
					}
					text = this.Send3gModemCommand(stream, "AT+COPS=0,1");
					return RouterStatuses.MobilePinOk;
				}
				finally
				{
					stream.Close();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.EnableDisablePortRemoteAccess("usb2", false);
			}
			return RouterStatuses.MobilePinOk;
		}

		private void EnableDisablePortRemoteAccess(string Port, bool NewState)
		{
			string str = this.RetrievePortRemoteAccess(Port);
			try
			{
				this.AccessToRouterLock.EnterWriteLock("EnableDisablePortRemoteAccess");
				if (this.EnsureConnection())
				{
					if (NewState)
					{
						this.Send("/port/remote-access/enable");
					}
					else
					{
						this.Send("/port/remote-access/disable");
					}
					this.Send("=.id=" + str, true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("EnableDisablePortRemoteAccess");
			}
		}

		private string RetrievePortRemoteAccess(string Port)
		{
			string result = string.Empty;
			try
			{
				this.AccessToRouterLock.EnterWriteLock("RetrievePortRemoteAccess");
				if (this.EnsureConnection())
				{
					this.Send("/port/remote-access/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf("=port=" + Port) != -1)
						{
							result = yrUtils.ExtractInfo(list[i], ".id=");
							return result;
						}
					}
					return result;
				}
				return result;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return result;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("RetrievePortRemoteAccess");
			}
		}

		private string Send3gModemCommand(NetworkStream streamer, string Command)
		{
			byte[] bytes = Encoding.ASCII.GetBytes(Command + "\r\n");
			streamer.Write(bytes, 0, bytes.Length);
			byte[] array = new byte[65535];
			int count = streamer.Read(array, 0, array.Length);
			string @string = Encoding.ASCII.GetString(array, 0, count);
			this._curLogger.LogMessage("3G Modem Command: " + Command);
			this._curLogger.LogMessage("3G Modem Response: " + @string);
			return @string;
		}

		public void SetMobileRoamingControl(bool EnableRoaming)
		{
			try
			{
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.EnableDisablePortRemoteAccess("usb2", false);
			}
		}

		public YachtRouterConfigWifiAP GetShipWifiConfiguration(string ShipWifiInterface, YachtRouterConfigWifiAP config)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetShipWifiConfiguration");
				if (this.EnsureConnection())
				{
					this.Send("/interface/wireless/security-profiles/print", true);
					List<string> list = this.Read();
					int num = 0;
					while (num < list.Count)
					{
						if (list[num].IndexOf(config.WiFiSecurityProfile) == -1)
						{
							num++;
							continue;
						}
						config.WiFiSecurityPassword = yrUtils.ExtractInfo(list[num], "wpa-pre-shared-key=");
						break;
					}
					this.Send("/interface/wireless/print", true);
					list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf(ShipWifiInterface) != -1)
						{
							config.WiFiAPN = yrUtils.ExtractInfo(list[i], "ssid=");
							return config;
						}
					}
					return config;
				}
				return config;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return config;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetShipWifiConfiguration");
			}
		}

		public void SetShipWifiConfiguration(string ShipWifiInterface, YachtRouterConfigWifiAP config, bool ChangeSSID, bool ChangePassowrd)
		{
			this._SetShipWifiConfiguration(ShipWifiInterface, config, ChangeSSID, ChangePassowrd);
		}

		private void _SetShipWifiConfiguration(string ShipWifiInterface, YachtRouterConfigWifiAP config, bool ChangeSSID, bool ChangePassowrd)
		{
			try
			{
				if (ChangePassowrd)
				{
					this.SetWifiInterfacePassword(config.WiFiSecurityProfile, config.WiFiSecurityPassword, false);
				}
				if (ChangeSSID)
				{
					this.SetWifiInterfaceSSID(ShipWifiInterface, config.WiFiAPN);
				}
				this.HotspotEnableDisable(ShipWifiInterface, config.HotspotEnabled);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
			}
		}

		private bool CheckLanDisableFilterRuleStatus(YachtRouterConfigLAN yrc)
		{
			return this.CheckFirewallFilterRuleStatus(yrc.FirewallRule);
		}

		public bool CheckIsInterfaceEnabled(object YachtRouterInterfaceConfiguration)
		{
			if (!(YachtRouterInterfaceConfiguration is YachtRouterConfigWANLan) && !(YachtRouterInterfaceConfiguration is YachtRouterConfigWANWifi))
			{
				return this.CheckIsInerfaceEnabledPhysical(YachtRouterInterfaceConfiguration);
			}
			YachtRouterConfigInterfaceBase yachtRouterConfigInterfaceBase = YachtRouterInterfaceConfiguration as YachtRouterConfigInterfaceBase;
			return this.CheckEnabledDisabledRouteStatus(yachtRouterConfigInterfaceBase.InterfaceName);
		}

		public bool CheckIsInerfaceEnabledPhysical(object YachtRouterInterfaceConfiguration)
		{
			try
			{
				if (!this.SuspendUpdates)
				{
					if (YachtRouterInterfaceConfiguration is YachtRouterConfigLAN)
					{
						return this.CheckLanDisableFilterRuleStatus(YachtRouterInterfaceConfiguration as YachtRouterConfigLAN);
					}
					if (YachtRouterInterfaceConfiguration is YachtRouterConfigInterfaceBase)
					{
						YachtRouterConfigInterfaceBase yachtRouterConfigInterfaceBase = YachtRouterInterfaceConfiguration as YachtRouterConfigInterfaceBase;
						return this.CheckIsInterfaceEnabledPhysicalByInterface(yachtRouterConfigInterfaceBase.InterfaceName);
					}
				}
			}
			catch (Exception ex)
			{
				this.FireNewInfo("Error Getting Router Status: " + ex.Message);
			}
			return false;
		}

		public bool CheckIsInterfaceExistingPhysicalByInterface(string InterfaceName)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CheckIsInterfaceEnabled");
				if (this.EnsureConnection())
				{
					this.Send("/interface/print", true);
					list = this.Read();
					if (!list.Last().StartsWith("!done"))
					{
						list = this.Read();
					}
				}
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CheckIsInterfaceEnabled");
			}
			for (int i = 0; i < list.Count; i++)
			{
				if (list[i].IndexOf("name=" + InterfaceName) != -1)
				{
					return true;
				}
			}
			return false;
		}

		public bool CheckIsInterfaceEnabledPhysicalByInterface(string InterfaceName)
		{
			List<string> list = new List<string>();
			try
			{
				bool flag;
				do
				{
					flag = false;
					this.AccessToRouterLock.EnterWriteLock("CheckIsInterfaceEnabledPhysicalByInterface");
					if (this.EnsureConnection())
					{
						this.Send("/interface/print", true);
						list = this.Read();
						flag = false;
						int num = 0;
						while (num < list.Count)
						{
							if (list[num].IndexOf("name=" + InterfaceName) == -1)
							{
								num++;
								continue;
							}
							flag = true;
							break;
						}
						if (!list.Last().StartsWith("!done") || !flag)
						{
							list = this.Read();
						}
					}
					int num2 = 0;
					while (num2 < list.Count)
					{
						if (list[num2].IndexOf("name=" + InterfaceName) == -1)
						{
							num2++;
							continue;
						}
						flag = true;
						break;
					}
				}
				while (!flag);
				for (int i = 0; i < list.Count; i++)
				{
					if (list[i].IndexOf("name=" + InterfaceName) != -1)
					{
						if (list[i].IndexOf("disabled=true") == -1)
						{
							return true;
						}
						return false;
					}
				}
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CheckIsInterfaceEnabledPhysicalByInterface");
			}
			return false;
		}

		public void EnableDisableInterface(object YachtRouterInterfaceConfiguration, bool NewState)
		{
			YachtRouterConfigInterfaceBase yachtRouterConfigInterfaceBase = YachtRouterInterfaceConfiguration as YachtRouterConfigInterfaceBase;
			if (YachtRouterInterfaceConfiguration is YachtRouterConfigWANLan || YachtRouterInterfaceConfiguration is YachtRouterConfigWANWifi)
			{
				this.EnableDisableRoute(yachtRouterConfigInterfaceBase.InterfaceName, NewState);
			}
			else
			{
				this.EnableDisableInterfacePhysical(yachtRouterConfigInterfaceBase.InterfaceName, NewState);
			}
		}

		public void EnableDisableInterfacePhysical(string Interface, bool NewState)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("EnableDisableInterface");
				if (this.EnsureConnection())
				{
					if (NewState)
					{
						this.Send("/interface/enable");
					}
					else
					{
						this.Send("/interface/disable");
					}
					this.Send("=.id=" + Interface, true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("EnableDisableInterface");
			}
		}

		public void EnableDisableSchedulers(string Scheduler, string newState)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("EnableDisableSchedulers");
				if (this.EnsureConnection())
				{
					this.Send("/system/scheduler/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					int num = 0;
					while (true)
					{
						if (num < list.Count)
						{
							if (list[num].IndexOf("name=" + Scheduler) == -1)
							{
								num++;
								continue;
							}
							break;
						}
						return;
					}
					string str = yrUtils.ExtractInfo(list[num], ".id=");
					if (newState.ToLower() == "true")
					{
						this.Send("/system/scheduler/enable");
					}
					else
					{
						this.Send("/system/scheduler/disable");
					}
					this.Send("=.id=" + str, true);
					list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("EnableDisableSchedulers");
			}
		}

		public string CheckEnabledDisabledScheduler(string SchedulerName)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CheckEnabledDisabledScheduler");
				if (this.EnsureConnection())
				{
					this.Send("/system/scheduler/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf("name=" + SchedulerName) != -1)
						{
							if (list[i].IndexOf("=disabled=true") == -1)
							{
								return "true";
							}
							return "false";
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CheckEnabledDisabledScheduler");
			}
			return "yes";
		}

		public void EnableRouteToRouterIDDisableOtherRoutes(string RouteBase, string TargetRouterID)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("EnableRouteToRouterIDDisableOtherRoutes");
				if (this.EnsureConnection())
				{
					this.Send("/ip/route/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf("comment=" + RouteBase) != -1)
						{
							string str = yrUtils.ExtractInfo(list[i], ".id=");
							string a = yrUtils.ExtractInfo(list[i], "comment=");
							if (a == RouteBase + TargetRouterID)
							{
								this.Send("/ip/route/enable");
							}
							else
							{
								this.Send("/ip/route/disable");
							}
							this.Send("=.id=" + str, true);
							List<string> list2 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("EnableRouteToRouterIDDisableOtherRoutes");
			}
		}

		public void EnableDisableRoute(string RouteComment, bool newState)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("EnableDisableRoute");
				if (this.EnsureConnection())
				{
					this.Send("/ip/route/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					int num = 0;
					while (true)
					{
						if (num < list.Count)
						{
							if (list[num].IndexOf("comment=" + RouteComment) == -1)
							{
								num++;
								continue;
							}
							break;
						}
						return;
					}
					string str = yrUtils.ExtractInfo(list[num], ".id=");
					if (newState)
					{
						this.Send("/ip/route/enable");
					}
					else
					{
						this.Send("/ip/route/disable");
					}
					this.Send("=.id=" + str, true);
					list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("EnableDisableRoute");
			}
		}

		public bool CheckEnabledDisabledRouteStatus(string RouteComment)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CheckEnabledDisabledRouteStatus");
				if (this.EnsureConnection())
				{
					this.Send("/ip/route/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf("comment=" + RouteComment) != -1)
						{
							if (list[i].IndexOf("=disabled=true") == -1)
							{
								return true;
							}
							return false;
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CheckEnabledDisabledRouteStatus");
			}
			return false;
		}

		public void EnableDisablFirewallRule(string RuleComment, bool newState)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("EnableDisableFirewallRule");
				if (this.EnsureConnection())
				{
					this.Send("/ip/firewall/filter/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf("comment=" + RuleComment) != -1)
						{
							string str = yrUtils.ExtractInfo(list[i], ".id=");
							if (!newState)
							{
								this.Send("/ip/firewall/filter/enable");
							}
							else
							{
								this.Send("/ip/firewall/filter/disable");
							}
							this.Send("=.id=" + str, true);
							List<string> list2 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("EnableDisableFirewallRule");
			}
		}

		public void EnableDisableIPAddress(string Interface, bool newState)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("EnableDisableIPAddress");
				if (this.EnsureConnection())
				{
					this.Send("/ip/address/print", true);
					List<string> list = this.Read();
					string str = string.Empty;
					int num = 0;
					while (num < list.Count)
					{
						if (!(yrUtils.ExtractInfo(list[num], "interface").ToLower() == Interface.ToLower()))
						{
							num++;
							continue;
						}
						str = yrUtils.ExtractInfo(list[num], ".id=");
						break;
					}
					if (newState)
					{
						this.Send("/ip/address/enable");
					}
					else
					{
						this.Send("/ip/address/disable");
					}
					this.Send("=.id=" + str, true);
					list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("EnableDisableIPAddress");
			}
		}

		public bool CheckFirewallFilterRuleStatus(string FirewallRuleComment)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CheckFirewallFilterRuleStatus");
				if (this.EnsureConnection())
				{
					this.Send("/ip/firewall/filter/print", true);
					List<string> list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					if (list != null && list.Count > 0)
					{
						for (int i = 0; i < list.Count; i++)
						{
							if (list[i].IndexOf("comment=" + FirewallRuleComment) != -1)
							{
								if (list[i].IndexOf("disabled=false") != -1)
								{
									return false;
								}
								return true;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CheckFirewallFilterRuleStatus");
			}
			return false;
		}

		public void RouteSetTargetTo(string routingMark, string Target)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("RouteSetTargetTo");
				if (this.EnsureConnection())
				{
					this.Send("/ip/route/print");
					this.Send("=detail=", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf("routing-mark=" + routingMark) != -1)
						{
							string str = yrUtils.ExtractInfo(list[i], ".id=");
							this.Send("/ip/route/set");
							this.Send("=.id=" + str);
							this.Send("=comment=" + Target, true);
							this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("RouteSetTargetTo");
			}
		}

		public void RouteSetTargetToNew(string oldTarget, string newTarget, string comment)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("RouteSetTargetTo");
				if (this.EnsureConnection())
				{
					this.Send("/ip/route/print");
					this.Send("=detail=", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf("dst-address=" + oldTarget) != -1 && list[i].IndexOf("comment=" + comment) != -1)
						{
							string str = yrUtils.ExtractInfo(list[i], ".id=");
							this.Send("/ip/route/set");
							this.Send("=.id=" + str);
							this.Send("=dst-address=" + newTarget);
							this.Send("=comment=" + comment, true);
							this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("RouteSetTargetTo");
			}
		}

		public void RouteSetTargetToNewByComment(string newGateway, string comment)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("RouteSetTargetToNewByComment");
				if (this.EnsureConnection())
				{
					this.Send("/ip/route/print");
					this.Send("=detail=", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].Contains("comment=" + comment))
						{
							string str = yrUtils.ExtractInfo(list[i], ".id=");
							this.Send("/ip/route/set");
							this.Send("=.id=" + str);
							this.Send("=gateway=" + newGateway);
							this.Send("=comment=" + comment, true);
							this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("RouteSetTargetToNewByComment");
			}
		}

		public List<string> RouteGetTargets()
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("RouteGetTargets");
				if (this.EnsureConnection())
				{
					this.Send("/ip/route/print");
					this.Send("=detail=", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					return list;
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("RouteGetTargets");
			}
			return new List<string>();
		}

		public string GetYachtRouterActiveWANLan()
		{
			return this.GetYachtRouterStoredCommentInfo("YachtRouterActiveWANLan");
		}

		public void SetYachtRouterActiveWANLan(string newPassword)
		{
			this.SetYachtRouterStoredCommentInfo("YachtRouterActiveWANLan", newPassword);
		}

		public string GetYachtRouterActiveWANMobile()
		{
			return this.GetYachtRouterStoredCommentInfo("YachtRouterActiveWANMobile");
		}

		public void SetYachtRouterActiveWANMobile(string newPassword)
		{
			this.SetYachtRouterStoredCommentInfo("YachtRouterActiveWANMobile", newPassword);
		}

		public string GetYachtRouterActiveWANWifi()
		{
			return this.GetYachtRouterStoredCommentInfo("YachtRouterActiveWANWifi");
		}

		public void SetYachtRouterActiveWANWifi(string newPassword)
		{
			this.SetYachtRouterStoredCommentInfo("YachtRouterActiveWANWifi", newPassword);
		}

		public string GetYachtRouterGUIScreenPassword()
		{
			return this.GetYachtRouterStoredCommentInfo("YachtRouterScreenSaverPassword");
		}

		public void SetYachtRouterGUIScreenPassword(string newPassword)
		{
			this.SetYachtRouterStoredCommentInfo("YachtRouterScreenSaverPassword", newPassword);
		}

		private string GetYachtRouterStoredCommentInfo(string Key)
		{
			try
			{
				List<string> list = new List<string>();
				try
				{
					this.AccessToRouterLock.EnterWriteLock(Key);
					if (this.EnsureConnection())
					{
						this.Send("/interface/print", true);
						list = this.Read();
						if (!list.Last().StartsWith("!done"))
						{
							list = this.Read();
						}
					}
				}
				finally
				{
					this.AccessToRouterLock.ExitWriteLock(Key);
				}
				for (int i = 0; i < list.Count; i++)
				{
					if (list[i].IndexOf("name=" + Key) != -1)
					{
						return yrUtils.ExtractInfo(list[i], "comment=");
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return string.Empty;
		}

		private void SetYachtRouterStoredCommentInfo(string Key, string Value)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock(Key);
				if (this.EnsureConnection())
				{
					this.Send("/interface/set");
					this.Send("=.id=" + Key);
					this.Send("=comment=" + Value, true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock(Key);
			}
		}

		public void SetWifiInterfacePassword(string WiFiSecurityProfile, string WiFiSecurityPassword, bool UseWEP)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("SetWifiInterfacePassword");
				if (this.EnsureConnection())
				{
					List<string> list = new List<string>();
					bool flag;
					do
					{
						this.Send("/interface/wireless/security-profiles/print");
						this.Send(".tag=11", true);
						list = this.Read();
						flag = false;
						for (int i = 0; i < list.Count; i++)
						{
							if (list[i].IndexOf("!done.tag=11") != -1)
							{
								flag = true;
							}
						}
					}
					while (!flag);
					string str = string.Empty;
					int num = 0;
					while (num < list.Count)
					{
						if (list[num].IndexOf(WiFiSecurityProfile) == -1)
						{
							num++;
							continue;
						}
						str = yrUtils.ExtractInfo(list[num], ".id");
						break;
					}
					if (UseWEP)
					{
						this.Send("/interface/wireless/security-profiles/set");
						this.Send("=.id=" + str);
						this.Send("=mode=static-keys-optional");
						this.Send("=static-algo-0=40bit-wep");
						this.Send("=static-key-0=" + WiFiSecurityPassword, true);
					}
					else if (WiFiSecurityPassword != string.Empty)
					{
						this.Send("/interface/wireless/security-profiles/set");
						this.Send("=.id=" + str);
						this.Send("=mode=dynamic-keys");
						this.Send("=wpa-pre-shared-key=" + WiFiSecurityPassword);
						this.Send("=wpa2-pre-shared-key=" + WiFiSecurityPassword, true);
					}
					else
					{
						this.Send("/interface/wireless/security-profiles/set");
						this.Send("=.id=" + str);
						this.Send("=mode=none");
						this.Send("=wpa-pre-shared-key=" + WiFiSecurityPassword);
						this.Send("=wpa2-pre-shared-key=" + WiFiSecurityPassword, true);
					}
					list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("SetWifiInterfacePassword");
			}
		}

		public void SetWifiInterfaceSSID(string InterfaceName, string newSSID)
		{
			try
			{
				if (this.GetIsHighSpeedWIFISSIDisAvailable())
				{
					newSSID += this.HighSpeedSSIDSuffix;
				}
				this.AccessToRouterLock.EnterWriteLock("SetWifiInterfaceSSID");
				if (newSSID != this.GetInterfaceSSID(InterfaceName) && this.EnsureConnection())
				{
					this.Send("/interface/wireless/set");
					this.Send("=.id=" + InterfaceName);
					this.Send("=ssid=" + newSSID, true);
					List<string> list = this.Read();
					if (this.GetIsDualFrequencyWIFISSIDisAvailable())
					{
						this.Send("/interface/wireless/set");
						this.Send("=.id=" + InterfaceName + "Ex");
						this.Send("=ssid=" + newSSID + this.HighSpeedSSIDSuffix, true);
						list = this.Read();
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("SetWifiInterfaceSSID");
			}
		}

		public void SetWifiInterfaceSSIDVisibility(string InterfaceName, bool Visible)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("SetWifiInterfaceSSIDVisibility");
				if (this.EnsureConnection())
				{
					this.Send("/interface/wireless/set");
					this.Send("=.id=" + InterfaceName);
					this.Send("=hide-ssid=" + (!Visible).ToString().ToLower(), true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("SetWifiInterfaceSSIDVisibility");
			}
		}

		public string[] GetMonitorTrafficRXTXForInterface(string Interface, int tag)
		{
			string[] array = new string[2]
			{
				"0",
				"0"
			};
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetMonitorTrafficRXTXForInterface");
				if (this.EnsureConnection())
				{
					this.Send("/int/monitor-traffic");
					this.Send("=interface=" + Interface);
					this.Send(".tag=" + tag.ToString(), true);
					List<string> list = this.Read(true, 1);
					this.Send("/cancel");
					this.Send(".tag=" + tag.ToString(), true);
					List<string> list2 = this.Read();
					List<string> list3 = this.Read();
					{
						foreach (string item in list)
						{
							if (item.Contains(".tag=" + tag.ToString()))
							{
								array[0] = yrUtils.ExtractInfo(item, "=rx-bits-per-second");
								array[1] = yrUtils.ExtractInfo(item, "=tx-bits-per-second");
								return array;
							}
						}
						return array;
					}
				}
				return array;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return array;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetMonitorTrafficRXTXForInterface");
			}
		}

		public string GetWanInterfaceTitle(string Interface)
		{
			try
			{
				int num = 0;
				bool flag = false;
				this.AccessToRouterLock.EnterWriteLock("GetWanInterfaceTitle");
				if (this.EnsureConnection())
				{
					List<string> list;
					while (true)
					{
						this.Send("/interface/print", true);
						list = this.Read();
						flag = false;
						int num2 = 0;
						while (num2 < list.Count)
						{
							if (list[num2].IndexOf("name=" + Interface) == -1)
							{
								num2++;
								continue;
							}
							flag = true;
							break;
						}
						if (!list.Last().StartsWith("!done") || !flag)
						{
							list = this.Read();
						}
						int num3 = 0;
						while (num3 < list.Count)
						{
							if (list[num3].IndexOf("name=" + Interface) == -1)
							{
								num3++;
								continue;
							}
							flag = true;
							break;
						}
						if (flag)
						{
							break;
						}
						num++;
						if (num <= 3)
						{
							continue;
						}
						throw new Exception("Interface missing");
					}
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf("=name=" + Interface) != -1)
						{
							return yrUtils.ExtractInfo(list[i], "comment=");
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetWanInterfaceTitle");
			}
			return string.Empty;
		}

		public void SetWanInterfaceTitle(string Interface, string newName)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("SetWanInterfaceName");
				if (this.EnsureConnection())
				{
					this.Send("/interface/set");
					this.Send("=.id=" + Interface);
					this.Send("=comment=" + newName, true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("SetWanInterfaceName");
			}
		}

		public void SetWanInterfaceAccessRules(YachtRouterConfigWANBase WanConfig)
		{
			this.EnableDisablFirewallRule(WanConfig.InterfaceName + "_ShipLAN_Disable", !WanConfig.RestrictExitToLAN);
			this.EnableDisablFirewallRule(WanConfig.InterfaceName + "_ShipWIFI1_Disable", !WanConfig.RestrictExitToShipWIFI1);
			this.EnableDisablFirewallRule(WanConfig.InterfaceName + "_ShipWIFI2_Disable", !WanConfig.RestrictExitToShipWIFI2);
		}

		public void GetWanInterfaceAccessRules(YachtRouterConfigWANBase WanConfig)
		{
			WanConfig.RestrictExitToLAN = !this.CheckFirewallFilterRuleStatus(WanConfig.InterfaceName + "_ShipLAN_Disable");
			WanConfig.RestrictExitToShipWIFI1 = !this.CheckFirewallFilterRuleStatus(WanConfig.InterfaceName + "_ShipWIFI1_Disable");
			WanConfig.RestrictExitToShipWIFI2 = !this.CheckFirewallFilterRuleStatus(WanConfig.InterfaceName + "_ShipWIFI2_Disable");
		}

		public bool GetIsDHCPClientEnabled(string Interface)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetIsDHCPClientEnabled");
				if (this.EnsureConnection())
				{
					this.Send("/ip/dhcp-client/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf(Interface) != -1)
						{
							string a = yrUtils.ExtractInfo(list[i], "comment=");
							if (a == string.Empty)
							{
								return true;
							}
							return false;
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetIsDHCPClientEnabled");
			}
			return false;
		}

		public bool SetDHCPClientCommentGateway(string Interface, string Gateway)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetIsDHCPClientEnabled");
				if (this.EnsureConnection())
				{
					this.Send("/ip/dhcp-client/print", true);
					List<string> list = this.Read();
					int num = 0;
					while (num < list.Count)
					{
						if (list[num].IndexOf(Interface) == -1)
						{
							num++;
							continue;
						}
						string str = yrUtils.ExtractInfo(list[num], ".id=");
						this.Send("/ip/dhcp-client/set");
						this.Send("=.id=" + str);
						if (Gateway == string.Empty)
						{
							this.Send("=disabled=false");
						}
						else
						{
							this.Send("=disabled=true");
						}
						this.Send("=comment=" + Gateway, true);
						list = this.Read();
						break;
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetIsDHCPClientEnabled");
			}
			return false;
		}

		public void SetIpAndDhcp(string Interface, string ip, string subnet, string gateway, string dns1, string dns2, bool UseDhcpClient)
		{
			try
			{
				if (!UseDhcpClient)
				{
					this.SetDHCPClientCommentGateway(Interface, gateway);
					this.SetIPAddress(Interface, ip, subnet);
					this.EnableDisableIPAddress(Interface, true);
					if (!string.IsNullOrEmpty(dns1.Trim()))
					{
						if (!string.IsNullOrEmpty(dns2.Trim()))
						{
							this.SetDNSes(new string[2]
							{
								dns1,
								dns2
							});
						}
						else
						{
							this.SetDNSes(new string[1]
							{
								dns1
							});
						}
					}
					else
					{
						this.SetDNSes(new string[0]);
					}
				}
				else
				{
					this.SetDHCPClientCommentGateway(Interface, string.Empty);
					this.SetIPAddress(Interface, "10.254.254.254", "255.255.255.0");
					this.EnableDisableIPAddress(Interface, false);
					this.SetDNSes(new string[0]);
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void SetIsDHCPClientEnabled(string Interface, bool newState)
		{
		}

		public void RenewDHCPClient(string Interface)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("RenewDHCPClient");
				if (this.EnsureConnection())
				{
					this.Send("/ip/dhcp-client/print", true);
					string str = string.Empty;
					List<string> list = this.Read();
					int num = 0;
					while (num < list.Count)
					{
						if (list[num].IndexOf(Interface) == -1)
						{
							num++;
							continue;
						}
						str = yrUtils.ExtractInfo(list[num], ".id=");
						break;
					}
					this.Send("/ip/dhcp-client/renew");
					this.Send("=.id=" + str, true);
					list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("RenewDHCPClient");
			}
		}

		private string[] GetDHCPAddresses(string Interface)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetDHCPAddresses");
				if (this.EnsureConnection())
				{
					this.Send("/ip/dhcp-client/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf(Interface) != -1)
						{
							string text = yrUtils.ExtractInfo(list[i], "address=");
							if (text != string.Empty)
							{
								string[] array = text.Split('/');
								string text2 = array[0];
								string text3 = this.ConvertCDIRtoSubnetMask(array[1]);
								string text4 = yrUtils.ExtractInfo(list[i], "gateway=");
								string text5 = yrUtils.ExtractInfo(list[i], "primary-dns=");
								string text6 = yrUtils.ExtractInfo(list[i], "secondary-dns=");
								return new string[5]
								{
									text2,
									text3,
									text4,
									text5,
									text6
								};
							}
							return new string[5]
							{
								"0.0.0.0",
								"255.255.255.0",
								"0.0.0.0",
								"0.0.0.0",
								"0.0.0.0"
							};
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetDHCPAddresses");
			}
			return new string[5]
			{
				"0.0.0.0",
				"255.255.255.0",
				"0.0.0.0",
				"0.0.0.0",
				"0.0.0.0"
			};
		}

		private string[] GetIPAddress(string Interface)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetIPAddress");
				if (this.EnsureConnection())
				{
					this.Send("/ip/address/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (yrUtils.ExtractInfo(list[i], "interface").ToLower() == Interface.ToLower())
						{
							string text = yrUtils.ExtractInfo(list[i], "address=");
							string[] array = text.Split('/');
							return new string[2]
							{
								array[0],
								this.ConvertCDIRtoSubnetMask(array[1])
							};
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetIPAddress");
			}
			return new string[2]
			{
				"0.0.0.0",
				"255.255.255.0"
			};
		}

		private string[] SetIPAddress(string Interface, string newIPAdress, string SubnetMask)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("SetIPAddress");
				if (this.EnsureConnection())
				{
					this.Send("/ip/address/print", true);
					List<string> list = this.Read();
					string text = "notfound";
					int num = 0;
					while (num < list.Count)
					{
						if (!(yrUtils.ExtractInfo(list[num], "interface").ToLower() == Interface.ToLower()))
						{
							num++;
							continue;
						}
						text = yrUtils.ExtractInfo(list[num], ".id=");
						break;
					}
					if (text != "notfound")
					{
						this.Send("/ip/address/set");
						this.Send("=.id=" + text);
						this.Send("=address=" + newIPAdress + this.ConvertSubnetMaskToCDIR(SubnetMask), true);
						list = this.Read();
						goto end_IL_0000;
					}
					throw new Exception("IP Address Set Erorr");
				}
				end_IL_0000:;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("SetIPAddress");
			}
			return new string[2]
			{
				"0.0.0.0",
				"255.255.255.0"
			};
		}

		private string[] GetDNSes()
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetDNSes");
				if (this.EnsureConnection())
				{
					this.Send("/ip/dns/print", true);
					List<string> list = this.Read();
					string text = string.Empty;
					string text2 = string.Empty;
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf("primary-dns") != -1)
						{
							text = yrUtils.ExtractInfo(list[i], "primary-dns=");
						}
						if (list[i].IndexOf("secondary-dns") != -1)
						{
							text2 = yrUtils.ExtractInfo(list[i], "secondary-dns=");
						}
						if (list[i].IndexOf("servers") != -1)
						{
							string[] array = yrUtils.ExtractInfo(list[i], "servers=").Split(',');
							if (array.Count() > 0)
							{
								text = array[0];
							}
							if (array.Count() > 1)
							{
								text2 = array[1];
							}
						}
					}
					return new string[2]
					{
						text,
						text2
					};
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetDNSes");
			}
			return new string[1]
			{
				"0.0.0.0"
			};
		}

		private void SetDNSes(string[] dnses)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("SetDNSes");
				if (this.EnsureConnection())
				{
					string text = string.Empty;
					foreach (string str in dnses)
					{
						text = text + str + ",";
					}
					text = text.TrimEnd(',');
					this.Send("/ip/dns/set");
					this.Send("=servers=" + text, true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("SetDNSes");
			}
		}

		private string ConvertSubnetMaskToCDIR(string subnetMask)
		{
			if (subnetMask != null)
			{
				if (MK._003C_003Ef__switch_0024map0 == null)
				{
					Dictionary<string, int> dictionary = new Dictionary<string, int>(24);
					dictionary.Add("255.0.0.0", 0);
					dictionary.Add("255.128.0.0", 1);
					dictionary.Add("255.192.0.0", 2);
					dictionary.Add("255.224.0.0", 3);
					dictionary.Add("255.240.0.0", 4);
					dictionary.Add("255.248.0.0", 5);
					dictionary.Add("255.252.0.0", 6);
					dictionary.Add("255.254.0.0", 7);
					dictionary.Add("255.255.0.0", 8);
					dictionary.Add("255.255.128.0", 9);
					dictionary.Add("255.255.192.0", 10);
					dictionary.Add("255.255.224.0", 11);
					dictionary.Add("255.255.240.0", 12);
					dictionary.Add("255.255.248.0", 13);
					dictionary.Add("255.255.252.0", 14);
					dictionary.Add("255.255.254.0", 15);
					dictionary.Add("255.255.255.0", 16);
					dictionary.Add("255.255.255.128", 17);
					dictionary.Add("255.255.255.192", 18);
					dictionary.Add("255.255.255.224", 19);
					dictionary.Add("255.255.255.240", 20);
					dictionary.Add("255.255.255.248", 21);
					dictionary.Add("255.255.255.252", 22);
					dictionary.Add("255.255.255.254", 23);
					MK._003C_003Ef__switch_0024map0 = dictionary;
				}
				int num = default(int);
				if (MK._003C_003Ef__switch_0024map0.TryGetValue(subnetMask, out num))
				{
					switch (num)
					{
					case 0:
						return "/8";
					case 1:
						return "/9";
					case 2:
						return "/10";
					case 3:
						return "/11";
					case 4:
						return "/12";
					case 5:
						return "/13";
					case 6:
						return "/14";
					case 7:
						return "/15";
					case 8:
						return "/16";
					case 9:
						return "/17";
					case 10:
						return "/18";
					case 11:
						return "/19";
					case 12:
						return "/20";
					case 13:
						return "/21";
					case 14:
						return "/22";
					case 15:
						return "/23";
					case 16:
						return "/24";
					case 17:
						return "/25";
					case 18:
						return "/26";
					case 19:
						return "/27";
					case 20:
						return "/28";
					case 21:
						return "/29";
					case 22:
						return "/30";
					case 23:
						return "/31";
					}
				}
			}
			return "32";
		}

		private string ConvertCDIRtoSubnetMask(string CDIR)
		{
			if (CDIR != null)
			{
				if (MK._003C_003Ef__switch_0024map1 == null)
				{
					Dictionary<string, int> dictionary = new Dictionary<string, int>(24);
					dictionary.Add("8", 0);
					dictionary.Add("9", 1);
					dictionary.Add("10", 2);
					dictionary.Add("11", 3);
					dictionary.Add("12", 4);
					dictionary.Add("13", 5);
					dictionary.Add("14", 6);
					dictionary.Add("15", 7);
					dictionary.Add("16", 8);
					dictionary.Add("17", 9);
					dictionary.Add("18", 10);
					dictionary.Add("19", 11);
					dictionary.Add("20", 12);
					dictionary.Add("21", 13);
					dictionary.Add("22", 14);
					dictionary.Add("23", 15);
					dictionary.Add("24", 16);
					dictionary.Add("25", 17);
					dictionary.Add("26", 18);
					dictionary.Add("27", 19);
					dictionary.Add("28", 20);
					dictionary.Add("29", 21);
					dictionary.Add("30", 22);
					dictionary.Add("31", 23);
					MK._003C_003Ef__switch_0024map1 = dictionary;
				}
				int num = default(int);
				if (MK._003C_003Ef__switch_0024map1.TryGetValue(CDIR, out num))
				{
					switch (num)
					{
					case 0:
						return "255.0.0.0";
					case 1:
						return "255.128.0.0";
					case 2:
						return "255.192.0.0";
					case 3:
						return "255.224.0.0";
					case 4:
						return "255.240.0.0";
					case 5:
						return "255.248.0.0";
					case 6:
						return "255.252.0.0";
					case 7:
						return "255.254.0.0";
					case 8:
						return "255.255.0.0";
					case 9:
						return "255.255.128.0";
					case 10:
						return "255.255.192.0";
					case 11:
						return "255.255.224.0";
					case 12:
						return "255.255.240.0";
					case 13:
						return "255.255.248.0";
					case 14:
						return "255.255.252.0";
					case 15:
						return "255.255.254.0";
					case 16:
						return "255.255.255.0";
					case 17:
						return "255.255.255.128";
					case 18:
						return "255.255.255.192";
					case 19:
						return "255.255.255.224";
					case 20:
						return "255.255.255.240";
					case 21:
						return "255.255.255.248";
					case 22:
						return "255.255.255.252";
					case 23:
						return "255.255.255.254";
					}
				}
			}
			return "255.255.255.0";
		}

		private void ConfigureRouteToPointToGateway(string Interface, string GatewayIP)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("ConfigureRouteToPointToGateway");
				if (this.EnsureConnection())
				{
					this.Send("/ip/route/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					if (GatewayIP == "0.0.0.0")
					{
						GatewayIP = "10.1.1.1";
					}
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf("=comment=" + Interface) != -1)
						{
							string str = yrUtils.ExtractInfo(list[i], ".id=");
							this.Send("/ip/route/set");
							this.Send("=.id=" + str);
							this.Send("=gateway=" + GatewayIP, true);
							List<string> list2 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("ConfigureRouteToPointToGateway");
			}
		}

		private string GetGatewayFromRoute(string Interface)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetGatewayFromRoute");
				if (this.EnsureConnection())
				{
					this.Send("/ip/route/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf("comment=" + Interface) != -1)
						{
							return yrUtils.ExtractInfo(list[i], "gateway=");
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetGatewayFromRoute");
			}
			return "0.0.0.0";
		}

		public bool RouterConfigurationsBackup(string BackupName)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("RouterConfigurationsBackup");
				if (this.EnsureConnection())
				{
					this.Send("/system/backup/save");
					this.Send("=name=" + BackupName, true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						return false;
					}
					this.Send("/system/backup/save");
					this.Send("=name=flash/" + BackupName, true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						return false;
					}
					return true;
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("RouterConfigurationsBackup");
			}
			return false;
		}

		public bool RouterConfigurationRestore(string BackupName)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("RouterConfigurationRestore");
				if (this.EnsureConnection())
				{
					this.Send("/system/backup/load");
					this.Send("=name=flash/" + BackupName, true);
				}
				if (this.EnsureConnection())
				{
					this.Send("/system/backup/load");
					this.Send("=name=" + BackupName, true);
					return true;
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("RouterConfigurationRestore");
			}
			return false;
		}

		public void EnableDisableWWWService(bool newState)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("EnableDisableWWWService");
				if (this.EnsureConnection())
				{
					this.Send("/ip/service/print", true);
					string str = string.Empty;
					List<string> list = this.Read();
					int num = 0;
					while (num < list.Count)
					{
						if (list[num].IndexOf("=www=") == -1)
						{
							num++;
							continue;
						}
						str = yrUtils.ExtractInfo(list[num], ".id=");
						break;
					}
					this.Send("/ip/service/set");
					this.Send("=.id=" + str);
					if (newState)
					{
						this.Send("=disabled=no", true);
					}
					else
					{
						this.Send("=disabled=yes", true);
					}
					list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("EnableDisableWWWService");
			}
		}

		public List<string> GetRouterLog()
		{
			List<string> result = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("SetYachtRouterSupportIP");
				if (this.EnsureConnection())
				{
					this.Send("/log/print", true);
					result = this.Read();
					return result;
				}
				return result;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return result;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("SetYachtRouterSupportIP");
			}
		}

		public void SetYachtRouterSupportIP(string InterfaceName, string YachtRouterSupportIP)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("SetYachtRouterSupportIP");
				if (this.EnsureConnection())
				{
					List<string> list = new List<string>();
					this.Send("/interface/sstp-client/set");
					this.Send("=.id=" + InterfaceName);
					this.Send("=connect-to=" + YachtRouterSupportIP.Trim() + ":443", true);
					list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("SetYachtRouterSupportIP");
			}
		}

		public List<string> CheckYachtRouterVPNConnection(string InterfaceName)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("SetYachtRouterSupportIP");
				if (this.EnsureConnection())
				{
					this.Send("/interface/sstp-client/print", true);
					list = this.Read();
					string str = string.Empty;
					int num = 0;
					while (num < list.Count)
					{
						if (list[num].IndexOf("=name=" + InterfaceName) == -1)
						{
							num++;
							continue;
						}
						str = yrUtils.ExtractInfo(list[num], ".id=");
						break;
					}
					this.Send("/interface/sstp-client/monitor");
					this.Send("=.id=" + str, true);
					list = this.Read(true, 6);
					this.Send("/cancel", true);
					List<string> list2 = this.Read();
					List<string> list3 = this.Read();
					return list;
				}
				return list;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return list;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("SetYachtRouterSupportIP");
			}
		}

		public List<YachtRouterConfigHotspotUser> GetHotspotUsers(string HotspotName)
		{
			List<YachtRouterConfigHotspotUser> list = new List<YachtRouterConfigHotspotUser>();
			List<string> list2 = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetHotspotUsers");
				if (this.EnsureConnection())
				{
					this.Send("/ip/hotspot/user/print", true);
					list2 = this.Read();
					for (int i = 0; i < list2.Count; i++)
					{
						if (list2[i].IndexOf("!done") == -1 && yrUtils.ExtractInfo(list2[i], "server") == HotspotName)
						{
							string name = yrUtils.ExtractInfo(list2[i], "name");
							string password = yrUtils.ExtractInfo(list2[i], "password");
							string text = yrUtils.ExtractInfo(list2[i], "limit-uptime");
							string text2 = yrUtils.ExtractInfo(list2[i], "limit-bytes-total");
							string usedTimeLimit = yrUtils.ExtractInfo(list2[i], "uptime");
							if (text == string.Empty)
							{
								text = "Unlimited";
							}
							text2 = ((!(text2 == string.Empty)) ? (Convert.ToInt64(text2) / 1024 / 1024).ToString() : "Unlimited");
							long num = 0L;
							try
							{
								num = Convert.ToInt64(yrUtils.ExtractInfo(list2[i], "bytes-in"));
							}
							catch
							{
							}
							long num2 = 0L;
							try
							{
								num2 = Convert.ToInt64(yrUtils.ExtractInfo(list2[i], "bytes-out"));
							}
							catch
							{
							}
							string usedByteLimit = ((num + num2) / 1024 / 1024).ToString();
							list.Add(new YachtRouterConfigHotspotUser
							{
								Name = name,
								Password = password,
								TimeLimit = text,
								ByteLimit = text2,
								UsedByteLimit = usedByteLimit,
								UsedTimeLimit = usedTimeLimit
							});
						}
					}
					return list;
				}
				return list;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return list;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetHotspotUsers");
			}
		}

		public int[] GetHotspotUsersActiveAndRegistered(string HotspotName)
		{
			List<YachtRouterConfigHotspotUser> list = new List<YachtRouterConfigHotspotUser>();
			List<string> list2 = new List<string>();
			int num = 0;
			int num2 = 0;
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetHotspotUsers");
				if (this.EnsureConnection())
				{
					this.Send("/ip/hotspot/user/print", true);
					list2 = this.Read();
					for (int i = 0; i < list2.Count; i++)
					{
						if (list2[i].IndexOf("!done") == -1 && yrUtils.ExtractInfo(list2[i], "server") == HotspotName)
						{
							num2++;
						}
					}
					this.Send("/ip/hotspot/active/print", true);
					list2 = this.Read();
					for (int j = 0; j < list2.Count; j++)
					{
						if (list2[j].IndexOf("!done") == -1 && yrUtils.ExtractInfo(list2[j], "server") == HotspotName)
						{
							num++;
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetHotspotUsers");
			}
			return new int[2]
			{
				num,
				num2
			};
		}

		public void HotspotUserAdd(string Username, string Password, string LimitTime, string LimitMegabytes, string Server)
		{
			List<string> list = new List<string>();
			try
			{
				if (LimitTime == "Unlimited")
				{
					LimitTime = "0";
				}
				if (LimitMegabytes == "Unlimited")
				{
					LimitMegabytes = "0";
				}
				long num = 0L;
				try
				{
					num = Convert.ToInt64(LimitMegabytes) * 1024 * 1024;
				}
				catch
				{
				}
				this.AccessToRouterLock.EnterWriteLock("HotspotUserAdd");
				if (this.EnsureConnection())
				{
					this.Send("/ip/hotspot/user/add");
					this.Send("=name=" + Username);
					this.Send("=server=" + Server);
					this.Send("=password=" + Password);
					this.Send("=limit-uptime=" + LimitTime);
					this.Send("=limit-bytes-total=" + num, true);
					List<string> list2 = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("HotspotUserAdd");
			}
		}

		public void HotspotUserEdit(string Username, string Password, string LimitTime, string LimitMegabytes, string Server)
		{
			List<string> list = new List<string>();
			try
			{
				if (LimitTime == "Unlimited")
				{
					LimitTime = "0";
				}
				if (LimitMegabytes == "Unlimited")
				{
					LimitMegabytes = "0";
				}
				long num = 0L;
				try
				{
					num = Convert.ToInt64(LimitMegabytes) * 1024 * 1024;
				}
				catch
				{
				}
				this.AccessToRouterLock.EnterWriteLock("HotspotUserEdit");
				if (this.EnsureConnection())
				{
					this.Send("/ip/hotspot/user/print", true);
					list = this.Read();
					int num2 = 0;
					while (true)
					{
						if (num2 < list.Count)
						{
							if (yrUtils.ExtractInfo(list[num2], "name") == Username && yrUtils.ExtractInfo(list[num2], "server") == Server)
							{
								break;
							}
							num2++;
							continue;
						}
						return;
					}
					string str = yrUtils.ExtractInfo(list[num2], ".id");
					this.Send("/ip/hotspot/user/set");
					this.Send("=.id=" + str);
					this.Send("=name=" + Username);
					this.Send("=password=" + Password);
					this.Send("=limit-uptime=" + LimitTime);
					this.Send("=limit-bytes-total=" + num, true);
					List<string> list2 = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("HotspotUserEdit");
			}
		}

		public void HotspotUserDelete(string Username, string Server)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("DeleteHotspotUser");
				if (this.EnsureConnection())
				{
					this.Send("/ip/hotspot/user/print", true);
					list = this.Read();
					int num = 0;
					while (true)
					{
						if (num < list.Count)
						{
							if (yrUtils.ExtractInfo(list[num], "name") == Username && yrUtils.ExtractInfo(list[num], "server") == Server)
							{
								break;
							}
							num++;
							continue;
						}
						return;
					}
					string str = yrUtils.ExtractInfo(list[num], ".id");
					this.Send("/ip/hotspot/user/remove");
					this.Send("=.id=" + str, true);
					List<string> list2 = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("DeleteHotspotUser");
			}
		}

		public void HotspotUserReset(string Username, string Server)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("HotspotUserReset");
				if (this.EnsureConnection())
				{
					this.Send("/ip/hotspot/user/print", true);
					list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (yrUtils.ExtractInfo(list[i], "name") == Username && yrUtils.ExtractInfo(list[i], "server") == Server)
						{
							string str = yrUtils.ExtractInfo(list[i], ".id");
							this.Send("/ip/hotspot/user/reset-counters");
							this.Send("=.id=" + str, true);
							List<string> list2 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("HotspotUserReset");
			}
		}

		public void HotspotUsersAllReset(string Server)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("HotspotUsersAllReset");
				if (this.EnsureConnection())
				{
					this.Send("/ip/hotspot/user/print", true);
					list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (yrUtils.ExtractInfo(list[i], "server") == Server)
						{
							string str = yrUtils.ExtractInfo(list[i], ".id");
							this.Send("/ip/hotspot/user/reset-counters");
							this.Send("=.id=" + str, true);
							List<string> list2 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("HotspotUsersAllReset");
			}
		}

		public void HotspotUsersAllDelete()
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("DeleteHotspotUser");
				if (this.EnsureConnection())
				{
					this.Send("/ip/hotspot/user/print", true);
					list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						string str = yrUtils.ExtractInfo(list[i], ".id");
						this.Send("/ip/hotspot/user/remove");
						this.Send("=.id=" + str, true);
						List<string> list2 = this.Read();
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("DeleteHotspotUser");
			}
		}

		public void HotspotEnableDisable(string InterfaceName, bool newState)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("HotspotEnableDisable");
				if (this.EnsureConnection())
				{
					this.Send("/ip/hotspot/print", true);
					list = this.Read();
					int num = 0;
					while (num < list.Count)
					{
						if (list[num].IndexOf(InterfaceName) == -1)
						{
							num++;
							continue;
						}
						string str = yrUtils.ExtractInfo(list[num], ".id");
						if (newState)
						{
							this.Send("/ip/hotspot/enable");
						}
						else
						{
							this.Send("/ip/hotspot/disable");
						}
						this.Send("=.id=" + str, true);
						List<string> list2 = this.Read();
						break;
					}
					Thread.Sleep(3000);
					this.Send("/system/script/print", true);
					list = this.Read();
					int num2 = 0;
					while (true)
					{
						if (num2 < list.Count)
						{
							if (list[num2].IndexOf("=name=scriptHotspotDNSdynamicFix") == -1)
							{
								num2++;
								continue;
							}
							break;
						}
						return;
					}
					this.Send("/system/script/run");
					this.Send("=.id=" + yrUtils.ExtractInfo(list[num2], "=.id"), true);
					List<string> list3 = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("HotspotEnableDisable");
			}
		}

		public bool GetIsHotspotEnabledDisabled(string InterfaceName)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("HotspotEnableDisable");
				if (this.EnsureConnection())
				{
					this.Send("/ip/hotspot/print", true);
					list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf(InterfaceName) != -1)
						{
							if (list[i].IndexOf("=disabled=true") != -1)
							{
								return false;
							}
							return true;
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("HotspotEnableDisable");
			}
			return false;
		}

		public bool GetIsQueueEnabledDisabled(string QueueName)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetIsQueueEnabledDisabled");
				if (this.EnsureConnection())
				{
					this.Send("/queue/tree/print", true);
					list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf(QueueName) != -1)
						{
							if (list[i].IndexOf("=disabled=true") != -1)
							{
								return false;
							}
							return true;
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetIsQueueEnabledDisabled");
			}
			return false;
		}

		public void SetIsQueueEnabledDisabled(string QueueName, bool newState)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("SetIsQueueEnabledDisabled");
				if (this.EnsureConnection())
				{
					this.Send("/queue/tree/print", true);
					list = this.Read();
					int num = 0;
					while (true)
					{
						if (num < list.Count)
						{
							if (list[num].IndexOf(QueueName) == -1)
							{
								num++;
								continue;
							}
							break;
						}
						return;
					}
					this.Send("/queue/tree/set");
					this.Send("=.id=" + yrUtils.ExtractInfo(list[num], ".id="));
					if (!newState)
					{
						this.Send("=disabled=true", true);
					}
					else
					{
						this.Send("=disabled=false", true);
					}
					List<string> list2 = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("SetIsQueueEnabledDisabled");
			}
		}

		public string GetQueueTypePCQRate(string QueueTypeName)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetQueueTypePCQRate");
				if (this.EnsureConnection())
				{
					this.Send("/queue/type/print", true);
					list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf("=name=" + QueueTypeName) != -1)
						{
							return yrUtils.ExtractInfo(list[i], "=pcq-rate");
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetQueueTypePCQRate");
			}
			return string.Empty;
		}

		public void SetQueueTypePCQRate(string QueueTypeName, int pcqRate)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("SetQueueTypePCQRate");
				if (this.EnsureConnection())
				{
					this.Send("/queue/type/print", true);
					list = this.Read();
					int num = 0;
					while (true)
					{
						if (num < list.Count)
						{
							if (list[num].IndexOf("=name=" + QueueTypeName) == -1)
							{
								num++;
								continue;
							}
							break;
						}
						return;
					}
					this.Send("/queue/type/set");
					this.Send("=.id=" + yrUtils.ExtractInfo(list[num], ".id="));
					this.Send("=pcq-rate=" + pcqRate + "k", true);
					List<string> list2 = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("SetQueueTypePCQRate");
			}
		}

		public bool HotspotRadiusUserAdd(string Username, string Password, string LimitTime, string LimitMegabytes, string Server, string ProfileName)
		{
			List<string> list = new List<string>();
			try
			{
				if (LimitTime == "Unlimited")
				{
					LimitTime = "0";
				}
				if (LimitMegabytes == "Unlimited")
				{
					LimitMegabytes = "0";
				}
				long num = 0L;
				try
				{
					num = Convert.ToInt64(LimitMegabytes) * 1024 * 1024;
				}
				catch
				{
				}
				this.AccessToRouterLock.EnterWriteLock("HotspotRadiusUserAdd");
				if (this.EnsureConnection())
				{
					this.Send("/tool/user-manager/user/add");
					this.Send("=username=" + Username);
					this.Send("=customer=" + Server);
					this.Send("=password=" + Password, true);
					List<string> list2 = this.Read();
					this.Send("/tool/user-manager/user/create-and-activate-profile");
					this.Send("=.id=" + yrUtils.ExtractInfo(("=" + list2[0]).Replace("=ret", string.Empty), "!done="));
					this.Send("=customer=" + Server);
					this.Send("=profile=" + ProfileName, true);
					List<string> list3 = this.Read();
					if (list3[0].ToLower().Contains("!done"))
					{
						return true;
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("HotspotRadiusUserAdd");
			}
			return false;
		}

		public List<string> GetDhcpLeases()
		{
			List<string> result = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetDhcpLeases");
				if (this.EnsureConnection())
				{
					this.Send("/ip/dhcp-server/lease/print", true);
					return this.Read();
				}
				return result;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return result;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetDhcpLeases");
			}
		}

		public List<string> GetDhcpLeasesAndFixThem(string dhcpServerName, string Identity)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetExtendersIPsAndFixThemInDHCPAddresses");
				if (this.EnsureConnection())
				{
					this.Send("/ip/dhcp-server/lease/print", true);
					List<string> list2 = this.Read();
					for (int i = 0; i < list2.Count; i++)
					{
						if (yrUtils.ExtractInfo(list2[i], "server") == dhcpServerName && yrUtils.ExtractInfo(list2[i], "host-name").StartsWith(Identity))
						{
							list.Add(yrUtils.ExtractInfo(list2[i], "active-address"));
						}
					}
					return list;
				}
				return list;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return list;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetExtendersIPsAndFixThemInDHCPAddresses");
			}
		}

		public void DhcpLeaseMakeStatic(string ip)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("DhcpLeaseMakeStatic");
				if (this.EnsureConnection())
				{
					this.Send("/ip/dhcp-server/lease/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (yrUtils.ExtractInfo(list[i], "active-address") == ip)
						{
							string str = yrUtils.ExtractInfo(list[i], ".id");
							this.Send("/ip/dhcp-server/lease/make-static");
							this.Send("=.id=" + str, true);
							List<string> list2 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("DhcpLeaseMakeStatic");
			}
		}

		public void DhcpLeaseDelete(string ip)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("DhcpLeaseDelete");
				if (this.EnsureConnection())
				{
					this.Send("/ip/dhcp-server/lease/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (yrUtils.ExtractInfo(list[i], "active-address") == ip)
						{
							string str = yrUtils.ExtractInfo(list[i], ".id");
							this.Send("/ip/dhcp-server/lease/remove");
							this.Send("=.id=" + str, true);
							List<string> list2 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("DhcpLeaseDelete");
			}
		}

		public List<string[]> GetDhcpLeases(string dhcpServerName)
		{
			List<string[]> list = new List<string[]>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetExtendersIPsAndFixThemInDHCPAddresses");
				if (this.EnsureConnection())
				{
					this.Send("/ip/dhcp-server/lease/print", true);
					List<string> list2 = this.Read();
					for (int i = 0; i < list2.Count; i++)
					{
						if (yrUtils.ExtractInfo(list2[i], "server") == dhcpServerName)
						{
							bool flag = false;
							flag = ((byte)((!(yrUtils.ExtractInfo(list2[i], "dynamic") == "true")) ? 1 : 0) != 0);
							list.Add(new string[4]
							{
								yrUtils.ExtractInfo(list2[i], "mac-address"),
								yrUtils.ExtractInfo(list2[i], "active-address"),
								yrUtils.ExtractInfo(list2[i], "host-name").Replace("\0", string.Empty),
								flag.ToString()
							});
						}
					}
					return list;
				}
				return list;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return list;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetExtendersIPsAndFixThemInDHCPAddresses");
			}
		}

		public void CleanEOIPs()
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CleanEOIPs");
				if (this.EnsureConnection())
				{
					this.Send("/interface/eoip/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						string str = yrUtils.ExtractInfo(list[i], ".id");
						this.Send("/interface/eoip/remove");
						this.Send("=.id=" + str, true);
						List<string> list2 = this.Read();
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CleanEOIPs");
			}
		}

		public void CleanVirtualAPs(string InterfacePrefix)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CleanVirtualAPs");
				if (this.EnsureConnection())
				{
					this.Send("/interface/wireless/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].ToLower().IndexOf(InterfacePrefix.ToLower()) != -1)
						{
							string str = yrUtils.ExtractInfo(list[i], ".id");
							this.Send("/interface/wireless/remove");
							this.Send("=.id=" + str, true);
							List<string> list2 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CleanVirtualAPs");
			}
		}

		public void CleanEoipBridgesAndPorts()
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CleanBridges");
				if (this.EnsureConnection())
				{
					this.Send("/interface/bridge/port/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (yrUtils.ExtractInfo(list[i], "=interface").StartsWith("*") || yrUtils.ExtractInfo(list[i], "=interface").StartsWith("shipWIFI"))
						{
							string str = yrUtils.ExtractInfo(list[i], ".id");
							this.Send("/interface/bridge/port/remove");
							this.Send("=.id=" + str, true);
							List<string> list2 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CleanBridges");
			}
		}

		public void CleanAllWirelessSecurityProfiles()
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CleanAllWirelessSecurityProfiles");
				if (this.EnsureConnection())
				{
					this.Send("/interface/wireless/security-profiles/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf(yrEngine.virtualApSecurityProfilePrefix) != -1)
						{
							this.Send("/interface/wireless/security-profiles/remove");
							this.Send("=.id=" + yrUtils.ExtractInfo(list[i], ".id="), true);
							List<string> list2 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CleanAllWirelessSecurityProfiles");
			}
		}

		public void CleanIpAddressesWithPrefix(string IpAddressInterfacePrefix)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CleanIpAddressesWithPrefix");
				if (this.EnsureConnection())
				{
					this.Send("/ip/address/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf(IpAddressInterfacePrefix) != -1)
						{
							this.Send("/ip/address/remove");
							this.Send("=.id=" + yrUtils.ExtractInfo(list[i], ".id="), true);
							List<string> list2 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CleanIpAddressesWithPrefix");
			}
		}

		public void CleanIpAddressPoolsWithPrefix(string IpAddressPoolPrefix)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CleanIpAddressPoolsWithPrefix");
				if (this.EnsureConnection())
				{
					this.Send("/ip/pool/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf(IpAddressPoolPrefix) != -1)
						{
							this.Send("/ip/pool/remove");
							this.Send("=.id=" + yrUtils.ExtractInfo(list[i], ".id="), true);
							List<string> list2 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CleanIpAddressPoolsWithPrefix");
			}
		}

		public void CleanDHCPServersWithPrefix(string DHCPServerPrefix)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CleanDHCPServersWithPrefix");
				if (this.EnsureConnection())
				{
					this.Send("/ip/dhcp-server/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf(DHCPServerPrefix) != -1)
						{
							this.Send("/ip/dhcp-server/remove");
							this.Send("=.id=" + yrUtils.ExtractInfo(list[i], ".id="), true);
							List<string> list2 = this.Read();
						}
					}
					this.Send("/ip/dhcp-server/network/print", true);
					list = this.Read();
					for (int j = 0; j < list.Count; j++)
					{
						if (list[j].IndexOf(DHCPServerPrefix) != -1)
						{
							this.Send("/ip/dhcp-server/network/remove");
							this.Send("=.id=" + yrUtils.ExtractInfo(list[j], ".id="), true);
							List<string> list3 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CleanDHCPServersWithPrefix");
			}
		}

		public void CleanFirewallMangleRoutingMarkRules(string IdentifyComment)
		{
			this.CleanFirewallRules("mangle", IdentifyComment);
		}

		public void CleanFirewallNatRules(string IdentifyComment)
		{
			this.CleanFirewallRules("nat", IdentifyComment);
		}

		public void CleanFirewallRules(string FirewallSection, string IdentifyComment)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CleanFirewallRules");
				if (this.EnsureConnection())
				{
					this.Send("/ip/firewall/" + FirewallSection + "/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf(IdentifyComment) != -1)
						{
							string str = yrUtils.ExtractInfo(list[i], ".id");
							this.Send("/ip/firewall/" + FirewallSection + "/remove");
							this.Send("=.id=" + str, true);
							List<string> list2 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CleanFirewallRules");
			}
		}

		public void CleanRoutesWithRoutingMarks(string routingMarkPrefix)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CleanRoutesWithRoutingMarks");
				if (this.EnsureConnection())
				{
					this.Send("/ip/route/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf(routingMarkPrefix) != -1)
						{
							string str = yrUtils.ExtractInfo(list[i], ".id");
							this.Send("/ip/route/remove");
							this.Send("=.id=" + str, true);
							List<string> list2 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CleanRoutesWithRoutingMarks");
			}
		}

		public void CreateBridge(string BridgeName)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CreateBridge");
				if (this.EnsureConnection())
				{
					this.Send("/interface/bridge/add");
					this.Send("=name=" + BridgeName, true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CreateBridge");
			}
		}

		public void CreateBridgePort(string BridgeName, string InterfaceName)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CreateBridgePort");
				if (this.EnsureConnection())
				{
					this.Send("/interface/bridge/port/add");
					this.Send("=bridge=" + BridgeName);
					this.Send("=interface=" + InterfaceName, true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CreateBridgePort");
			}
		}

		public void CreateVirtualAP(string PhysicalInterface, string VirtualApName, string SSID, string password)
		{
			try
			{
				if (this.GetIsHighSpeedWIFISSIDisAvailable())
				{
					SSID += this.HighSpeedSSIDSuffix;
				}
				this.AccessToRouterLock.EnterWriteLock("CreateVirtualAP");
				if (this.EnsureConnection())
				{
					this.Send("/interface/wireless/security-profiles/add");
					this.Send("=name=" + yrEngine.virtualApSecurityProfilePrefix + VirtualApName);
					this.Send("=mode=dynamic-keys");
					this.Send("=unicast-ciphers=tkip,aes-ccm");
					this.Send("=group-ciphers=tkip,aes-ccm");
					this.Send("=authentication-types=wpa-psk,wpa2-psk");
					this.Send("=wpa-pre-shared-key=" + password);
					this.Send("=wpa2-pre-shared-key=" + password, true);
					List<string> list = this.Read();
					this.Send("/interface/wireless/add");
					this.Send("=name=" + VirtualApName);
					this.Send("=master-interface=" + PhysicalInterface);
					this.Send("=ssid=" + SSID);
					this.Send("=disabled=no");
					this.Send("=security-profile=" + yrEngine.virtualApSecurityProfilePrefix + VirtualApName, true);
					list = this.Read();
					if (this.GetIsDualFrequencyWIFISSIDisAvailable())
					{
						this.Send("/interface/wireless/add");
						this.Send("=name=" + VirtualApName + "Ex");
						this.Send("=master-interface=" + PhysicalInterface + "Ex");
						this.Send("=ssid=" + SSID + this.HighSpeedSSIDSuffix);
						this.Send("=disabled=no");
						this.Send("=security-profile=" + yrEngine.virtualApSecurityProfilePrefix + VirtualApName, true);
						list = this.Read();
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CreateVirtualAP");
			}
		}

		public void CreateEoipTunnel(string TunnelName, string localAddress, string remoteAddress, string TunnelID)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CreateEoipTunnel");
				if (this.EnsureConnection())
				{
					this.Send("/interface/eoip/add");
					this.Send("=name=" + TunnelName);
					this.Send("=local-address=" + localAddress);
					this.Send("=remote-address=" + remoteAddress);
					this.Send("=tunnel-id=" + TunnelID, true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CreateEoipTunnel");
			}
		}

		public void CreateIpAddress(string InterfaceName, string IPAddress, string SubnetMask)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CreateIpAddress");
				if (this.EnsureConnection())
				{
					this.Send("/ip/address/add");
					this.Send("=interface=" + InterfaceName);
					this.Send("=address=" + IPAddress + this.ConvertSubnetMaskToCDIR(SubnetMask), true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CreateIpAddress");
			}
		}

		public void CreateIpAddressPool(string PoolName, string fromAddress, string toAddress)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CreateIpAddressPool");
				if (this.EnsureConnection())
				{
					this.Send("/ip/pool/add");
					this.Send("=name=" + PoolName);
					this.Send("=ranges=" + fromAddress + "-" + toAddress, true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CreateIpAddressPool");
			}
		}

		public void CreateDHCPServer(string DHCPServerName, string Interface, string PoolName, string NetworkAddressSubnet, string DHCPServerIP)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CreateDHCPServer");
				if (this.EnsureConnection())
				{
					this.Send("/ip/dhcp-server/add");
					this.Send("=name=" + DHCPServerName);
					this.Send("=authoritative=yes");
					this.Send("=disabled=no");
					this.Send("=address-pool=" + PoolName);
					this.Send("=interface=" + Interface, true);
					List<string> list = this.Read();
					this.Send("/ip/dhcp-server/network/add");
					this.Send("=address=" + NetworkAddressSubnet);
					this.Send("=gateway=" + DHCPServerIP);
					this.Send("=comment=" + DHCPServerName);
					this.Send("=dns-server=8.8.8.8,8.8.4.4", true);
					list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CreateDHCPServer");
			}
		}

		public void CreateFirewallMangleRoutingMarkRule(string routingMark, string sourceAddress, string IdentifyComment)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CreateFirewallMangleRoutingMarkRule");
				if (this.EnsureConnection())
				{
					this.Send("/ip/firewall/mangle/add");
					this.Send("=chain=prerouting");
					this.Send("=action=mark-routing");
					this.Send("=new-routing-mark=" + routingMark);
					this.Send("=passthrough=yes");
					this.Send("=comment=" + IdentifyComment);
					this.Send("=src-address=" + sourceAddress, true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CreateFirewallMangleRoutingMarkRule");
			}
		}

		public void CreateFirewallMangleAcceptRule(string destinationAddress, string IdentifyComment)
		{
			try
			{
				this.CleanFirewallMangleRoutingMarkRules(IdentifyComment);
				this.AccessToRouterLock.EnterWriteLock("CreateFirewallMangleAcceptRule");
				if (this.EnsureConnection())
				{
					this.Send("/ip/firewall/mangle/add");
					this.Send("=chain=prerouting");
					this.Send("=action=accept");
					this.Send("=place-before=0");
					this.Send("=dst-address=" + destinationAddress);
					this.Send("=passthrough=no");
					this.Send("=comment=" + IdentifyComment, true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CreateFirewallMangleAcceptRule");
			}
		}

		public void CreateFirewallNatRule(string outInterface, string IdentifyComment)
		{
			try
			{
				this.CleanFirewallNatRules(IdentifyComment);
				this.AccessToRouterLock.EnterWriteLock("CreateFirewallNatRule");
				if (this.EnsureConnection())
				{
					this.Send("/ip/firewall/nat/add");
					this.Send("=chain=srcnat");
					this.Send("=action=masquerade");
					this.Send("=out-interface=" + outInterface);
					this.Send("=comment=" + IdentifyComment, true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CreateFirewallNatRule");
			}
		}

		public void CreateRoute(string gateway, string routingMark, string interfaceNameForComment)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CreateRoute");
				if (this.EnsureConnection())
				{
					this.Send("/ip/route/add");
					this.Send("=gateway=" + gateway);
					this.Send("=routing-mark=" + routingMark);
					this.Send("=comment=" + interfaceNameForComment, true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CreateRoute");
			}
		}

		public void DeleteAllRoutes(string targetIP, string interfaceNameForComment)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("DeleteAllRoutes");
				if (this.EnsureConnection())
				{
					this.Send("/ip/route/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf("comment=" + interfaceNameForComment) != -1 && list[i].IndexOf("dst-address=" + targetIP) != -1)
						{
							this.Send("/ip/route/remove");
							this.Send("=.id=" + yrUtils.ExtractInfo(list[i], "=.id"), true);
							List<string> list2 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("DeleteAllRoutes");
			}
		}

		public void EnsureWorkingRoute(string targetIP, string interfaceNameForComment, string distance = null)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("EnsureWorkingRoute");
				if (this.EnsureConnection())
				{
					this.Send("/ip/route/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					bool flag = false;
					int num = 0;
					while (num < list.Count)
					{
						if (list[num].IndexOf("comment=" + interfaceNameForComment) == -1 || list[num].IndexOf("dst-address=" + targetIP) == -1)
						{
							num++;
							continue;
						}
						flag = true;
						break;
					}
					if (!flag)
					{
						this.Send("/ip/route/add");
						this.Send("=gateway=1.1.1.1");
						this.Send("=dst-address=" + targetIP);
						if (distance != null)
						{
							this.Send("=distance=" + distance);
						}
						this.Send("=comment=" + interfaceNameForComment, true);
						List<string> list2 = this.Read();
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("EnsureWorkingRoute");
			}
		}

		public void EnsureWorkingRouteToIP(string dstrange, string gateway)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("EnsureWorkingRoute");
				if (this.EnsureConnection())
				{
					this.Send("/ip/route/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					bool flag = false;
					int num = 0;
					while (num < list.Count)
					{
						if (list[num].IndexOf("dst-address=" + dstrange) == -1 || list[num].IndexOf("gateway=" + gateway) == -1)
						{
							num++;
							continue;
						}
						flag = true;
						break;
					}
					if (!flag)
					{
						this.Send("/ip/route/add");
						this.Send("=gateway=" + gateway);
						this.Send("=dst-address=" + dstrange);
						this.Send("=comment=Support Network", true);
						List<string> list2 = this.Read();
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("EnsureWorkingRoute");
			}
		}

		public void EnsureFirewallMangle(string action, string chain, string dstAddress, string newRoutingMark, string passthrough, string srcAddress)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("EnsureFirewallMangle");
				if (this.EnsureConnection())
				{
					this.Send("/ip/firewall/mangle/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					bool flag = false;
					int num = 0;
					while (num < list.Count)
					{
						if (list[num].IndexOf("action=" + action) == -1 || list[num].IndexOf("chain=" + chain) == -1 || list[num].IndexOf("dst-address=" + dstAddress) == -1 || list[num].IndexOf("new-routing-mark=" + newRoutingMark) == -1 || list[num].IndexOf("passthrough=" + passthrough) == -1 || list[num].IndexOf("src-address=" + srcAddress) == -1)
						{
							num++;
							continue;
						}
						flag = true;
						break;
					}
					if (!flag)
					{
						this.Send("/ip/firewall/mangle/add");
						this.Send("=action=" + action);
						this.Send("=chain=" + chain);
						this.Send("=dst-address=" + dstAddress);
						this.Send("=new-routing-mark=" + newRoutingMark);
						this.Send("=passthrough=" + passthrough);
						this.Send("=src-address=" + srcAddress, true);
						List<string> list2 = this.Read();
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("EnsureFirewallMangle");
			}
		}

		public void ResetInterfaceStats(string Interface, string typeOfInterface)
		{
		}

		public List<string> GetInterfaceStats(string Interface)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetInterfaceStats");
				List<string> list;
				List<string> list2;
				int num2;
				if (this.EnsureConnection())
				{
					list = new List<string>();
					this.Send("/interface/print");
					this.Send("=stats-detail=yes", true);
					list2 = this.Read();
					int num = 0;
					while (num < list2.Count)
					{
						if (list2[num].IndexOf("=name=" + Interface) == -1)
						{
							num++;
							continue;
						}
						list.Add(yrUtils.ExtractInfo(list2[num], "rx-byte="));
						list.Add(yrUtils.ExtractInfo(list2[num], "tx-byte="));
						break;
					}
					this.Send("/interface/monitor-traffic");
					this.Send("=interface=" + Interface);
					this.Send(".tag=5", true);
					list2 = this.Read(true, 1);
					this.Send("/cancel");
					this.Send(".tag=5", true);
					List<string> list3 = this.Read();
					List<string> list4 = this.Read();
					num2 = 0;
					goto IL_0147;
				}
				goto end_IL_0000;
				IL_0141:
				num2++;
				goto IL_0147;
				IL_0147:
				if (num2 < list2.Count)
				{
					list.Add(yrUtils.ExtractInfo(list2[num2], "rx-bits-per-second="));
					list.Add(yrUtils.ExtractInfo(list2[num2], "tx-bits-per-second="));
					return list;
				}
				end_IL_0000:;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetInterfaceStats");
			}
			return null;
		}

		public List<string> GetInterfaceMonitor(string Interface)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetInterfaceMonitor");
				if (this.EnsureConnection())
				{
					goto end_IL_0000;
				}
				end_IL_0000:;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetInterfaceMonitor");
			}
			return null;
		}

		public string GetIdentity()
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetIdentity");
				if (this.EnsureConnection())
				{
					this.Send("/system/identity/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf("=name=") != -1)
						{
							return yrUtils.ExtractInfo(list[i], "name=");
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetIdentity");
			}
			return string.Empty;
		}

		public void SetIdentity(string newIdentity)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("SetIdentity");
				if (this.EnsureConnection())
				{
					this.Send("/system/identity/set");
					this.Send("=name=" + newIdentity, true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("SetIdentity");
			}
		}

		public string GetVNOutputPower(string Interface)
		{
			try
			{
				try
				{
					this.AccessToRouterLock.EnterWriteLock("GetVNOutputPower");
					if (this.EnsureConnection())
					{
						this.Send("/interface/wireless/print");
						this.Send("=advanced=yes", true);
						List<string> list = this.Read();
						for (int i = 0; i < list.Count; i++)
						{
							if (list[i].IndexOf("=name=" + Interface) != -1)
							{
								if (list[i].IndexOf("tx-power-mode=all-rates-fixed") != -1)
								{
									return yrUtils.ExtractInfo(list[i], "tx-power=");
								}
								return "0";
							}
						}
					}
				}
				catch (Exception ex)
				{
					this._curLogger.LogException(ex);
				}
				finally
				{
					this.AccessToRouterLock.ExitWriteLock("GetVNOutputPower");
				}
				return string.Empty;
			}
			catch (Exception ex2)
			{
				this._curLogger.LogException(ex2);
			}
			return "0";
		}

		public void SetVNOutputPower(string Interface, string power)
		{
			try
			{
				try
				{
					this.AccessToRouterLock.EnterWriteLock("SetVNOutputPower");
					if (this.EnsureConnection())
					{
						this.Send("/interface/wireless/set");
						this.Send("=.id=" + Interface);
						if (power == "0")
						{
							this.Send("=tx-power-mode=default", true);
						}
						else
						{
							this.Send("=tx-power-mode=all-rates-fixed");
							this.Send("=tx-power=" + power, true);
						}
						List<string> list = this.Read();
					}
				}
				catch (Exception ex)
				{
					this._curLogger.LogException(ex);
				}
				finally
				{
					this.AccessToRouterLock.ExitWriteLock("SetVNOutputPower");
				}
			}
			catch (Exception ex2)
			{
				this._curLogger.LogException(ex2);
			}
		}

		public bool CheckWanInternetStatus(string InternetStatusTargetIP)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("CheckWanInternetStatus");
				if (this.EnsureConnection())
				{
					int num = 3;
					List<string> list = new List<string>();
					list.Add("no-connection");
					List<string> list2 = list;
					while (num > 0)
					{
						try
						{
							this.Send("/ping");
							this.Send("=address=" + InternetStatusTargetIP);
							this.Send("=count=5", true);
							list2 = this.Read();
							if (list2.Count == 6 && !list2[list2.Count - 2].Contains("=received=0="))
							{
								return true;
							}
						}
						catch
						{
						}
						num--;
					}
					return !list2[list2.Count - 2].Contains("=received=0=");
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("CheckWanInternetStatus");
			}
			return false;
		}

		private void CleanRouterReadouts()
		{
			int num = 5;
			while (num > 0)
			{
				try
				{
					this.Read();
				}
				catch
				{
					return;
				}
			}
		}

		public void SetInterfaceBridge(string InterfaceName, string BridgeToAssignTo)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("SetInterfaceBridge");
				if (this.EnsureConnection())
				{
					string str = string.Empty;
					this.Send("/interface/bridge/port/print", true);
					List<string> list = this.Read();
					int num = 0;
					while (num < list.Count)
					{
						if (list[num].IndexOf("=interface=" + InterfaceName) == -1)
						{
							num++;
							continue;
						}
						str = yrUtils.ExtractInfo(list[num], ".id=");
						break;
					}
					this.Send("/interface/bridge/port/set");
					this.Send("=bridge=" + BridgeToAssignTo);
					this.Send("=interface=" + InterfaceName);
					this.Send("=.id=" + str, true);
					list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("SetInterfaceBridge");
			}
		}

		public string GetInterfaceBridge(string InterfaceName)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetInterfaceBridge");
				if (this.EnsureConnection())
				{
					this.Send("/interface/bridge/port/print", true);
					List<string> list = this.Read();
					for (int i = 0; i < list.Count; i++)
					{
						if (list[i].IndexOf("=interface=" + InterfaceName) != -1)
						{
							return yrUtils.ExtractInfo(list[i], "bridge=");
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetInterfaceBridge");
			}
			return string.Empty;
		}

		public void ProcessReloadSimCard(string InterfaceName, int bus)
		{
			try
			{
				int num = bus;
				if (bus == 0)
				{
					num = 1;
				}
				if (bus == 0 && this.curRouterModelName.Contains("922UAGS"))
				{
					num = 2;
				}
				this.AccessToRouterLock.EnterWriteLock("ProcessReloadSimCard");
				if (this.EnsureConnection())
				{
					this.Send("/system/routerboard/usb/power-reset");
					this.Send("=bus=" + num);
					this.Send("=duration=30", true);
					List<string> list = this.Read();
					Thread.Sleep(30000);
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("ProcessReloadSimCard");
			}
		}

		public void AddPortForward(string InputInterface, string ip, string DevicePort, string CloudPort, string CloudPortComment, bool disabled)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("AddPortForward");
				if (this.EnsureConnection())
				{
					this.Send("/ip/firewall/nat/add");
					this.Send("=action=dst-nat");
					this.Send("=chain=dstnat");
					this.Send("=protocol=tcp");
					this.Send("=in-interface=" + InputInterface);
					this.Send("=dst-port=" + CloudPort);
					this.Send("=to-addresses=" + ip);
					this.Send("=to-ports=" + DevicePort);
					if (disabled)
					{
						this.Send("=disabled=yes");
					}
					else
					{
						this.Send("=disabled=no");
					}
					this.Send("=comment=" + CloudPortComment, true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("AddPortForward");
			}
		}

		public List<string[]> GetPortForwards()
		{
			List<string[]> list = new List<string[]>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetPortForwards");
				if (this.EnsureConnection())
				{
					this.Send("/ip/firewall/nat/print", true);
					List<string> list2 = this.Read();
					for (int i = 0; i < list2.Count; i++)
					{
						if (list2[i].IndexOf("dstnat") != -1)
						{
							list.Add(new string[6]
							{
								yrUtils.ExtractInfo(list2[i], "=in-interface"),
								yrUtils.ExtractInfo(list2[i], "=dst-port"),
								yrUtils.ExtractInfo(list2[i], "=to-address"),
								yrUtils.ExtractInfo(list2[i], "=to-ports"),
								yrUtils.ExtractInfo(list2[i], "=disabled"),
								yrUtils.ExtractInfo(list2[i], "=comment")
							});
						}
					}
					return list;
				}
				return list;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return list;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetPortForwards");
			}
		}

		public void PortForwardDelete(string cloudPort)
		{
			List<string[]> list = new List<string[]>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("PortForwardDelete");
				if (this.EnsureConnection())
				{
					this.Send("/ip/firewall/nat/print", true);
					List<string> list2 = this.Read();
					for (int num = list2.Count - 1; num >= 0; num--)
					{
						if (list2[num].IndexOf("dstnat") != -1 && cloudPort == yrUtils.ExtractInfo(list2[num], "=dst-port"))
						{
							this.Send("/ip/firewall/nat/remove");
							this.Send("=.id=" + yrUtils.ExtractInfo(list2[num], "=.id"), true);
							List<string> list3 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("PortForwardDelete");
			}
		}

		public void PortForwardEnableDisable(string interfaceName, string cloudPort, bool SetToEnabled)
		{
			List<string[]> list = new List<string[]>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("PortForwardEnableDisable");
				if (this.EnsureConnection())
				{
					this.Send("/ip/firewall/nat/print", true);
					List<string> list2 = this.Read();
					for (int num = list2.Count - 1; num >= 0; num--)
					{
						if (list2[num].IndexOf("dstnat") != -1 && cloudPort == yrUtils.ExtractInfo(list2[num], "=dst-port") && interfaceName.ToLower() == yrUtils.ExtractInfo(list2[num], "=in-interface").ToLower())
						{
							this.Send("/ip/firewall/nat/set");
							this.Send("=.id=" + yrUtils.ExtractInfo(list2[num], "=.id"));
							if (SetToEnabled)
							{
								this.Send("=disabled=no", true);
							}
							else
							{
								this.Send("=disabled=yes", true);
							}
							List<string> list3 = this.Read();
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("PortForwardEnableDisable");
			}
		}

		public List<string> GetAutoswitcherAllScripts()
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetAutoswitcherAllScripts");
				if (this.EnsureConnection())
				{
					this.Send("/system/script/print", true);
					List<string> list2 = this.Read();
					for (int i = 0; i < list2.Count; i++)
					{
						if (list2[i].IndexOf("=name=Autoswitch_") != -1)
						{
							list.Add(yrUtils.ExtractInfo(list2[i], "=name"));
						}
					}
					return list;
				}
				return list;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return list;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetAutoswitcherAllScripts");
			}
		}

		public void EnsureDhcpRecoveryScripts()
		{
			List<string> list = new List<string>();
			List<string> list2 = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("EnsureDhcpRecoveryScripts");
				if (this.EnsureConnection())
				{
					this.Send("/ip/dhcp-client/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					if (list.Count <= 3)
					{
						for (int i = 0; i < list.Count - 1; i++)
						{
							string scriptSource = ":local dhcpStaus" + i + " [/ip dhcp-client get " + i + " status]\r\n:if ( $dhcpStaus" + i + " = \"bound\" ) do={ \r\n} else= { \r\n   /ip dhcp-client release " + i + " \r\n   /ip dhcp-client renew " + i + " \r\n }";
							this.EnsureScript("scriptDhcpRecovery_" + i, scriptSource, "schedulerDhcpRecovery_" + i, "15s", "no", true);
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("EnsureDhcpRecoveryScripts");
			}
		}

		public void EnsureRecoveryEnforceStartupScripts(bool SkipIPAddressCheck = false)
		{
			List<string> list = new List<string>();
			List<string> list2 = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("EnsureRecoveryEnforceStartupScripts");
				if (this.EnsureConnection())
				{
					this.Send("/ip/dhcp-client/print", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					string empty = string.Empty;
					empty = ((!SkipIPAddressCheck) ? ("/ip address set 0 disabled=no address=" + this.RouterIP + "/16 \r\n/system routerboard usb set type=mini-PCIe\r\n/system routerboard usb power-reset bus=0 duration=20") : "/system routerboard usb set type=mini-PCIe\r\n/system routerboard usb power-reset bus=0 duration=20");
					this.EnsureScript("scriptRecoveryEnforce", empty, "schedulerRecoveryEnforce", "0", "no", true);
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("EnsureRecoveryEnforceStartupScripts");
			}
		}

		public void EnsureScript(string ScriptName, string ScriptSource, string SchedulerName, string SchedulerTimeout, string SchedulerDisabled, bool CreateScheduler = true)
		{
			List<string> list = new List<string>();
			try
			{
				if (this.EnsureConnection())
				{
					this.Send("/system/script/print");
					this.Send("=brief=yes", true);
					list = this.Read();
					if (list.Last() != "!done")
					{
						list = this.Read();
					}
					int num = 0;
					while (num < list.Count)
					{
						if (list[num].IndexOf(ScriptName) == -1)
						{
							num++;
							continue;
						}
						this.Send("/system/script/remove");
						this.Send("=.id=" + yrUtils.ExtractInfo(list[num], ".id="), true);
						List<string> list2 = this.Read();
						break;
					}
					this.Send("/system/script/add");
					this.Send("=name=" + ScriptName);
					this.Send("=source=" + ScriptSource, true);
					List<string> list3 = this.Read();
					if (CreateScheduler)
					{
						this.Send("/system/scheduler/remove");
						this.Send("=name=" + SchedulerName, true);
						this.Read();
						this.Send("/system/scheduler/add");
						this.Send("=name=" + SchedulerName);
						this.Send("=disabled=" + SchedulerDisabled);
						this.Send("=interval=" + SchedulerTimeout);
						if (SchedulerTimeout != "0")
						{
							this.Send("=start-date=jan/01/1970");
							this.Send("=start-time=00:00:00");
						}
						else
						{
							this.Send("=start-time=startup");
						}
						this.Send("=on-event=" + ScriptName, true);
						List<string> list4 = this.Read();
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
			}
		}

		public void ExecuteScript(string ScriptName)
		{
			List<string> list = new List<string>();
			try
			{
				if (this.EnsureConnection())
				{
					this.Send("/system/script/print", true);
					List<string> list2 = this.Read();
					int num = 0;
					while (true)
					{
						if (num < list2.Count)
						{
							if (list2[num].IndexOf("=name=" + ScriptName) == -1)
							{
								num++;
								continue;
							}
							break;
						}
						return;
					}
					this.Send("/system/script/run");
					this.Send("=.id=" + yrUtils.ExtractInfo(list2[num], "=.id"), true);
					List<string> list3 = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
			}
		}

		public void UpdateMacAddressForWirelessInterfaceWithPrefix(string InterfaceName, string Prefix, string RadioName, string CountryCode, bool SetRadioName)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("UpdateMacAddressForWirelessInterfaceWithPrefix");
				if (this.EnsureConnection())
				{
					this.Send("/interface/wireless/print", true);
					List<string> list2 = this.Read();
					if (list2.Last() != "!done")
					{
						list2 = this.Read();
					}
					int num = 0;
					while (true)
					{
						if (num < list2.Count)
						{
							if (list2[num].IndexOf(InterfaceName) == -1)
							{
								num++;
								continue;
							}
							break;
						}
						return;
					}
					string str = yrUtils.ExtractInfo(list2[num], ".id=");
					string text = yrUtils.ExtractInfo(list2[num], "mac-address=");
					text = Prefix + text.Substring(Prefix.Length);
					this.Send("/interface/wireless/set");
					this.Send("=.id=" + str);
					this.Send("=country=" + CountryCode);
					if (SetRadioName)
					{
						this.Send("=radio-name=" + RadioName);
					}
					this.Send("=mac-address=" + text, true);
					list2 = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("UpdateMacAddressForWirelessInterfaceWithPrefix");
			}
		}

		public void UpdateWIFItoAutoFrequency(string interfaceName)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("UpdateWIFItoAutoFrequency");
				if (this.EnsureConnection())
				{
					this.Send("/interface/wireless/set");
					this.Send("=frequency=auto", true);
					List<string> list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("UpdateWIFItoAutoFrequency");
			}
		}

		public void AdjustDNS(string servers)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("AdjustDNS");
				if (this.EnsureConnection())
				{
					this.Send("/ip/dns/set");
					this.Send("=allow-remote-requests=yes");
					this.Send("=servers=" + servers, true);
					List<string> source = this.Read();
					if (source.Last() != "!done")
					{
						source = this.Read();
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("AdjustDNS");
			}
		}

		public string GetEthernetPortStatus(string portName)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetEthernetPortStatus");
				if (this.EnsureConnection())
				{
					this.Send("/interface/ethernet/print", true);
					list = this.Read();
					bool flag = false;
					string str = string.Empty;
					int num = 0;
					while (num < list.Count)
					{
						if (list[num].IndexOf("=name=" + portName) == -1)
						{
							num++;
							continue;
						}
						flag = true;
						str = yrUtils.ExtractInfo(list[num], ".id=");
						break;
					}
					if (flag)
					{
						this.Send("/interface/ethernet/monitor");
						this.Send("=.id=" + str);
						this.Send(".tag=31", true);
						list = this.Read(true, 1);
						this.Send("/cancel");
						this.Send(".tag=31", true);
						List<string> list2 = this.Read();
						List<string> list3 = this.Read();
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetAutoswitcherAllScripts");
			}
			return list[0];
		}

		public void StartGettingTorchData(string interfaceName, string srcAddresses)
		{
			Task task = new Task(delegate
			{
				this.GetTorchDataStreaming(interfaceName, srcAddresses);
			});
			this.StopGettingTorchDataFlag = false;
			task.Start();
		}

		public void StopGettingTorchData()
		{
			this.StopGettingTorchDataFlag = true;
		}

		public void GetTorchDataStreaming(string interfaceName, string srcAddresses)
		{
			List<string> list = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetTorchData");
				if (this.EnsureConnection())
				{
					this.Send("/tool/torch");
					this.Send("=src-address=" + srcAddresses);
					this.Send("=ip-protocol=any");
					this.Send("=port=any");
					this.Send("=mac-protocol=any");
					this.Send("=dst-address=0.0.0.0/0");
					this.Send("=interface=" + interfaceName);
					this.Send(".tag=11", true);
					while (!this.StopGettingTorchDataFlag)
					{
						list = this.Read(true, 1);
						if (this.OnNewTorchLine != null)
						{
							this.OnNewTorchLine(list[0]);
						}
					}
					this.Send("/cancel");
					this.Send(".tag=11", true);
					List<string> list2 = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetTorchData");
			}
		}

		public string GetWIFIInfo(string interfaceName)
		{
			List<string> list = new List<string>();
			string empty = string.Empty;
			list = this.CheckWanWiFiInfo("shipPhysical");
			int num = 0;
			goto IL_0041;
			IL_0041:
			if (num < list.Count)
			{
				return "Channel: " + yrUtils.ExtractInfo(list[num], "channel=");
			}
			return empty;
			IL_003d:
			num++;
			goto IL_0041;
		}

		public List<string> GetRegisteredWIFIUsers(List<string> dhcpLeases)
		{
			List<string> list = new List<string>();
			List<string> list2 = new List<string>();
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetAllRegisteredWIFIUsers");
				if (this.EnsureConnection())
				{
					this.Send("/interface/wireless/registration-table/print", true);
					List<string> list3 = this.Read();
					if (list3.Last() != "!done")
					{
						list3 = this.Read();
					}
					for (int i = 0; i < list3.Count; i++)
					{
						if (!list3[i].Contains("!done"))
						{
							string str = "VN" + yrUtils.ExtractInfo(list3[i], "interface").Replace("shipWIFI", string.Empty);
							str = str + " MAC: " + yrUtils.ExtractInfo(list3[i], "mac-address").PadRight(20);
							str = str + " RX: " + yrUtils.ExtractInfo(list3[i], "rx-rate").PadRight(20);
							str = str + " TX: " + yrUtils.ExtractInfo(list3[i], "tx-rate").PadRight(20);
							str = str + " Signal: " + yrUtils.ExtractInfo(list3[i], "signal-to-noise").PadRight(8);
							str = str + " Last IP: " + yrUtils.ExtractInfo(list3[i], "last-ip").PadRight(15);
							string value = yrUtils.ExtractInfo(list3[i], "mac-address");
							foreach (string dhcpLease in dhcpLeases)
							{
								if (dhcpLease.Contains(value))
								{
									str = str + " [ " + yrUtils.ExtractInfo(dhcpLease, "host") + " ]";
									break;
								}
							}
							list2.Add(str);
						}
					}
					return list2;
				}
				return list2;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return list2;
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetAllRegisteredWIFIUsers");
			}
		}

		public List<string> GetActivePPP()
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetActivePPP");
				if (this.EnsureConnection())
				{
					this.Send("/ppp/active/print", true);
					return this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetActivePPP");
			}
			return new List<string>();
		}

		public void InitializeApiSSLAccess(bool ForceOverwrite = false)
		{
			try
			{
				this.AccessToRouterLock.EnterWriteLock("GetActivePPP");
				if (this.EnsureConnection())
				{
					this.Send("/ip/service/print", true);
					List<string> list = this.Read();
					foreach (string item in list)
					{
						if (item.Contains("api-ssl"))
						{
							if (!(yrUtils.ExtractInfo(item, "certificate") == "Locomarine-CA"))
							{
								break;
							}
							if (!(yrUtils.ExtractInfo(item, "invalid") == "false"))
							{
								break;
							}
							if (!(yrUtils.ExtractInfo(item, "disabled") == "false"))
							{
								break;
							}
							if (ForceOverwrite)
							{
								break;
							}
							return;
						}
					}
					this.Send("/certificate/print", true);
					list = this.Read();
					foreach (string item2 in list)
					{
						if (yrUtils.ExtractInfo(item2, "=name") == "Locomarine-CA")
						{
							this.Send("/certificate/remove");
							this.Send("=.id=" + yrUtils.ExtractInfo(item2, "=.id"), true);
							List<string> list2 = this.Read();
						}
					}
					this.Send("/certificate/add");
					this.Send("=name=Locomarine-CA");
					this.Send("=days-valid=3650");
					this.Send("=common-name=Locomarine-CA", true);
					list = this.Read();
					string str = yrUtils.ExtractInfo(list[0], "=ret");
					this.routerConnection.ReceiveTimeout = 60000;
					this.Send("/certificate/sign");
					this.Send("=.id=" + str);
					this.Send("=name=Locomarine-CA");
					this.Send("=ca-crl-host=10.80.0.1", true);
					list = this.Read();
					this.Send("/ip/service/print", true);
					list = this.Read();
					string str2 = string.Empty;
					foreach (string item3 in list)
					{
						if (item3.Contains("api-ssl"))
						{
							str2 = yrUtils.ExtractInfo(item3, "=.id");
							break;
						}
					}
					this.Send("/ip/service/set");
					this.Send("=.id=" + str2);
					this.Send("=disabled=no");
					this.Send("=certificate=Locomarine-CA", true);
					list = this.Read();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				this.AccessToRouterLock.ExitWriteLock("GetActivePPP");
			}
		}
	}
}
