namespace YR.Core
{
	public delegate void RouterNewInfo(string routerID, string newInfo);
}
