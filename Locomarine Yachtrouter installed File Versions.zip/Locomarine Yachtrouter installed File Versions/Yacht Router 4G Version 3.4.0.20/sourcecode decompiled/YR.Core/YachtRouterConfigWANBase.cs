using System;

namespace YR.Core
{
	[Serializable]
	public class YachtRouterConfigWANBase : YachtRouterConfigInterfaceBase
	{
		public bool TrafficControlAwailable;

		public bool RestrictExitToLAN
		{
			get;
			set;
		}

		public bool RestrictExitToShipWIFI1
		{
			get;
			set;
		}

		public bool RestrictExitToShipWIFI2
		{
			get;
			set;
		}

		public string CheckInternetStatusTargetIP
		{
			get;
			set;
		}

		public string Connection
		{
			get;
			set;
		}

		public string Usage
		{
			get;
			set;
		}
	}
}
