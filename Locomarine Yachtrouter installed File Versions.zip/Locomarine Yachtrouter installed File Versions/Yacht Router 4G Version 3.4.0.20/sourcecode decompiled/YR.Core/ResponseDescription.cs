namespace YR.Core
{
	public class ResponseDescription
	{
		private int m_dwStatus;

		private string m_szStatusDescription;

		public int Status
		{
			get
			{
				return this.m_dwStatus;
			}
			set
			{
				this.m_dwStatus = value;
			}
		}

		public string StatusDescription
		{
			get
			{
				return this.m_szStatusDescription;
			}
			set
			{
				this.m_szStatusDescription = value;
			}
		}

		public bool PositivePreliminary
		{
			get
			{
				return this.m_dwStatus / 100 == 1;
			}
		}

		public bool PositiveCompletion
		{
			get
			{
				return this.m_dwStatus / 100 == 2;
			}
		}

		public bool PositiveIntermediate
		{
			get
			{
				return this.m_dwStatus / 100 == 3;
			}
		}

		public bool TransientNegativeCompletion
		{
			get
			{
				return this.m_dwStatus / 100 == 4;
			}
		}

		public bool PermanentNegativeCompletion
		{
			get
			{
				return this.m_dwStatus / 100 == 5;
			}
		}
	}
}
