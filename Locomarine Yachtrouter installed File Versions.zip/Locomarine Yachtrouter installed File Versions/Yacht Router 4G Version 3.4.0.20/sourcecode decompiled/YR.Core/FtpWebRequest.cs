using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;

namespace YR.Core
{
	public class FtpWebRequest : WebRequest
	{
		private const int SOCKET_ERROR = -1;

		public string m_szCmdParameter;

		private Socket m_DataSocket;

		private Socket m_ControlSocket;

		private Uri m_RequestUri;

		private Uri m_ProxyUri;

		private Stream m_RequestStream;

		private ICredentials m_Credentials;

		private IWebProxy m_Proxy;

		private ServicePoint m_ServicePoint;

		private bool _bPassiveMode;

		private long m_dwdwContentLength;

		private string m_szContentType;

		private StringBuilder m_sbControlSocketLog;

		private Exception m_Exception;

		private string m_szMethod;

		private string m_szServerMethod;

		private FtpCommandType m_CommandType;

		public bool Passive
		{
			get
			{
				return this._bPassiveMode;
			}
			set
			{
				this._bPassiveMode = value;
			}
		}

		public override string Method
		{
			get
			{
				return this.m_szMethod;
			}
			set
			{
				if (value == null)
				{
					throw new ArgumentNullException("Method");
				}
				this.m_szServerMethod = FtpWebRequest.GetServerCommand(value);
				this.m_CommandType = FtpWebRequest.FindCommandType(this.m_szServerMethod);
				if (this.m_CommandType == FtpCommandType.FtpCommandNotSupported)
				{
					throw new NotSupportedException(value + " is not supported");
				}
				this.m_szMethod = value;
			}
		}

		public override ICredentials Credentials
		{
			get
			{
				return this.m_Credentials;
			}
			set
			{
				this.m_Credentials = value;
			}
		}

		public override string ConnectionGroupName
		{
			get
			{
				throw new NotSupportedException();
			}
			set
			{
				throw new NotSupportedException();
			}
		}

		public override long ContentLength
		{
			get
			{
				return this.m_dwdwContentLength;
			}
			set
			{
				this.m_dwdwContentLength = value;
			}
		}

		public override string ContentType
		{
			get
			{
				return this.m_szContentType;
			}
			set
			{
				this.m_szContentType = value;
			}
		}

		public override IWebProxy Proxy
		{
			get
			{
				return this.m_Proxy;
			}
			set
			{
				this.m_Proxy = value;
			}
		}

		public FtpWebRequest(Uri Url)
		{
			if (Url.Scheme != "ftp")
			{
				throw new NotSupportedException("This protocol is not supported");
			}
			this.m_RequestUri = Url;
			this.m_szMethod = "dir";
			this._bPassiveMode = false;
			this.m_szCmdParameter = Url.AbsolutePath;
			this.m_sbControlSocketLog = new StringBuilder();
		}

		public override Stream GetRequestStream()
		{
			if (this.m_CommandType != FtpCommandType.FtpDataReceiveCommand)
			{
				throw new InvalidOperationException("cant upload data with this method type");
			}
			if (this.m_RequestStream == null)
			{
				this.m_RequestStream = new FtpStream(new MemoryStream(), false, true, false);
				return this.m_RequestStream;
			}
			throw new InvalidOperationException("request stream already retrieved");
		}

		public override WebResponse GetResponse()
		{
			string text = "anonymous";
			string text2 = "User@";
			if (this.m_Proxy != null)
			{
				this.m_ProxyUri = this.GetProxyUri();
				if (this.m_ProxyUri != (Uri)null)
				{
					if (this.m_Proxy.Credentials != null)
					{
						NetworkCredential credential = this.m_Proxy.Credentials.GetCredential(this.m_ProxyUri, null);
						text = credential.UserName;
						text2 = credential.Password;
						if (text == null || text == string.Empty)
						{
							text = "anonymous";
						}
						if (text2 == null || text2 == string.Empty)
						{
							text2 = "User@";
						}
					}
					else if (this.m_Credentials != null)
					{
						NetworkCredential credential2 = this.m_Credentials.GetCredential(this.m_RequestUri, null);
						if (credential2 != null)
						{
							text = credential2.UserName;
							text2 = credential2.Password;
						}
						if (text == null || text == string.Empty)
						{
							text = "anonymous";
						}
						if (text2 == null || text2 == string.Empty)
						{
							text2 = "User@";
						}
					}
					text = text + "@" + this.m_RequestUri.Host.ToString();
				}
				this.m_ServicePoint = ServicePointManager.FindServicePoint(this.m_RequestUri, this.m_Proxy);
			}
			else
			{
				this.m_ServicePoint = ServicePointManager.FindServicePoint(this.m_RequestUri, null);
				if (this.m_Credentials != null)
				{
					NetworkCredential credential3 = this.m_Credentials.GetCredential(this.m_RequestUri, null);
					text = credential3.UserName;
					text2 = credential3.Password;
					if (text == null || text == string.Empty)
					{
						text = "anonymous";
					}
					if (text2 == null || text2 == string.Empty)
					{
						text2 = "User@";
					}
				}
			}
			if (!this.DoLogin(text, text2))
			{
				throw new ApplicationException("Login Failed\nServer Log:\n" + this.m_sbControlSocketLog.ToString());
			}
			return this.GetFtpResponse();
		}

		private WebResponse GetFtpResponse()
		{
			FtpWebResponse ftpWebResponse = null;
			if (this.m_CommandType == FtpCommandType.FtpDataReceiveCommand || this.m_CommandType == FtpCommandType.FtpDataSendCommand)
			{
				if (this._bPassiveMode)
				{
					this.OpenPassiveDataConnection();
				}
				else
				{
					this.OpenDataConnection();
				}
			}
			string parametertopass = "I";
			if (this.m_szContentType == "ascii")
			{
				parametertopass = "A";
			}
			this.SendCommand("TYPE", parametertopass);
			ResponseDescription responseDescription = this.ReceiveCommandResponse();
			if (!responseDescription.PositiveCompletion)
			{
				throw new ApplicationException("Data negotiation failed:\n" + this.m_sbControlSocketLog.ToString());
			}
			if (this.m_szServerMethod == "PWD")
			{
				this.m_szCmdParameter = null;
			}
			this.SendCommand(this.m_szServerMethod, this.m_szCmdParameter);
			responseDescription = this.ReceiveCommandResponse();
			if (this.m_CommandType == FtpCommandType.FtpDataSendCommand)
			{
				if (responseDescription.PositivePreliminary)
				{
					if (this.m_RequestStream != null)
					{
						Socket socket = (!this._bPassiveMode) ? this.m_DataSocket.Accept() : this.m_DataSocket;
						if (socket == null)
						{
							throw new ProtocolViolationException("Accept failed ");
						}
						this.SendData(socket);
						socket.Close();
						ResponseDescription responseDescription2 = this.ReceiveCommandResponse();
						ftpWebResponse = new FtpWebResponse(responseDescription2.Status, responseDescription2.StatusDescription, this.m_sbControlSocketLog.ToString());
						goto IL_0182;
					}
					throw new ApplicationException("Data to be uploaded not specified");
				}
				this.m_Exception = new ApplicationException(this.ComposeExceptionMessage(responseDescription, this.m_sbControlSocketLog.ToString()));
				goto IL_0182;
			}
			if (this.m_CommandType == FtpCommandType.FtpDataReceiveCommand)
			{
				if (responseDescription.PositivePreliminary)
				{
					Socket socket2 = (!this._bPassiveMode) ? this.m_DataSocket.Accept() : this.m_DataSocket;
					if (socket2 == null)
					{
						throw new ProtocolViolationException("DataConnection failed ");
					}
					Stream downloadStream = this.ReceiveData(socket2);
					socket2.Close();
					ResponseDescription responseDescription3 = this.ReceiveCommandResponse();
					ftpWebResponse = new FtpWebResponse(responseDescription3.Status, responseDescription3.StatusDescription, this.m_sbControlSocketLog.ToString());
					ftpWebResponse.SetDownloadStream(downloadStream);
				}
				else
				{
					this.m_Exception = new ApplicationException(this.ComposeExceptionMessage(responseDescription, this.m_sbControlSocketLog.ToString()));
				}
				this.CloseDataConnection();
			}
			else
			{
				ftpWebResponse = new FtpWebResponse(responseDescription.Status, responseDescription.StatusDescription, this.m_sbControlSocketLog.ToString());
			}
			goto IL_0265;
			IL_0182:
			this.CloseDataConnection();
			goto IL_0265;
			IL_0265:
			if (this.m_Exception != null)
			{
				throw this.m_Exception;
			}
			return ftpWebResponse;
		}

		private bool DoLogin(string UserID, string Password)
		{
			this.OpenControlConnection(this.m_ServicePoint.Address);
			this.SendCommand("USER", UserID);
			ResponseDescription responseDescription = this.ReceiveCommandResponse();
			if (responseDescription.Status == 331)
			{
				this.SendCommand("PASS", Password);
				responseDescription = this.ReceiveCommandResponse();
				if (responseDescription.Status == 230)
				{
					return true;
				}
				return false;
			}
			return false;
		}

		private void OpenDataConnection()
		{
			if (this.m_DataSocket != null)
			{
				throw new ApplicationException("Data socket is already open.");
			}
			this.m_DataSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
			IPHostEntry hostByName = Dns.GetHostByName(Dns.GetHostName());
			IPEndPoint localEP = new IPEndPoint(hostByName.AddressList[0], 0);
			this.m_DataSocket.Bind(localEP);
			this.m_DataSocket.Listen(5);
			IPEndPoint iPEndPoint = (IPEndPoint)this.m_DataSocket.LocalEndPoint;
			uint address = (uint)iPEndPoint.Address.Address;
			string parametertopass = this.FormatAddress(address, iPEndPoint.Port);
			this.SendCommand("PORT", parametertopass);
			ResponseDescription responseDescription = this.ReceiveCommandResponse();
			if (responseDescription.PositiveCompletion)
			{
				return;
			}
			throw new ApplicationException("Couldnt open data connection\n" + this.ComposeExceptionMessage(responseDescription, this.m_sbControlSocketLog.ToString()));
		}

		private void OpenPassiveDataConnection()
		{
			if (this.m_DataSocket != null)
			{
				throw new ProtocolViolationException();
			}
			string text = null;
			int num = 0;
			this.SendCommand("PASV", string.Empty);
			ResponseDescription responseDescription = this.ReceiveCommandResponse();
			if (!responseDescription.PositiveCompletion)
			{
				throw new ApplicationException("Couldnt open passive data connection\n" + this.ComposeExceptionMessage(responseDescription, this.m_sbControlSocketLog.ToString()));
			}
			text = this.getIPAddress(responseDescription.StatusDescription);
			num = this.getPort(responseDescription.StatusDescription);
			this.m_DataSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
			if (this.m_DataSocket == null)
			{
				throw new ProtocolViolationException("Error in creating Data Socket");
			}
			IPHostEntry hostByName = Dns.GetHostByName(this.m_RequestUri.Host);
			IPEndPoint remoteEP = new IPEndPoint(hostByName.AddressList[0], num);
			try
			{
				this.m_DataSocket.Connect(remoteEP);
			}
			catch (Exception)
			{
				this.m_DataSocket.Close();
				this.m_DataSocket = null;
				throw new ProtocolViolationException("Passive connection failure");
			}
		}

		private Uri GetProxyUri()
		{
			Uri result = null;
			if (this.m_Proxy != null && !this.m_Proxy.IsBypassed(this.m_RequestUri))
			{
				result = this.m_Proxy.GetProxy(this.m_RequestUri);
			}
			return result;
		}

		private void OpenControlConnection(Uri uriToConnect)
		{
			string host = uriToConnect.Host;
			int port = uriToConnect.Port;
			if (this.m_ControlSocket != null)
			{
				throw new ProtocolViolationException("Control connection already in use");
			}
			this.m_ControlSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
			EndPoint endPoint = new IPEndPoint(IPAddress.Any, 0);
			EndPoint localEP = endPoint;
			try
			{
				this.m_ControlSocket.Bind(localEP);
			}
			catch (Exception innerException)
			{
				this.m_ControlSocket.Close();
				this.m_ControlSocket = null;
				throw new ApplicationException(" Error in opening control connection", innerException);
			}
			localEP = this.m_ControlSocket.LocalEndPoint;
			try
			{
				IPHostEntry hostByName = Dns.GetHostByName(host);
				IPEndPoint remoteEP = new IPEndPoint(hostByName.AddressList[0], port);
				try
				{
					this.m_ControlSocket.Connect(remoteEP);
				}
				catch (Exception innerException2)
				{
					this.m_ControlSocket.Close();
					this.m_ControlSocket = null;
					string message = "Winsock error: " + Convert.ToString(Marshal.GetLastWin32Error());
					throw new ApplicationException(message, innerException2);
				}
			}
			catch (Exception ex)
			{
				this.m_ControlSocket.Close();
				this.m_ControlSocket = null;
				throw ex;
			}
			MemoryStream memoryStream = new MemoryStream();
			do
			{
				int num = 256;
				byte[] buffer = new byte[num + 1];
				int count = this.m_ControlSocket.Receive(buffer, num, SocketFlags.None);
				memoryStream.Write(buffer, 0, count);
			}
			while (!this.IsCompleteResponse(memoryStream));
		}

		public void CloseDataConnection()
		{
			if (this.m_DataSocket != null)
			{
				this.m_DataSocket.Close();
				this.m_DataSocket = null;
			}
		}

		private void CloseControlConnection()
		{
			this.m_ControlSocket.Close();
			this.m_ControlSocket = null;
		}

		private Stream ReceiveData(Socket Accept)
		{
			if (this.m_DataSocket == null)
			{
				throw new ArgumentNullException();
			}
			MemoryStream memoryStream = new MemoryStream();
			int num = 256;
			byte[] array = new byte[num + 1];
			while (true)
			{
				int num2 = 0;
				array[num2] = 0;
				num2 = Accept.Receive(array, num, SocketFlags.None);
				if (num2 > 0)
				{
					memoryStream.Write(array, 0, num2);
					continue;
				}
				break;
			}
			return memoryStream;
		}

		private void SendCommand(string RequestedMethod, string Parametertopass)
		{
			string str = RequestedMethod;
			if (Parametertopass != null && !Parametertopass.Equals(string.Empty))
			{
				str = str + " " + Parametertopass;
			}
			str += "\r\n";
			this.m_sbControlSocketLog.Append(str);
			byte[] bytes = Encoding.ASCII.GetBytes(str.ToCharArray());
			if (this.m_ControlSocket == null)
			{
				throw new ProtocolViolationException();
			}
			int num = this.m_ControlSocket.Send(bytes, str.Length, SocketFlags.None);
			if (num >= 0)
			{
				return;
			}
			throw new ApplicationException("Error writing to control socket");
		}

		private ResponseDescription ReceiveCommandResponse()
		{
			ResponseDescription responseDescription = new ResponseDescription();
			int num = 0;
			string text = null;
			bool flag = false;
			if (this.m_ControlSocket == null)
			{
				throw new ApplicationException("Control COnnection not opened");
			}
			MemoryStream memoryStream = new MemoryStream();
			while (true)
			{
				int num2 = 256;
				byte[] array = new byte[num2 + 1];
				int num3 = 0;
				array[0] = 0;
				num3 = this.m_ControlSocket.Receive(array, num2, SocketFlags.None);
				if (num3 > 0)
				{
					memoryStream.Write(array, 0, num3);
					string @string = Encoding.ASCII.GetString(array, 0, num3);
					this.m_sbControlSocketLog.Append(@string);
					flag = this.IsCompleteResponse(memoryStream);
					if (flag)
					{
						break;
					}
					continue;
				}
				break;
			}
			if (flag)
			{
				try
				{
					memoryStream.Position = 0L;
					byte[] array2 = new byte[3];
					memoryStream.Read(array2, 0, 3);
					string string2 = Encoding.ASCII.GetString(array2, 0, 3);
					num = Convert.ToInt16(string2);
				}
				catch
				{
					num = -1;
				}
				int num4 = (int)memoryStream.Length;
				memoryStream.Position = 0L;
				byte[] array3 = new byte[num4];
				memoryStream.Read(array3, 0, num4);
				text = Encoding.ASCII.GetString(array3, 4, num4 - 4);
				responseDescription.Status = num;
				responseDescription.StatusDescription = text;
				return responseDescription;
			}
			throw new ProtocolViolationException();
		}

		private bool IsCompleteResponse(Stream responseStream)
		{
			bool flag = false;
			int num = (int)responseStream.Length;
			responseStream.Position = 0L;
			if (num >= 5)
			{
				int num2 = -1;
				byte[] array = new byte[num];
				responseStream.Read(array, 0, num);
				string @string = Encoding.ASCII.GetString(array, 0, num);
				if (num == 5 && array[num - 1] == 10)
				{
					flag = true;
				}
				else if (array[num - 1] == 10 && array[num - 2] == 13)
				{
					flag = true;
				}
				if (num == 5 && array[num - 1] == 10)
				{
					flag = true;
				}
				if (flag)
				{
					try
					{
						num2 = Convert.ToInt16(@string.Substring(0, 3));
					}
					catch
					{
						num2 = -1;
					}
					if (@string[3] == '-')
					{
						int num3 = 0;
						num3 = num - 2;
						while (num3 > 0 && (array[num3] != 10 || array[num3 - 1] != 13))
						{
							num3--;
						}
						if (num3 == 0)
						{
							flag = false;
						}
						else if (@string[num3 + 4] != ' ')
						{
							flag = false;
						}
						else
						{
							int num4 = -1;
							try
							{
								num4 = Convert.ToInt16(@string.Substring(num3 + 1, 3));
							}
							catch
							{
								num4 = -1;
							}
							if (num4 != num2)
							{
								flag = false;
							}
						}
					}
					else if (@string[3] != ' ')
					{
						num2 = -1;
					}
				}
			}
			else
			{
				flag = false;
			}
			return flag;
		}

		public static string GetServerCommand(string command)
		{
			if (command == null)
			{
				throw new ArgumentNullException("command");
			}
			string a = command.ToLower();
			string text = null;
			if (a == "dir")
			{
				text = "LIST";
			}
			else if (a == "get")
			{
				text = "RETR";
			}
			else if (a == "cd")
			{
				text = "CWD";
			}
			else if (a == "pwd")
			{
				text = "PWD";
			}
			else if (a == "put")
			{
				text = "STOR";
			}
			if (text == null)
			{
				throw new NotSupportedException(command);
			}
			return text;
		}

		public static FtpCommandType FindCommandType(string command)
		{
			if (!command.Equals("USER") && !command.Equals("PASS") && !command.Equals("CWD") && !command.Equals("PWD") && !command.Equals("CDUP") && !command.Equals("QUIT"))
			{
				if (!command.Equals("RETR") && !command.Equals("LIST"))
				{
					if (!command.Equals("STOR") && !command.Equals("STOU"))
					{
						return FtpCommandType.FtpCommandNotSupported;
					}
					return FtpCommandType.FtpDataSendCommand;
				}
				return FtpCommandType.FtpDataReceiveCommand;
			}
			return FtpCommandType.FtpControlCommand;
		}

		private int SendData(Socket Accept)
		{
			if (Accept == null)
			{
				throw new ArgumentNullException();
			}
			((FtpStream)this.m_RequestStream).InternalPosition = 0L;
			int num = (int)((FtpStream)this.m_RequestStream).InternalLength;
			byte[] buffer = new byte[num];
			((FtpStream)this.m_RequestStream).InternalRead(buffer, 0, num);
			int result = Accept.Send(buffer, num, SocketFlags.None);
			((FtpStream)this.m_RequestStream).InternalClose();
			return result;
		}

		private string FormatAddress(uint Address, int Port)
		{
			StringBuilder stringBuilder = new StringBuilder(32);
			uint num = Address;
			while (num != 0)
			{
				uint value = num % 256u;
				num /= 256u;
				stringBuilder.Append(value);
				stringBuilder.Append(',');
			}
			stringBuilder.Append(Port / 256);
			stringBuilder.Append(',');
			stringBuilder.Append(Port % 256);
			return stringBuilder.ToString();
		}

		private string getIPAddress(string str)
		{
			StringBuilder stringBuilder = new StringBuilder(32);
			string text = null;
			int num = str.IndexOf("(") + 1;
			int num2 = str.IndexOf(",");
			for (int i = 0; i < 3; i++)
			{
				text = str.Substring(num, num2 - num) + ".";
				stringBuilder.Append(text);
				num = num2 + 1;
				num2 = str.IndexOf(",", num);
			}
			text = str.Substring(num, num2 - num);
			stringBuilder.Append(text);
			return stringBuilder.ToString();
		}

		private int getPort(string str)
		{
			int num = 0;
			int num2 = str.IndexOf("(");
			int num3 = str.IndexOf(",");
			for (int i = 0; i < 3; i++)
			{
				num2 = num3 + 1;
				num3 = str.IndexOf(",", num2);
			}
			num2 = num3 + 1;
			num3 = str.IndexOf(",", num2);
			string value = str.Substring(num2, num3 - num2);
			num2 = num3 + 1;
			num3 = str.IndexOf(")", num2);
			string value2 = str.Substring(num2, num3 - num2);
			num = Convert.ToInt32(value) * 256;
			return num + Convert.ToInt32(value2);
		}

		internal string ComposeExceptionMessage(ResponseDescription resp_desc, string log)
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("FTP Protocol Error.....\n");
			stringBuilder.Append("Status: " + resp_desc.Status + "\n");
			stringBuilder.Append("Description: " + resp_desc.StatusDescription + "\n");
			stringBuilder.Append("\n");
			stringBuilder.Append("--------------------------------\n");
			stringBuilder.Append(log);
			stringBuilder.Append("\n");
			return stringBuilder.ToString();
		}
	}
}
