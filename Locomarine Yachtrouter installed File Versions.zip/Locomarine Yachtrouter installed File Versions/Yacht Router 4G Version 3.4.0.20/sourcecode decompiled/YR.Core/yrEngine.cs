using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Tamir.SharpSsh.java.io;
using Tamir.SharpSsh.jsch;

namespace YR.Core
{
	public class yrEngine
	{
		public class MyUserInfo : UserInfo, UIKeyboardInteractive
		{
			private string passwd;

			public MyUserInfo(string Password)
			{
				this.passwd = Password;
			}

			public string getPassword()
			{
				return this.passwd;
			}

			public bool promptYesNo(string str)
			{
				return true;
			}

			public string getPassphrase()
			{
				return null;
			}

			public bool promptPassphrase(string message)
			{
				return true;
			}

			public bool promptPassword(string message)
			{
				return true;
			}

			public void showMessage(string message)
			{
			}

			public string[] promptKeyboardInteractive(string destination, string name, string instruction, string[] prompt, bool[] echo)
			{
				string text = (prompt == null || prompt.Length <= 0) ? string.Empty : prompt[0];
				this.passwd = string.Empty;
				return new string[1]
				{
					this.passwd
				};
			}
		}

		public static string RouterConfig_Username = "loco";

		public static string RouterConfig_Password = "ySyteMJwWuyAyMu84D";

		public static List<string> RouterConfig_PasswordOlds = new List<string>
		{
			"SecureConnectingUser"
		};

		public static string RouterConfig_FtpPath = "ftp://10.80.0.1/YachtRouterGen3.xml";

		public static string RouterSupportInfo_FtpPath = "ftp://10.80.0.1/SupportInfo.png";

		public static string extenderIdentity = "YR_WIFI_EXTENDER";

		public static string rootExtenderDHCPServer = "dhcpBACKBONE";

		public static string bridgePrefix = "bridgeEoip_";

		public static string routingMarkPrefix = "markAlwaysON_";

		public static string virtualApPrefix = "wifiAlwaysON_";

		public static string virtualApSecurityProfilePrefix = "SecurityProfile_";

		public static string eoipTunnelPrefix = "eoipTunnel_";

		public static string shipPhysicalWifiInterface = "shipPhysical";

		public static string defaultPassword = "12345678";

		public static string rootIpAddress = "10.90.";

		public static string rootSubnet = "255.255.255.0";

		public static string dhcpPoolNamePrefix = "dhcpAlwaysOn_pool_";

		public static string dhcpServerNamePrefix = "dhcpAlwaysOnServer_";

		public static string curAssemblyVersion = "3.4.0.20";

		private YachtRouterMainConfiguration _mainConfig = new YachtRouterMainConfiguration();

		public yrLogger _curLogger;

		private List<MK> _Routers = new List<MK>();

		private Thread checkInternetStatus;

		private Thread checkRouterStatus;

		private Thread checkDiagnosticsStatus;

		private bool _workingInDeviceMode;

		public bool LateConfigurationLoadFinished;

		private bool _IsConnectedToRouter;

		private bool _IsModuleMissing;

		private Thread threadLateConfigurationLoad;

		private bool _PerformUpgrade;

		public bool PerformDiagnostics;

		private bool _SuspendUpdatesNew = true;

		private bool _InterfaceUpdateInProgess;

		private Thread curScanThread;

		private bool StopScanning;

		private Thread curWanWifiStatusUpdateThread;

		private bool StopWanStatusUpdateFlag;

		private bool WanStatusShowWifiAdditionalInfo;

		private bool WanStatusShowMobileAdditionalInfo;

		private bool WanStatusUpdateGetResultsReallyReallyStopped = true;

		private bool requestLTERunningParam;

		private int LTERunningPreviousData;

		private int LTERunning;

		private string mobileLastOperator = string.Empty;

		private DateTime timeWorkingPasswordStart;

		private bool boolStartedWorkingPasswordStart;

		private string WorkingPasswordLastStatus = string.Empty;

		private int WorkingPasswordChangeCounter;

		private string lastSignalStrength = string.Empty;

		private string lastPinStatus = string.Empty;

		private string lastFunctionality = string.Empty;

		private bool ready;

		public bool IsConnectedToRouter
		{
			get
			{
				return this._IsConnectedToRouter;
			}
			set
			{
				this._IsConnectedToRouter = value;
			}
		}

		public YachtRouterMainConfiguration mainConfig
		{
			get
			{
				return this._mainConfig;
			}
		}

		public bool ShowDiagnosticInfo
		{
			get
			{
				return this._mainConfig.ShowDiagnosticInfo;
			}
			set
			{
				this._mainConfig.ShowDiagnosticInfo = value;
			}
		}

		public bool SuspendUpdates
		{
			get
			{
				return this._SuspendUpdatesNew;
			}
			set
			{
				bool flag = false;
				if (this._SuspendUpdatesNew != value)
				{
					flag = true;
				}
				this._curLogger.LogMessage("SUSPEND UPDATES: " + this._SuspendUpdatesNew);
				this._SuspendUpdatesNew = value;
				this.FireOnStatusUpdate(RouterStatuses.PleaseWaitMessage, value);
				if (flag)
				{
					while (this._InterfaceUpdateInProgess)
					{
						Thread.Sleep(50);
					}
				}
			}
		}

		public List<YachtRouterConfigWifiAP> WifiApConfiguration
		{
			get
			{
				return this._mainConfig.WifiAPs;
			}
		}

		public List<YachtRouterConfigWANLan> WanSatConfiguration
		{
			get
			{
				return this._mainConfig.LanWANs;
			}
		}

		public List<YachtRouterConfigWANMobile> WanMobileConfiguration
		{
			get
			{
				return this._mainConfig.MobileWANs;
			}
		}

		public List<YachtRouterConfigWANWifi> WanWifiConfiguration
		{
			get
			{
				return this._mainConfig.WifiWANs;
			}
		}

		public event NewInfo OnNewInfo
		{
			add
			{
				NewInfo newInfo = this.OnNewInfo;
				NewInfo newInfo2;
				do
				{
					newInfo2 = newInfo;
					newInfo = Interlocked.CompareExchange<NewInfo>(ref this.OnNewInfo, (NewInfo)Delegate.Combine(newInfo2, value), newInfo);
				}
				while (newInfo != newInfo2);
			}
			remove
			{
				NewInfo newInfo = this.OnNewInfo;
				NewInfo newInfo2;
				do
				{
					newInfo2 = newInfo;
					newInfo = Interlocked.CompareExchange<NewInfo>(ref this.OnNewInfo, (NewInfo)Delegate.Remove(newInfo2, value), newInfo);
				}
				while (newInfo != newInfo2);
			}
		}

		public event StatusUpdate OnStatusUpdate
		{
			add
			{
				StatusUpdate statusUpdate = this.OnStatusUpdate;
				StatusUpdate statusUpdate2;
				do
				{
					statusUpdate2 = statusUpdate;
					statusUpdate = Interlocked.CompareExchange<StatusUpdate>(ref this.OnStatusUpdate, (StatusUpdate)Delegate.Combine(statusUpdate2, value), statusUpdate);
				}
				while (statusUpdate != statusUpdate2);
			}
			remove
			{
				StatusUpdate statusUpdate = this.OnStatusUpdate;
				StatusUpdate statusUpdate2;
				do
				{
					statusUpdate2 = statusUpdate;
					statusUpdate = Interlocked.CompareExchange<StatusUpdate>(ref this.OnStatusUpdate, (StatusUpdate)Delegate.Remove(statusUpdate2, value), statusUpdate);
				}
				while (statusUpdate != statusUpdate2);
			}
		}

		public yrEngine()
		{
			this._curLogger = new yrLogger();
		}

		public static void CreateTestConfiguration(bool workingInDeviceMode)
		{
			YachtRouterMainConfiguration yachtRouterMainConfiguration = new YachtRouterMainConfiguration();
			yachtRouterMainConfiguration.InitializeStaticConfig();
			yachtRouterMainConfiguration.SaveConfiguration();
		}

		public void DestroyEngine()
		{
			try
			{
				foreach (MK router in this._Routers)
				{
					router.Close();
				}
				this.checkInternetStatus.Abort();
				this.checkRouterStatus.Abort();
				this.threadLateConfigurationLoad.Abort();
			}
			catch
			{
			}
		}

		public void InitEngine(bool WorkingInDeviceMode, bool PerformUpgrade, bool InitializeDiagnosticsUpdates = false)
		{
			try
			{
				this._workingInDeviceMode = WorkingInDeviceMode;
				this._PerformUpgrade = PerformUpgrade;
				if (!this._mainConfig.LoadConfiguration(this._workingInDeviceMode))
				{
					this._IsConnectedToRouter = false;
					this._IsModuleMissing = false;
					this.FireOnStatusUpdate(RouterStatuses.RouterMissing, null);
				}
				else
				{
					this._curLogger.InitLogger(this, this._workingInDeviceMode);
					this._curLogger.OutputLogFile = this._mainConfig.ShowDiagnosticInfo;
					foreach (YachtRouterRouterConfig routerConfig in this._mainConfig.RouterConfigs)
					{
						MK mK = new MK(routerConfig.RouterID, routerConfig.RouterIP.ToString(), this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
						mK.OnRouterNewInfo += this._RouterEngine_OnRouterNewInfo;
						this._Routers.Add(mK);
					}
					Parallel.ForEach(this._Routers, delegate(MK curRouter)
					{
						if (!curRouter.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password))
						{
							if (this.CheckIfWanWifiIsMissingForRouter(curRouter, true))
							{
								this.FireOnStatusUpdate(RouterStatuses.RouterMissingWanWifi, null);
							}
							if (this.CheckIfMobileExpanderIsMissingForRouter(curRouter, true))
							{
								this.FireOnStatusUpdate(RouterStatuses.RouterMissingMobileExpander, null);
							}
						}
					});
					this.InitializeBackThreads();
					this.threadLateConfigurationLoad = new Thread(this.LateConfigurationUpdateProc);
					this.threadLateConfigurationLoad.IsBackground = true;
					this.threadLateConfigurationLoad.Start();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		private void InitializeBackThreads()
		{
			this.checkInternetStatus = new Thread(this.CheckInternetStatus);
			this.checkInternetStatus.Name = "Check Internet Status Thread";
			this.checkInternetStatus.IsBackground = true;
			this.checkRouterStatus = new Thread(this.CheckInterfaceStatusesNew);
			this.checkRouterStatus.Name = "Check Router Status Thread";
			this.checkRouterStatus.IsBackground = true;
			this.checkDiagnosticsStatus = new Thread(this.CheckDiagnosticsStatus);
			this.checkDiagnosticsStatus.Name = "Check Diagnostics Status Thread";
			this.checkDiagnosticsStatus.IsBackground = true;
		}

		private void LateConfigurationUpdateProc()
		{
			try
			{
				this.CheckRouterConnectionsAreActive(this._Routers, false);
				if (this._PerformUpgrade)
				{
					this.ApplyPatches();
				}
				this.IsConnectedToRouter = this.CheckRouterConnectionsAreActive();
				this.UpdateWanSatConfigurationForAllWans();
				this.UpdateVNConfiguration();
				this.UpdateWanWifiConfigurationForAllWans();
				this.UpdateWanMobileConfigurationForAllWans();
				this.UpdateWifiApConfiguration();
				this.LateConfigurationLoadFinished = true;
				this.checkInternetStatus.Start();
				this.checkRouterStatus.Start();
				this.checkDiagnosticsStatus.Start();
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void SuspendUpdatesQuiet()
		{
			this._SuspendUpdatesNew = true;
		}

		public MK GetRouterByRouterID(string RouterID)
		{
			for (int i = 0; i < this._Routers.Count; i++)
			{
				if (this._Routers[i].RouterID == RouterID)
				{
					return this._Routers[i];
				}
			}
			return null;
		}

		public MK GetRouterByRouterIP(string RouterIP)
		{
			MK mK = new MK("wifiExtender", RouterIP, this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
			mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
			return mK;
		}

		public bool CheckRouterConnectionsAreActive()
		{
			return this.CheckRouterConnectionsAreActive(this._Routers, true);
		}

		public bool CheckRouterConnectionsAreActive(List<MK> routers, bool FireNotifications = true)
		{
			if (routers.Count == 0)
			{
				return false;
			}
			for (int i = 0; i < routers.Count; i++)
			{
				if (!routers[i].ConnectedToRouter && !routers[i].EnsureConnection())
				{
					if (FireNotifications)
					{
						this.FireOnStatusUpdate(RouterStatuses.ConnectedToRouter, new List<string>
						{
							"False"
						});
					}
					return false;
				}
			}
			this._IsConnectedToRouter = true;
			if (!this._IsModuleMissing && FireNotifications)
			{
				this.FireOnStatusUpdate(RouterStatuses.ConnectedToRouter, new List<string>
				{
					"True"
				});
			}
			return true;
		}

		private void CheckInterfaceStatusesNew()
		{
			Dictionary<string, string> wanStatuses;
			while (true)
			{
				List<MK> list = new List<MK>();
				try
				{
					foreach (MK router in this._Routers)
					{
						MK mK = new MK(router.RouterID, router.RouterIP, this._curLogger, string.Empty);
						mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
						list.Add(mK);
					}
					while (true)
					{
						try
						{
							if (!this.SuspendUpdates)
							{
								if (this.CheckRouterConnectionsAreActive(list, true))
								{
									wanStatuses = new Dictionary<string, string>();
									foreach (MK item in list)
									{
										List<string> list2 = item.RouteGetTargets();
										foreach (string item2 in list2)
										{
											string text = yrUtils.ExtractInfo(item2, "=routing-mark=");
											if (text.StartsWith("108"))
											{
												string text2 = yrUtils.ExtractInfo(item2, "=comment=");
												if (!text2.StartsWith("10.8"))
												{
													string text3 = text2;
													if (text != "1080")
													{
														if (this.SuspendUpdates)
														{
															break;
														}
														string str = string.Empty;
														int num = Convert.ToInt16(text[3].ToString());
														if (num <= this.mainConfig.VNs.Count)
														{
															if (this.mainConfig.VNs[num - 1].AutoswitchAvailable && this.CheckIsEnabledDisableAutoswitcher(num))
															{
																str = "(A) ";
															}
															this.FireOnStatusUpdate(RouterStatuses.VesselNetworkWAN, new List<string>
															{
																text[3].ToString(),
																str + item.GetWanInterfaceTitle(text2)
															});
														}
													}
												}
											}
										}
									}
									Parallel.ForEach(list, delegate(MK curRouter)
									{
										List<string> list3 = curRouter.RouteGetTargets();
										foreach (string item3 in list3)
										{
											string text4 = yrUtils.ExtractInfo(item3, "=routing-mark=");
											if (text4.StartsWith("108"))
											{
												string text5 = yrUtils.ExtractInfo(item3, "=comment=");
												if (!text5.StartsWith("10.8"))
												{
													string interfaceName = text5;
													if (text4 != "1080")
													{
														if (this.SuspendUpdates)
														{
															break;
														}
														string text6 = "connected";
														if (!wanStatuses.ContainsKey(text5))
														{
															if (!curRouter.CheckIsInterfaceEnabledPhysicalByInterface(interfaceName))
															{
																text6 = "disabled";
															}
															else
															{
																foreach (YachtRouterConfigWANBase allWan in this.mainConfig.GetAllWans())
																{
																	if (allWan.InterfaceName == text5)
																	{
																		string[] array = allWan.CheckInternetStatusTargetIP.Split('|');
																		string[] array2 = array;
																		foreach (string internetStatusTargetIP in array2)
																		{
																			if (curRouter.CheckWanInternetStatus(internetStatusTargetIP))
																			{
																				text6 = "connected";
																				break;
																			}
																			text6 = "nointernet";
																		}
																		break;
																	}
																}
															}
															wanStatuses.Add(text5, text6);
															this.SetWanInternetStatus(text5, text6);
														}
														this.FireOnStatusUpdate(RouterStatuses.VesselNetworkWANStatus, new List<string>
														{
															text4[3].ToString(),
															wanStatuses[text5],
															text5
														});
													}
												}
											}
										}
									});
								}
								Thread.Sleep(2000);
							}
							this._InterfaceUpdateInProgess = false;
							Thread.Sleep(100);
						}
						catch
						{
							this._curLogger.LogMessage("interface status exception");
						}
						finally
						{
							this._InterfaceUpdateInProgess = false;
						}
					}
				}
				catch
				{
				}
				finally
				{
					if (list != null)
					{
						foreach (MK item4 in list)
						{
							item4.Close();
						}
						list.Clear();
					}
				}
			}
		}

		private void CheckDiagnosticsStatus()
		{
			int num = 0;
			while (true)
			{
				if (this.PerformDiagnostics)
				{
					try
					{
						Dictionary<string, string> dictionary = new Dictionary<string, string>();
						foreach (MK router in this._Routers)
						{
							List<string> list = router.RouteGetTargets();
							foreach (string item in list)
							{
								string text = yrUtils.ExtractInfo(item, "=routing-mark=");
								string text2;
								int num2;
								if (text.StartsWith("108"))
								{
									text2 = yrUtils.ExtractInfo(item, "=comment=");
									if (!text2.StartsWith("10.8"))
									{
										string text3 = text2;
										if (text != "1080")
										{
											string empty = string.Empty;
											num2 = Convert.ToInt16(text[3].ToString());
											if (num2 <= this.mainConfig.VNs.Count)
											{
												if (!this.mainConfig.VNs[num2 - 1].AutoswitchAvailable)
												{
													goto IL_00f8;
												}
												goto IL_00f8;
											}
										}
									}
								}
								continue;
								IL_00f8:
								dictionary.Add(num2.ToString(), text2);
							}
						}
						Dictionary<string, Dictionary<string, string>> dictionary2 = new Dictionary<string, Dictionary<string, string>>();
						foreach (string key in dictionary.Keys)
						{
							string text4 = dictionary[key];
							bool flag = false;
							foreach (string key2 in dictionary2.Keys)
							{
								if (dictionary2[key2]["selectedWanInterfaceName"] == text4)
								{
									dictionary2.Add(key.ToString(), dictionary2[key2]);
									flag = true;
									break;
								}
							}
							if (!flag)
							{
								MK mK = null;
								string[] array = new string[0];
								YachtRouterConfigWANBase yachtRouterConfigWANBase = null;
								foreach (YachtRouterConfigWANBase allWan in this.mainConfig.GetAllWans())
								{
									if (allWan.InterfaceName == text4)
									{
										yachtRouterConfigWANBase = allWan;
										mK = this.GetRouterByRouterID(allWan.RouterID);
										array = allWan.CheckInternetStatusTargetIP.Split('|');
										break;
									}
								}
								if (yachtRouterConfigWANBase.TrafficControlAwailable)
								{
									string wanInterfaceTitle = mK.GetWanInterfaceTitle("bridgeCounter_" + text4 + "_BootRX");
									string wanInterfaceTitle2 = mK.GetWanInterfaceTitle("bridgeCounter_" + text4 + "_RX");
									string wanInterfaceTitle3 = mK.GetWanInterfaceTitle("bridgeCounter_" + text4 + "_BootTX");
									string wanInterfaceTitle4 = mK.GetWanInterfaceTitle("bridgeCounter_" + text4 + "_TX");
									string wanInterfaceTitle5 = mK.GetWanInterfaceTitle("bridgeCounter_" + text4 + "_Limit");
									bool flag2 = mK.CheckIsInterfaceEnabledPhysicalByInterface("bridgeCounter_" + text4 + "_Limit");
									string wanInterfaceTitle6 = mK.GetWanInterfaceTitle("bridgeCounter_" + text4 + "_Warning");
									bool flag3 = mK.CheckIsInterfaceEnabledPhysicalByInterface("bridgeCounter_" + text4 + "_Warning");
									string text5 = (long.Parse(wanInterfaceTitle) + long.Parse(wanInterfaceTitle2)).ToString();
									string text6 = (long.Parse(wanInterfaceTitle3) + long.Parse(wanInterfaceTitle4)).ToString();
									Dictionary<string, string> dictionary3 = new Dictionary<string, string>();
									dictionary3.Add("selectedWanUsage_RX", text5.ToString());
									dictionary3.Add("selectedWanUsage_TX", text6.ToString());
									dictionary3.Add("selectedWanUsageLimit", wanInterfaceTitle5);
									dictionary3.Add("selectedWanUsageLimitEnabled", flag2.ToString());
									dictionary3.Add("selectedWanUsageWarning", wanInterfaceTitle6);
									dictionary3.Add("selectedWanUsageWarningEnabled", flag3.ToString());
									string value = "checking";
									if (num % 30 == 0)
									{
										if (!mK.CheckIsInterfaceEnabledPhysicalByInterface(text4))
										{
											value = "disabled";
										}
										else
										{
											string[] array2 = array;
											foreach (string internetStatusTargetIP in array2)
											{
												if (mK.CheckWanInternetStatus(internetStatusTargetIP))
												{
													value = "connected";
													break;
												}
												value = "nointernet";
											}
										}
										dictionary3.Add("selectedWanInternetAvailable", value);
									}
									dictionary3.Add("selectedWan", mK.GetWanInterfaceTitle(text4));
									dictionary3.Add("selectedWanInterfaceName", text4);
									string[] monitorTrafficRXTXForInterface = mK.GetMonitorTrafficRXTXForInterface(text4, short.Parse(key));
									dictionary3.Add("selectedWanBandwith_RX", monitorTrafficRXTXForInterface[0]);
									dictionary3.Add("selectedWanBandwith_TX", monitorTrafficRXTXForInterface[1]);
									dictionary2.Add(key.ToString(), dictionary3);
								}
							}
						}
						this.FireOnStatusUpdate(RouterStatuses.DiagnosticsVesselNetworkSelectedWanInfo, dictionary2);
						if (num % 30 == 0)
						{
							int num3 = 1;
							Dictionary<string, Dictionary<string, string>> dictionary4 = new Dictionary<string, Dictionary<string, string>>();
							foreach (YachtRouterConfigWifiAP vN in this.mainConfig.VNs)
							{
								Dictionary<string, string> dictionary5 = new Dictionary<string, string>();
								dictionary5.Add("name", vN.Name);
								if (vN.AutoswitchAvailable)
								{
									dictionary5.Add("vesselNetworkAutoswitchEnabled", this.CheckIsEnabledDisableAutoswitcher(num3).ToString());
									dictionary5.Add("vesselNetworkAutoswitchScript", this.GetAutoswitcherSelectedScript(num3));
								}
								else
								{
									dictionary5.Add("vesselNetworkAutoswitchEnabled", "false");
									dictionary5.Add("vesselNetworkAutoswitchScript", "false");
								}
								if (vN.HotspotAvailable)
								{
									dictionary5.Add("vesselNetworkHotspotEnabled", this.GetIsHotspotEnabledDisabled("VN" + num3).ToString());
									int[] hotspotUsersActiveAndRegistered = this.GetHotspotUsersActiveAndRegistered("VN" + num3);
									dictionary5.Add("vesselNetworkHotspotUsersActive", hotspotUsersActiveAndRegistered[0].ToString());
									dictionary5.Add("vesselNetworkHotspotUsersRegistered", hotspotUsersActiveAndRegistered[1].ToString());
								}
								else
								{
									dictionary5.Add("vesselNetworkHotspotEnabled", "false");
									dictionary5.Add("vesselNetworkHotspotUsersActive", "0");
									dictionary5.Add("vesselNetworkHotspotUsersRegistered", "0");
								}
								dictionary5.Add("vesselNetworkWifiEnabled", vN.WiFiEnabled.ToString());
								dictionary5.Add("vesselNetworkWifiUsers", this.GetNumberOfRegisteredWIFIUsers(num3).ToString());
								Dictionary<string, string> vesselNetworkBandwithControlStatus = this.GetVesselNetworkBandwithControlStatus(num3);
								dictionary5.Add("vesselNetworkBandwithControlLimitEnabled", vesselNetworkBandwithControlStatus["vesselNetworkBandwithControlLimitEnabled"]);
								dictionary5.Add("vesselNetworkBandwithControlLimit_RX", vesselNetworkBandwithControlStatus["vesselNetworkBandwithControlLimit_RX"]);
								dictionary5.Add("vesselNetworkBandwithControlLimit_TX", vesselNetworkBandwithControlStatus["vesselNetworkBandwithControlLimit_TX"]);
								dictionary4.Add(num3.ToString(), dictionary5);
								num3++;
							}
							this.FireOnStatusUpdate(RouterStatuses.DiagnosticsVesselNetworkInfo, dictionary4);
						}
						if (num == 0)
						{
							this.FireOnStatusUpdate(RouterStatuses.DiagnosticsStarted, new List<string>());
						}
					}
					catch (Exception ex)
					{
						this._curLogger.LogException(ex);
					}
					num++;
				}
				else
				{
					num = 0;
				}
				Thread.Sleep(1000);
				if (num > 1000)
				{
					num = 0;
				}
			}
		}

		private void SetWanInternetStatus(string comment, string internetStatus)
		{
			foreach (YachtRouterConfigWANBase allWan in this.mainConfig.GetAllWans())
			{
				if (comment == allWan.InterfaceName)
				{
					allWan.Connection = internetStatus;
					break;
				}
			}
		}

		private void CheckInterfaceStatuses()
		{
			while (true)
			{
				try
				{
					while (true)
					{
						try
						{
							while (!this.SuspendUpdates && this.CheckRouterConnectionsAreActive())
							{
								this._InterfaceUpdateInProgess = true;
								for (int i = 0; i < this._mainConfig.LanWANs.Count; i++)
								{
									YachtRouterConfigWANLan yachtRouterConfigWANLan = this._mainConfig.LanWANs[i];
									MK routerByRouterID = this.GetRouterByRouterID(yachtRouterConfigWANLan.RouterID);
									yachtRouterConfigWANLan.IsEnabled = routerByRouterID.CheckIsInterfaceEnabled(yachtRouterConfigWANLan);
									if (this.GetYachtRouterActiveWANLan() == i.ToString())
									{
										this.FireOnStatusUpdate(RouterStatuses.WanSatEnabled, yachtRouterConfigWANLan.IsEnabled);
										this.FireOnStatusUpdate(RouterStatuses.WanSatTitle, routerByRouterID.GetWanInterfaceTitle(yachtRouterConfigWANLan.InterfaceName));
										this.CheckInterfaceAccessStatuses(routerByRouterID, yachtRouterConfigWANLan);
									}
									if (this.LateConfigurationLoadFinished)
									{
										routerByRouterID.UpdateRoutesToDHCPClientData(yachtRouterConfigWANLan);
									}
								}
								if (this.SuspendUpdates)
								{
									continue;
								}
								for (int j = 0; j < this._mainConfig.WifiWANs.Count; j++)
								{
									YachtRouterConfigWANWifi yachtRouterConfigWANWifi = this._mainConfig.WifiWANs[j];
									MK routerByRouterID2 = this.GetRouterByRouterID(yachtRouterConfigWANWifi.RouterID);
									yachtRouterConfigWANWifi.IsEnabled = routerByRouterID2.CheckIsInterfaceEnabled(yachtRouterConfigWANWifi);
									if (this.GetYachtRouterActiveWANWifi() == j.ToString())
									{
										this.FireOnStatusUpdate(RouterStatuses.WanWifiEnabled, yachtRouterConfigWANWifi.IsEnabled);
										if (yachtRouterConfigWANWifi.IsEnabled)
										{
											List<string> list = routerByRouterID2.CheckWanWiFiInfo(yachtRouterConfigWANWifi.InterfaceName);
											foreach (string item in list)
											{
												this.FireOnStatusUpdate(RouterStatuses.WanWiFiAP, yrUtils.ExtractInfo(item, "ssid="));
												this.FireOnStatusUpdate(RouterStatuses.WanWiFiSignalStrength, yrUtils.ExtractInfo(item, "signal-strength="));
												this.FireOnStatusUpdate(RouterStatuses.WanWifiConnectedStatus, yrUtils.ExtractInfo(item, "status="));
											}
											this.CheckInterfaceAccessStatuses(routerByRouterID2, yachtRouterConfigWANWifi);
										}
									}
									if (this.LateConfigurationLoadFinished)
									{
										routerByRouterID2.UpdateRoutesToDHCPClientData(yachtRouterConfigWANWifi);
									}
								}
								if (this.SuspendUpdates)
								{
									continue;
								}
								for (int k = 0; k < this._mainConfig.MobileWANs.Count; k++)
								{
									YachtRouterConfigWANMobile yachtRouterConfigWANMobile = this._mainConfig.MobileWANs[k];
									MK routerByRouterID3 = this.GetRouterByRouterID(yachtRouterConfigWANMobile.RouterID);
									yachtRouterConfigWANMobile.IsEnabled = routerByRouterID3.CheckIsInterfaceEnabled(yachtRouterConfigWANMobile);
									if (this.GetYachtRouterActiveWANMobile() == k.ToString())
									{
										this.FireOnStatusUpdate(RouterStatuses.WanMobileEnabled, yachtRouterConfigWANMobile.IsEnabled);
										if (yachtRouterConfigWANMobile.IsEnabled)
										{
											List<string> list2 = routerByRouterID3.CheckWanMobileInfo(yachtRouterConfigWANMobile.InterfaceName);
											foreach (string item2 in list2)
											{
												string text = yrUtils.ExtractInfo(item2, "current-operator=");
												string newValue = yrUtils.ExtractInfo(item2, "signal-strengh=");
												string newValue2 = yrUtils.ExtractInfo(item2, "access-technology=");
												if (text != string.Empty)
												{
													this.FireOnStatusUpdate(RouterStatuses.MobileNetworkOperator, text);
													this.FireOnStatusUpdate(RouterStatuses.MobileNetworkType, newValue2);
													this.FireOnStatusUpdate(RouterStatuses.MobileNetworkSignalStrength, newValue);
													break;
												}
											}
											this.CheckInterfaceAccessStatuses(routerByRouterID3, yachtRouterConfigWANMobile);
										}
									}
								}
								if (this.SuspendUpdates)
								{
									continue;
								}
								for (int l = 0; l < this._mainConfig.LANs.Count; l++)
								{
									YachtRouterConfigLAN yachtRouterConfigLAN = this._mainConfig.LANs[l];
									yachtRouterConfigLAN.IsEnabled = this.GetRouterByRouterID(yachtRouterConfigLAN.RouterID).CheckIsInterfaceEnabled(yachtRouterConfigLAN);
									if (l == 0)
									{
										this.FireOnStatusUpdate(RouterStatuses.LanEnabled, yachtRouterConfigLAN.IsEnabled);
									}
								}
								if (this.SuspendUpdates)
								{
									continue;
								}
								for (int m = 0; m < this._mainConfig.WifiAPs.Count; m++)
								{
									YachtRouterConfigWifiAP yachtRouterConfigWifiAP = this._mainConfig.WifiAPs[m];
									MK routerByRouterID4 = this.GetRouterByRouterID(yachtRouterConfigWifiAP.RouterID);
									yachtRouterConfigWifiAP.IsEnabled = routerByRouterID4.CheckIsInterfaceEnabled(yachtRouterConfigWifiAP);
									switch (m)
									{
									case 0:
										this.FireOnStatusUpdate(RouterStatuses.ShipWifi1Enabled, yachtRouterConfigWifiAP.IsEnabled);
										this.FireOnStatusUpdate(RouterStatuses.ShipWiFiAP_1, routerByRouterID4.CheckShipWiFiInfo(yachtRouterConfigWifiAP.InterfaceName));
										break;
									case 1:
										this.FireOnStatusUpdate(RouterStatuses.ShipWifi2Enabled, yachtRouterConfigWifiAP.IsEnabled);
										this.FireOnStatusUpdate(RouterStatuses.ShipWiFiAP_2, routerByRouterID4.CheckShipWiFiInfo(yachtRouterConfigWifiAP.InterfaceName));
										break;
									}
								}
								break;
							}
							Thread.Sleep(2000);
						}
						catch
						{
							this._curLogger.LogMessage("interface status exception");
						}
						finally
						{
							this._InterfaceUpdateInProgess = false;
						}
					}
				}
				catch
				{
				}
			}
		}

		private void CheckInterfaceAccessStatuses(MK router, YachtRouterConfigWANBase curWan)
		{
			if (curWan.IsEnabled)
			{
				router.GetWanInterfaceAccessRules(curWan);
				this.FireOnStatusUpdate(RouterStatuses.LanRestricted, curWan.RestrictExitToLAN);
				this.FireOnStatusUpdate(RouterStatuses.ShipWifi1Restricted, curWan.RestrictExitToShipWIFI1);
				this.FireOnStatusUpdate(RouterStatuses.ShipWifi2Restricted, curWan.RestrictExitToShipWIFI2);
			}
		}

		private void CheckInternetStatus()
		{
			while (true)
			{
				try
				{
					while (true)
					{
						Thread.Sleep(5000);
						try
						{
							if (!this.CheckRouterConnectionsAreActive())
							{
								this.FireOnStatusUpdate(RouterStatuses.RouterMissing, true);
							}
						}
						catch
						{
						}
					}
				}
				catch
				{
				}
			}
		}

		private bool TestInternetConnection()
		{
			try
			{
				TcpClient tcpClient = new TcpClient("www.google.com", 80);
				tcpClient.Close();
				return true;
			}
			catch
			{
			}
			return false;
		}

		private void _RouterEngine_OnRouterStatusUpdate(string RouterID, RouterStatuses ChangedStatus)
		{
			this.FireOnStatusUpdate(ChangedStatus, null);
		}

		private void _RouterEngine_OnRouterNewInfo(string routerID, string newInfo)
		{
			this.FireNewInfo(newInfo, false, 0);
		}

		private void FireNewInfo(string newInfo, bool ShowOnScreen = false, int SleepTimeinSec = 0)
		{
			if (this.OnNewInfo != null)
			{
				this.OnNewInfo(newInfo, ShowOnScreen);
				if (SleepTimeinSec > 0)
				{
					Thread.Sleep(SleepTimeinSec * 1000);
				}
			}
		}

		internal void FireOnStatusUpdate(RouterStatuses ChangedStatus, object newValue)
		{
			if (this.OnStatusUpdate != null)
			{
				this.OnStatusUpdate(ChangedStatus, newValue);
			}
		}

		private void SetAllRoutesToRouterID(string TargetRouterID)
		{
			try
			{
				for (int i = 0; i < this._Routers.Count; i++)
				{
					MK mK = this._Routers[i];
					mK.EnableRouteToRouterIDDisableOtherRoutes("routeOnRouterID", TargetRouterID);
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void EnabledDisableWan(string wanInterfaceName, bool newState)
		{
			try
			{
				foreach (YachtRouterConfigWANBase allWan in this.mainConfig.GetAllWans())
				{
					if (allWan.InterfaceName == wanInterfaceName)
					{
						this.GetRouterByRouterID(allWan.RouterID).EnableDisableInterfacePhysical(wanInterfaceName, newState);
						break;
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void EnabledDisableWanMobile(bool newState)
		{
			this.SuspendUpdates = true;
			try
			{
				this._EnabledDisableWanMobile(newState);
				this._EnabledDisableWanSat(false);
				this._EnabledDisableWanWifi(false);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			this.SuspendUpdates = false;
		}

		public void _EnabledDisableWanMobile(bool newState)
		{
			this.UpdateWanMobileConfigurationForAllWans();
			for (int i = 0; i < this._mainConfig.MobileWANs.Count; i++)
			{
				YachtRouterConfigWANMobile yachtRouterConfigWANMobile = this._mainConfig.MobileWANs[i];
				MK routerByRouterID = this.GetRouterByRouterID(yachtRouterConfigWANMobile.RouterID);
				if (i.ToString() != this.GetYachtRouterActiveWANMobile())
				{
					routerByRouterID.EnableDisableInterface(yachtRouterConfigWANMobile, false);
				}
				else
				{
					if (newState)
					{
						RouterStatuses routerStatuses = routerByRouterID.CheckAndResolveModemPin();
						this.FireOnStatusUpdate(routerStatuses, string.Empty);
						if (routerStatuses != RouterStatuses.MobilePinOk)
						{
							break;
						}
					}
					routerByRouterID.EnableDisableInterface(yachtRouterConfigWANMobile, newState);
					if (newState)
					{
						this.SetAllRoutesToRouterID(routerByRouterID.RouterID);
					}
				}
			}
		}

		public void EnabledDisableWanSat(bool newState)
		{
			this.SuspendUpdates = true;
			try
			{
				this._EnabledDisableWanSat(newState);
				this._EnabledDisableWanWifi(false);
				this._EnabledDisableWanMobile(false);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			this.SuspendUpdates = false;
		}

		public void _EnabledDisableWanSat(bool newState)
		{
			this.UpdateWanSatConfigurationForAllWans();
			for (int i = 0; i < this._mainConfig.LanWANs.Count; i++)
			{
				YachtRouterConfigWANLan yachtRouterConfigWANLan = this._mainConfig.LanWANs[i];
				MK routerByRouterID = this.GetRouterByRouterID(yachtRouterConfigWANLan.RouterID);
				this.EnableDisableWAN(newState, i, this.GetYachtRouterActiveWANLan(), yachtRouterConfigWANLan, routerByRouterID);
			}
		}

		public void EnabledDisableWanWifi(bool newState)
		{
			this.SuspendUpdates = true;
			try
			{
				this._EnabledDisableWanWifi(newState);
				this._EnabledDisableWanSat(false);
				this._EnabledDisableWanMobile(false);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			this.SuspendUpdates = false;
		}

		public void _EnabledDisableWanWifi(bool newState)
		{
			this.UpdateWanWifiConfigurationForAllWans();
			for (int i = 0; i < this._mainConfig.WifiWANs.Count; i++)
			{
				YachtRouterConfigWANWifi yachtRouterConfigWANWifi = this._mainConfig.WifiWANs[i];
				MK routerByRouterID = this.GetRouterByRouterID(yachtRouterConfigWANWifi.RouterID);
				this.EnableDisableWAN(newState, i, this.GetYachtRouterActiveWANWifi(), yachtRouterConfigWANWifi, routerByRouterID);
			}
		}

		private void EnableDisableWAN(bool newState, int i, string SelectedWanID, YachtRouterConfigWANLan curWan, MK router)
		{
			try
			{
				if (i.ToString() != SelectedWanID)
				{
					router.EnableDisableInterface(curWan, false);
					router.EnableDisableRoute(curWan.InterfaceName, false);
				}
				else
				{
					router.EnableDisableInterface(curWan, newState);
					router.EnableDisableRoute(curWan.InterfaceName, newState);
					if (newState)
					{
						this.SetAllRoutesToRouterID(router.RouterID);
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void EnabledDisableVNWifi(int VesselNetwork, bool newState)
		{
			this.SuspendUpdates = true;
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(this._mainConfig.VNs[VesselNetwork - 1].RouterID);
				routerByRouterID.EnableDisableInterface(this._mainConfig.VNs[VesselNetwork - 1], newState);
				this.ConfigureWifiApOnExtenders(this._mainConfig.VNs[VesselNetwork - 1].InterfaceName, yrEngine.virtualApSecurityProfilePrefix + this._mainConfig.VNs[VesselNetwork - 1].InterfaceName, newState, this._mainConfig.VNs[VesselNetwork - 1].WiFiAPN, this._mainConfig.VNs[VesselNetwork - 1].WiFiSecurityPassword, false, false);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			this.SuspendUpdates = false;
		}

		public void EnabledDisableWifi1(bool newState)
		{
			this.SuspendUpdates = true;
			try
			{
				for (int i = 0; i < this._mainConfig.WifiAPs.Count; i++)
				{
					YachtRouterConfigWifiAP yachtRouterConfigWifiAP = this._mainConfig.WifiAPs[i];
					if (yachtRouterConfigWifiAP.WiFiNumber == 0)
					{
						MK routerByRouterID = this.GetRouterByRouterID(yachtRouterConfigWifiAP.RouterID);
						routerByRouterID.EnableDisableInterface(yachtRouterConfigWifiAP, newState);
						this.ConfigureWifiApOnExtenders(yachtRouterConfigWifiAP.InterfaceName, yrEngine.virtualApSecurityProfilePrefix + yachtRouterConfigWifiAP.InterfaceName, newState, yachtRouterConfigWifiAP.WiFiAPN, yachtRouterConfigWifiAP.WiFiSecurityPassword, false, false);
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			this.SuspendUpdates = false;
		}

		public void EnabledDisableWifi2(bool newState)
		{
			this.SuspendUpdates = true;
			try
			{
				for (int i = 0; i < this._mainConfig.WifiAPs.Count; i++)
				{
					YachtRouterConfigWifiAP yachtRouterConfigWifiAP = this._mainConfig.WifiAPs[i];
					if (yachtRouterConfigWifiAP.WiFiNumber == 1)
					{
						MK routerByRouterID = this.GetRouterByRouterID(yachtRouterConfigWifiAP.RouterID);
						routerByRouterID.EnableDisableInterface(yachtRouterConfigWifiAP, newState);
						this.ConfigureWifiApOnExtenders(yachtRouterConfigWifiAP.InterfaceName, yrEngine.virtualApSecurityProfilePrefix + yachtRouterConfigWifiAP.InterfaceName, newState, yachtRouterConfigWifiAP.WiFiAPN, yachtRouterConfigWifiAP.WiFiSecurityPassword, false, false);
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			this.SuspendUpdates = false;
		}

		public void EnabledDisableLan(bool newState)
		{
			this.SuspendUpdates = true;
			try
			{
				for (int i = 0; i < this._mainConfig.LANs.Count; i++)
				{
					YachtRouterConfigLAN yachtRouterConfigLAN = this._mainConfig.LANs[i];
					foreach (MK router in this._Routers)
					{
						router.EnableDisablFirewallRule(yachtRouterConfigLAN.FirewallRule, newState);
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			this.SuspendUpdates = false;
		}

		public void EnabledDisableAutoswitcher(int VesselNetwork, bool newState)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(this._mainConfig.VNs[VesselNetwork - 1].RouterID);
				routerByRouterID.EnableDisableInterfacePhysical("Autoswitch_VN" + VesselNetwork, newState);
				foreach (MK router in this._Routers)
				{
					router.EnableDisableSchedulers("scheduleCheckSemaphore108" + VesselNetwork, newState.ToString());
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void EnableDisableSchedulers(string RouterID, string SchedulerName, string newState)
		{
			this.SuspendUpdates = true;
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(RouterID);
				routerByRouterID.EnableDisableSchedulers(SchedulerName, newState);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			this.SuspendUpdates = false;
		}

		public void UpdateVNConfiguration()
		{
			MK routerByRouterID = this.GetRouterByRouterID("Main");
			for (int i = 0; i < this._mainConfig.VNs.Count; i++)
			{
				YachtRouterConfigWifiAP yachtRouterConfigWifiAP = this._mainConfig.VNs[i];
				MK routerByRouterID2 = this.GetRouterByRouterID(yachtRouterConfigWifiAP.RouterID);
				this._mainConfig.VNs[i] = routerByRouterID2.GetShipWifiConfiguration(yachtRouterConfigWifiAP.InterfaceName, yachtRouterConfigWifiAP);
				this._mainConfig.VNs[i].WiFiEnabled = routerByRouterID2.CheckIsInterfaceEnabled(yachtRouterConfigWifiAP);
				this._mainConfig.VNs[i].Name = routerByRouterID2.GetWanInterfaceTitle("bridgeVN" + (i + 1));
				if (this._mainConfig.VNs[i].AutoswitchAvailable)
				{
					this._mainConfig.VNs[i].AutoswitchEnabled = routerByRouterID.CheckIsInterfaceEnabledPhysicalByInterface("Autoswitch_VN" + (i + 1));
					this._mainConfig.VNs[i].AutoswitchScript = routerByRouterID.GetWanInterfaceTitle("Autoswitch_VN" + (i + 1));
				}
			}
		}

		public void UpdateWifiApConfiguration()
		{
			for (int i = 0; i < this._mainConfig.WifiAPs.Count; i++)
			{
				YachtRouterConfigWifiAP yachtRouterConfigWifiAP = this._mainConfig.WifiAPs[i];
				MK routerByRouterID = this.GetRouterByRouterID(yachtRouterConfigWifiAP.RouterID);
				this._mainConfig.WifiAPs[i] = routerByRouterID.GetShipWifiConfiguration(yachtRouterConfigWifiAP.InterfaceName, yachtRouterConfigWifiAP);
			}
		}

		public void SetWifiApConfiguration(int ShipWifiID, YachtRouterConfigWifiAP config, bool ChangeSSID, bool ChangePassowrd)
		{
			for (int i = 0; i < this._mainConfig.WifiAPs.Count; i++)
			{
				YachtRouterConfigWifiAP yachtRouterConfigWifiAP = this._mainConfig.WifiAPs[i];
				if (yachtRouterConfigWifiAP.WiFiNumber == ShipWifiID && yachtRouterConfigWifiAP.IsConfigurable)
				{
					MK routerByRouterID = this.GetRouterByRouterID(yachtRouterConfigWifiAP.RouterID);
					routerByRouterID.SetWanInterfaceTitle("bridgeVN" + (ShipWifiID + 1), config.Name);
					routerByRouterID.SetShipWifiConfiguration(yachtRouterConfigWifiAP.InterfaceName, config, ChangeSSID, ChangePassowrd);
					this.ConfigureWifiApOnExtenders(yachtRouterConfigWifiAP.InterfaceName, yrEngine.virtualApSecurityProfilePrefix + yachtRouterConfigWifiAP.InterfaceName, yachtRouterConfigWifiAP.WiFiEnabled, config.WiFiAPN, config.WiFiSecurityPassword, ChangeSSID, ChangePassowrd);
				}
			}
		}

		public YachtRouterConfigWifiAP GetShipWifiConfiguration(int ShipWifiID)
		{
			try
			{
				return this._mainConfig.WifiAPs[ShipWifiID];
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return new YachtRouterConfigWifiAP();
		}

		public List<string[]> GetAllDhcpClients(int VesselNetwork)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(this.mainConfig.VNs[VesselNetwork - 1].RouterID);
				return routerByRouterID.GetDhcpLeases("dhcpVN" + VesselNetwork);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return new List<string[]>();
		}

		public void DhcpClientRenew(string interfaceName)
		{
			try
			{
				foreach (YachtRouterConfigWANBase allWan in this.mainConfig.GetAllWans())
				{
					if (allWan.InterfaceName == interfaceName)
					{
						this.GetRouterByRouterID(allWan.RouterID).RenewDHCPClient(interfaceName);
						break;
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void DhcpLeaseMakeStatic(string ip)
		{
			try
			{
				this.GetRouterByRouterID(this.mainConfig.VNs[0].RouterID).DhcpLeaseMakeStatic(ip);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void DhcpLeaseDelete(string ip)
		{
			try
			{
				this.GetRouterByRouterID(this.mainConfig.VNs[0].RouterID).DhcpLeaseDelete(ip);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public Dictionary<string, List<string>> GetRegisteredWIFIUsers()
		{
			Dictionary<string, List<string>> dictionary = new Dictionary<string, List<string>>();
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(this._mainConfig.WifiAPs[0].RouterID);
				List<string> dhcpLeasesAndFixThem = routerByRouterID.GetDhcpLeasesAndFixThem(yrEngine.rootExtenderDHCPServer, yrEngine.extenderIdentity);
				int num = dhcpLeasesAndFixThem.Count;
				if (num > this.mainConfig.MaxNumberOfWifiExteders)
				{
					num = this.mainConfig.MaxNumberOfWifiExteders;
				}
				List<string> dhcpLeases = routerByRouterID.GetDhcpLeases();
				List<string> registeredWIFIUsers = routerByRouterID.GetRegisteredWIFIUsers(dhcpLeases);
				dictionary.Add("Yacht Router  - " + routerByRouterID.GetWIFIInfo("shipPhysical") + " Clients: " + registeredWIFIUsers.Count, registeredWIFIUsers);
				for (int i = 0; i < num; i++)
				{
					try
					{
						MK mK = new MK("Extender_" + dhcpLeasesAndFixThem[i], dhcpLeasesAndFixThem[i], this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
						mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
						registeredWIFIUsers = mK.GetRegisteredWIFIUsers(dhcpLeases);
						dictionary.Add(mK.GetIdentity().Replace("YR_WIFI_EXTENDER_", "WIFI Extender ") + " - " + mK.GetWIFIInfo("shipPhysical") + " Clients: " + registeredWIFIUsers.Count, registeredWIFIUsers);
					}
					catch (Exception ex)
					{
						this._curLogger.LogException(ex);
					}
				}
				return dictionary;
			}
			catch (Exception ex2)
			{
				this._curLogger.LogException(ex2);
				return dictionary;
			}
		}

		public int GetNumberOfRegisteredWIFIUsers(int VNID)
		{
			int num = 0;
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(this._mainConfig.WifiAPs[0].RouterID);
				List<string> dhcpLeasesAndFixThem = routerByRouterID.GetDhcpLeasesAndFixThem(yrEngine.rootExtenderDHCPServer, yrEngine.extenderIdentity);
				int num2 = dhcpLeasesAndFixThem.Count;
				if (num2 > this.mainConfig.MaxNumberOfWifiExteders)
				{
					num2 = this.mainConfig.MaxNumberOfWifiExteders;
				}
				List<string> dhcpLeases = routerByRouterID.GetDhcpLeases();
				List<string> registeredWIFIUsers = routerByRouterID.GetRegisteredWIFIUsers(dhcpLeases);
				foreach (string item in registeredWIFIUsers)
				{
					if (item.Contains("VN" + VNID.ToString()))
					{
						num++;
					}
				}
				for (int i = 0; i < num2; i++)
				{
					try
					{
						MK mK = new MK("Extender_" + dhcpLeasesAndFixThem[i], dhcpLeasesAndFixThem[i], this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
						mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
						registeredWIFIUsers = mK.GetRegisteredWIFIUsers(dhcpLeases);
						foreach (string item2 in registeredWIFIUsers)
						{
							if (item2.Contains("VN" + VNID.ToString()))
							{
								num++;
							}
						}
					}
					catch (Exception ex)
					{
						this._curLogger.LogException(ex);
					}
				}
				return num;
			}
			catch (Exception ex2)
			{
				this._curLogger.LogException(ex2);
				return num;
			}
		}

		public Dictionary<string, string> GetVesselNetworkBandwithControlStatus(int VesselNetwork)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				bool isQueueEnabledDisabled = routerByRouterID.GetIsQueueEnabledDisabled("queue108" + VesselNetwork + "dst");
				bool isQueueEnabledDisabled2 = routerByRouterID.GetIsQueueEnabledDisabled("queue108" + VesselNetwork + "src");
				int num = Convert.ToInt32(routerByRouterID.GetQueueTypePCQRate("pcq108" + VesselNetwork + "dst")) / 1000;
				int num2 = Convert.ToInt32(routerByRouterID.GetQueueTypePCQRate("pcq108" + VesselNetwork + "src")) / 1000;
				dictionary.Add("vesselNetworkBandwithControlLimitEnabled", isQueueEnabledDisabled.ToString());
				dictionary.Add("vesselNetworkBandwithControlLimit_TX_Enabled", isQueueEnabledDisabled.ToString());
				dictionary.Add("vesselNetworkBandwithControlLimit_TX", num.ToString());
				dictionary.Add("vesselNetworkBandwithControlLimit_RX_Enabled", isQueueEnabledDisabled2.ToString());
				dictionary.Add("vesselNetworkBandwithControlLimit_RX", num2.ToString());
				return dictionary;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return dictionary;
			}
		}

		public void SetVesselNetworkBandwithControlEnabledStatus(int VesselNetwork, string direction, bool newStatus)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				if (direction == "tx")
				{
					routerByRouterID.SetIsQueueEnabledDisabled("queue108" + VesselNetwork + "dst", newStatus);
				}
				if (direction == "rx")
				{
					routerByRouterID.SetIsQueueEnabledDisabled("queue108" + VesselNetwork + "src", newStatus);
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void SetVesselNetworkBandwithControlLimits(int VesselNetwork, int TXLimit, int RXLimit)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				routerByRouterID.SetQueueTypePCQRate("pcq108" + VesselNetwork + "dst", TXLimit);
				routerByRouterID.SetQueueTypePCQRate("pcq108" + VesselNetwork + "src", RXLimit);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void SetIsolationState(string VesselNetwork, bool newStatus)
		{
			try
			{
				foreach (MK router in this._Routers)
				{
					router.EnableDisablFirewallRule("Client Isolation VN" + VesselNetwork, !newStatus);
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public bool GetIsolationState(int VesselNetworkID)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				return !routerByRouterID.CheckFirewallFilterRuleStatus("Client Isolation VN" + VesselNetworkID);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return false;
		}

		public void UpdateWanSatConfiguration(YachtRouterConfigWANLan curWan)
		{
			if (curWan.InterfaceName == string.Empty)
			{
				this._curLogger.LogMessage("INTERFACE DESTROYED!!!!");
				this._mainConfig.LoadConfiguration(this._workingInDeviceMode);
			}
			MK routerByRouterID = this.GetRouterByRouterID(curWan.RouterID);
			curWan = routerByRouterID.GetWanLanConfiguration(curWan.Name, curWan);
		}

		public void UpdateWanSatConfigurationForAllWans()
		{
			for (int i = 0; i < this._mainConfig.LanWANs.Count; i++)
			{
				YachtRouterConfigWANLan yachtRouterConfigWANLan = this._mainConfig.LanWANs[i];
				if (yachtRouterConfigWANLan.InterfaceName == string.Empty)
				{
					this._curLogger.LogMessage("INTERFACE DESTROYED!!!!");
					this._mainConfig.LoadConfiguration(this._workingInDeviceMode);
				}
				MK routerByRouterID = this.GetRouterByRouterID(yachtRouterConfigWANLan.RouterID);
				this._mainConfig.LanWANs[i] = routerByRouterID.GetWanLanConfiguration(yachtRouterConfigWANLan.Name, yachtRouterConfigWANLan);
			}
		}

		public bool IfConfigurable_WanSatConfiguration()
		{
			string yachtRouterActiveWANLan = this.GetYachtRouterActiveWANLan();
			int num = 0;
			goto IL_005d;
			IL_005d:
			if (num < this.WanSatConfiguration.Count)
			{
				YachtRouterConfigWANLan yachtRouterConfigWANLan = this.WanSatConfiguration[num];
				if (yachtRouterConfigWANLan.InterfaceName == string.Empty)
				{
					this._curLogger.LogMessage("INTERFACE DESTROYED!!!!");
					this._mainConfig.LoadConfiguration(this._workingInDeviceMode);
				}
				return yachtRouterConfigWANLan.IsConfigurable;
			}
			return false;
			IL_0059:
			num++;
			goto IL_005d;
		}

		public void SetWanSatConfiguration(string InterfaceName, YachtRouterConfigWANLan config)
		{
			int num = 0;
			while (true)
			{
				if (num < this._mainConfig.LanWANs.Count)
				{
					if (!(this._mainConfig.LanWANs[num].InterfaceName == InterfaceName))
					{
						num++;
						continue;
					}
					break;
				}
				return;
			}
			if (this._mainConfig.LanWANs[num].IsConfigurable)
			{
				MK routerByRouterID = this.GetRouterByRouterID(this._mainConfig.LanWANs[num].RouterID);
				routerByRouterID.SetWanLanConfiguration(this._mainConfig.LanWANs[num].InterfaceName, config);
				this.ConfigureAlwaysOnNetwork(config);
			}
		}

		public void UpdateRoutesToDHCPClientData(YachtRouterConfigWANBase curWan)
		{
			MK routerByRouterID = this.GetRouterByRouterID(curWan.RouterID);
			routerByRouterID.UpdateRoutesToDHCPClientData(curWan);
		}

		public void UpdateWanMobileConfiguration(YachtRouterConfigWANMobile curWan)
		{
			if (curWan.InterfaceName == string.Empty)
			{
				this._curLogger.LogMessage("INTERFACE DESTROYED!!!!");
				this._mainConfig.LoadConfiguration(this._workingInDeviceMode);
			}
			MK routerByRouterID = this.GetRouterByRouterID(curWan.RouterID);
			curWan = routerByRouterID.GetWanMobileConfiguration(curWan.InterfaceName, curWan);
			if (!curWan.BondedInterface && curWan.DirectIP)
			{
				curWan = routerByRouterID.GetWanIpConfiguration(curWan.InterfaceName, curWan);
			}
		}

		public void UpdateWanMobileConfigurationForAllWans()
		{
			for (int i = 0; i < this._mainConfig.MobileWANs.Count; i++)
			{
				YachtRouterConfigWANMobile yachtRouterConfigWANMobile = this._mainConfig.MobileWANs[i];
				if (yachtRouterConfigWANMobile.InterfaceName == string.Empty)
				{
					this._curLogger.LogMessage("INTERFACE DESTROYED!!!!");
					this._mainConfig.LoadConfiguration(this._workingInDeviceMode);
				}
				MK routerByRouterID = this.GetRouterByRouterID(yachtRouterConfigWANMobile.RouterID);
				this._mainConfig.MobileWANs[i] = routerByRouterID.GetWanMobileConfiguration(yachtRouterConfigWANMobile.InterfaceName, yachtRouterConfigWANMobile);
				if (!this._mainConfig.MobileWANs[i].BondedInterface && this._mainConfig.MobileWANs[i].DirectIP)
				{
					this._mainConfig.MobileWANs[i] = routerByRouterID.GetWanIpConfiguration(yachtRouterConfigWANMobile.InterfaceName, yachtRouterConfigWANMobile);
				}
			}
		}

		public bool IfConfigurable_WanMobileConfiguration()
		{
			string yachtRouterActiveWANMobile = this.GetYachtRouterActiveWANMobile();
			int num = 0;
			goto IL_005d;
			IL_005d:
			if (num < this.WanMobileConfiguration.Count)
			{
				YachtRouterConfigWANMobile yachtRouterConfigWANMobile = this.WanMobileConfiguration[num];
				if (yachtRouterConfigWANMobile.InterfaceName == string.Empty)
				{
					this._curLogger.LogMessage("INTERFACE DESTROYED!!!!");
					this._mainConfig.LoadConfiguration(this._workingInDeviceMode);
				}
				return yachtRouterConfigWANMobile.IsConfigurable;
			}
			return false;
			IL_0059:
			num++;
			goto IL_005d;
		}

		public void SetWanMobileConfiguration(string InterfaceName, YachtRouterConfigWANMobile config, bool IsRecycleNeeded)
		{
			int num = 0;
			while (true)
			{
				if (num < this._mainConfig.MobileWANs.Count)
				{
					if (!(this._mainConfig.MobileWANs[num].InterfaceName == InterfaceName))
					{
						num++;
						continue;
					}
					break;
				}
				return;
			}
			if (this._mainConfig.MobileWANs[num].IsConfigurable)
			{
				MK routerByRouterID = this.GetRouterByRouterID(this._mainConfig.MobileWANs[num].RouterID);
				routerByRouterID.SetWanMobileConfiguration(this._mainConfig.MobileWANs[num].InterfaceName, config, IsRecycleNeeded);
			}
		}

		public string CheckEnabledDisabledScheduler(string RouterID, string SchedulerName)
		{
			MK routerByRouterID = this.GetRouterByRouterID(RouterID);
			return routerByRouterID.CheckEnabledDisabledScheduler(SchedulerName);
		}

		public void SetIpAndDhcp(string Interface, string ip, string subnet, string gateway, string dns1, string dns2, bool UseDhcpClient)
		{
			foreach (YachtRouterConfigWANBase allWan in this.mainConfig.GetAllWans())
			{
				if (allWan.InterfaceName == Interface)
				{
					this.GetRouterByRouterID(allWan.RouterID).SetIpAndDhcp(Interface, ip, subnet, gateway, dns1, dns2, UseDhcpClient);
					break;
				}
			}
		}

		public void UpdateWanWifiConfiguration(YachtRouterConfigWANWifi curWan)
		{
			if (curWan.InterfaceName == string.Empty)
			{
				this._curLogger.LogMessage("INTERFACE DESTROYED!!!!");
				this._mainConfig.LoadConfiguration(this._workingInDeviceMode);
			}
			MK routerByRouterID = this.GetRouterByRouterID(curWan.RouterID);
			curWan = routerByRouterID.GetWanWifiConfiguration(curWan.InterfaceName, curWan);
		}

		public void SetInterfaceBand(string RouterID, string InterfaceName, string Band)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(RouterID);
				routerByRouterID.SetInterfaceBand(InterfaceName, Band);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void UpdateWanWifiConfigurationForAllWans()
		{
			for (int i = 0; i < this._mainConfig.WifiWANs.Count; i++)
			{
				YachtRouterConfigWANWifi yachtRouterConfigWANWifi = this._mainConfig.WifiWANs[i];
				if (yachtRouterConfigWANWifi.InterfaceName == string.Empty)
				{
					this._curLogger.LogMessage("INTERFACE DESTROYED!!!!");
					this._mainConfig.LoadConfiguration(this._workingInDeviceMode);
				}
				MK routerByRouterID = this.GetRouterByRouterID(yachtRouterConfigWANWifi.RouterID);
				this._mainConfig.WifiWANs[i] = routerByRouterID.GetWanWifiConfiguration(yachtRouterConfigWANWifi.InterfaceName, yachtRouterConfigWANWifi);
			}
		}

		public bool IfConfigurable_WanWifiConfiguration()
		{
			string yachtRouterActiveWANWifi = this.GetYachtRouterActiveWANWifi();
			int num = 0;
			goto IL_0026;
			IL_0026:
			if (num < this.WanWifiConfiguration.Count)
			{
				YachtRouterConfigWANWifi yachtRouterConfigWANWifi = this.WanWifiConfiguration[num];
				return yachtRouterConfigWANWifi.IsConfigurable;
			}
			return false;
			IL_0022:
			num++;
			goto IL_0026;
		}

		public void SetWanWifiConfiguration(string InterfaceName, YachtRouterConfigWANWifi config)
		{
			for (int i = 0; i < this._mainConfig.WifiWANs.Count; i++)
			{
				if (this._mainConfig.WifiWANs[i].InterfaceName == InterfaceName && this._mainConfig.WifiWANs[i].IsConfigurable)
				{
					MK routerByRouterID = this.GetRouterByRouterID(this._mainConfig.WifiWANs[i].RouterID);
					routerByRouterID.SetWanWifiConfiguration(this._mainConfig.WifiWANs[i].InterfaceName, config);
					this.boolStartedWorkingPasswordStart = false;
				}
			}
		}

		public List<string> ScanWANWiFi(string RouterID, string WanWifiInterface)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(RouterID);
				return routerByRouterID.ScanWANWiFi(WanWifiInterface);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return new List<string>();
		}

		public void StopScanWANWiFi()
		{
			this.StopScanning = true;
			if (this.curScanThread != null)
			{
				while (this.curScanThread.IsAlive)
				{
					Thread.Sleep(50);
				}
			}
		}

		public void StartScanWANWiFi(string RouterID, string WanWifiInterface)
		{
			try
			{
				this.curScanThread = new Thread(this.ScanWANWiFiStartGetResultsSSH);
				this.curScanThread.IsBackground = true;
				this.StopScanning = false;
				this.curScanThread.Start(new List<string>
				{
					RouterID,
					WanWifiInterface
				});
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		private void ScanWANWiFiStartGetResults(object transfer)
		{
			List<string> list = transfer as List<string>;
			MK routerByRouterID = this.GetRouterByRouterID(list[0]);
			List<string> list2 = new List<string>();
			int num = 0;
			int num2 = 0;
			do
			{
				try
				{
					routerByRouterID.AccessToRouterLock.EnterWriteLock("ScanWANWiFiStartGetResults");
					if (routerByRouterID.EnsureConnection())
					{
						routerByRouterID.Send("/interface/wireless/scan");
						routerByRouterID.Send("=.id=" + list[1]);
						routerByRouterID.Send(".tag=8", true);
						do
						{
							List<string> list3 = routerByRouterID.Read(true, 1);
							if (list3[0].IndexOf(".tag=8") != -1)
							{
								try
								{
									string text = yrUtils.ExtractInfo(list3[0], "=ssid=");
									string text2 = yrUtils.ExtractInfo(list3[0], "=band=");
									string text3 = yrUtils.ExtractInfo(list3[0], "=freq=");
									string text4 = yrUtils.ExtractInfo(list3[0], "=sig=");
									string text5 = yrUtils.ExtractInfo(list3[0], "=nf=");
									string text6 = yrUtils.ExtractInfo(list3[0], "=snr=");
									if (!this.CheckStringForUnexpectedChars(text4) && !this.CheckStringForUnexpectedChars(text2) && !this.CheckStringForUnexpectedChars(text3) && !this.CheckStringForUnexpectedChars(text6) && !this.CheckStringForUnexpectedChars(text5))
									{
										string text7 = yrUtils.encodeSSID(text);
										string text8 = text7 + "#" + text2 + "#" + text3 + "#" + text4 + "#" + text5 + "#" + text6;
										if (!(text == string.Empty))
										{
											bool flag = false;
											foreach (YachtRouterConfigWifiAP vN in this.mainConfig.VNs)
											{
												if (vN.WiFiAPN == text)
												{
													flag = true;
												}
											}
											if (!flag)
											{
												bool flag2 = false;
												for (int i = 0; i < list2.Count; i++)
												{
													if (list2[i].Split('#')[0] == text7)
													{
														list2[i] = text8;
														flag2 = true;
													}
												}
												if (!flag2)
												{
													list2.Add(text8);
												}
												if (num == list2.Count)
												{
													if (num2 % (list2.Count * 10) == 0 && !this.StopScanning)
													{
														this.FireOnStatusUpdate(RouterStatuses.WanWifiNewNetworkFound, list2);
													}
												}
												else
												{
													if (!this.StopScanning)
													{
														this.FireOnStatusUpdate(RouterStatuses.WanWifiNewNetworkFound, list2);
													}
													num2 = 0;
												}
												num2++;
												num = list2.Count;
											}
										}
									}
								}
								catch (Exception ex)
								{
									this._curLogger.LogException(ex);
								}
							}
						}
						while (!this.StopScanning);
						routerByRouterID.Send("/cancel");
						routerByRouterID.Send(".tag=8", true);
						List<string> list4 = routerByRouterID.Read();
						List<string> list5 = routerByRouterID.Read();
					}
				}
				catch (Exception ex2)
				{
					this._curLogger.LogException(ex2);
				}
				finally
				{
					routerByRouterID.AccessToRouterLock.ExitWriteLock("ScanWANWiFiStartGetResults");
				}
			}
			while (!this.StopScanning);
		}

		private bool CheckStringForUnexpectedChars(string targetString)
		{
			for (int i = 0; i < targetString.Length; i++)
			{
				if (targetString[i] != '-' && targetString[i] != '=' && targetString[i] != '!' && targetString[i] != '.' && targetString[i] != ',' && targetString[i] != ':' && targetString[i] != ' ' && targetString[i] != '_' && !char.IsPunctuation(targetString[i]) && !char.IsSeparator(targetString[i]) && !char.IsLetterOrDigit(targetString[i]))
				{
					return true;
				}
			}
			return false;
		}

		public Dictionary<string, bool[]> GetWirelessInterfaceEnabledAndVisibleStatus(string RouterIP, int NumberOfWifiNetworks)
		{
			Dictionary<string, bool[]> dictionary = new Dictionary<string, bool[]>();
			try
			{
				MK mK = new MK("wifiExtender", RouterIP, this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
				mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
				for (int i = 1; i <= NumberOfWifiNetworks; i++)
				{
					dictionary.Add(i.ToString(), mK.GetWirelessInterfaceEnabledAndVisibleStatus("shipWIFI" + i));
				}
				mK.Close();
				return dictionary;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return dictionary;
			}
		}

		public void StopWanStatusUpdate()
		{
			this.StopWanStatusUpdateFlag = true;
			if (this.curWanWifiStatusUpdateThread != null)
			{
				int num = 10;
				while (this.curWanWifiStatusUpdateThread != null && this.curWanWifiStatusUpdateThread.IsAlive && !this.WanStatusUpdateGetResultsReallyReallyStopped)
				{
					Thread.Sleep(50);
					num--;
					if (num == 0)
					{
						this.curWanWifiStatusUpdateThread.Abort();
						this.curWanWifiStatusUpdateThread = null;
					}
				}
				while (!this.WanStatusUpdateGetResultsReallyReallyStopped)
				{
					Thread.Sleep(50);
					num--;
				}
			}
		}

		public void StartWanStatusUpdate(string RouterID, string WanInterface, bool WifiAdditionalInfo, bool MobileAdditionalInfo, bool DynamicMultipassUpdate)
		{
			try
			{
				if (this.curWanWifiStatusUpdateThread == null || !this.curWanWifiStatusUpdateThread.IsAlive)
				{
					this.curWanWifiStatusUpdateThread = new Thread(this.WanStatusUpdateGetResults);
					this.curWanWifiStatusUpdateThread.IsBackground = true;
					this.StopWanStatusUpdateFlag = false;
					this.WanStatusShowWifiAdditionalInfo = WifiAdditionalInfo;
					this.WanStatusShowMobileAdditionalInfo = MobileAdditionalInfo;
					this.curWanWifiStatusUpdateThread.Start(new List<string>
					{
						RouterID,
						WanInterface,
						DynamicMultipassUpdate.ToString()
					});
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		private void WanStatusUpdateGetResults(object transfer)
		{
			bool flag;
			do
			{
				List<string> list = transfer as List<string>;
				MK routerByRouterID = this.GetRouterByRouterID(list[0]);
				MK mK = new MK(routerByRouterID.RouterID, routerByRouterID.RouterIP, this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
				mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
				flag = false;
				int num = 0;
				bool flag2 = Convert.ToBoolean(list[2]);
				List<string> list2 = new List<string>();
				List<string> list3 = new List<string>();
				this.WanStatusUpdateGetResultsReallyReallyStopped = false;
				this.boolStartedWorkingPasswordStart = false;
				int num2 = 0;
				try
				{
					this._curLogger.LogMessage("WanStatusUpdateGetResults STARTING");
					mK.AccessToRouterLock.EnterWriteLock("WanStatusUpdateGetResults");
					if (mK.EnsureConnection())
					{
						if (this.WanStatusShowWifiAdditionalInfo)
						{
							mK.Send("/interface/wireless/monitor");
							mK.Send("=.id=" + list[1]);
							mK.Send(".tag=9", true);
						}
						if (this.WanStatusShowMobileAdditionalInfo)
						{
							mK.Send("/interface/lte/info");
							mK.Send("=.id=" + list[1]);
							mK.Send(".tag=15", true);
						}
						do
						{
							try
							{
								this._curLogger.LogMessage("WanStatusUpdateGetResults CYCLE STARTING");
								List<string> list4 = new List<string>();
								if (num2++ % 3 == 0)
								{
									mK.Send("/ip/dhcp-client/print");
									mK.Send(".tag=10", true);
									list4 = mK.Read();
									foreach (string item in list4)
									{
										if (item.IndexOf(".tag=10") != -1 && !this.StopWanStatusUpdateFlag && yrUtils.ExtractInfo(item, "=interface=") == list[1])
										{
											if (!this.StopWanStatusUpdateFlag)
											{
												this.FireOnStatusUpdate(RouterStatuses.WanNetworkDhcpStatus, new List<string>
												{
													yrUtils.ExtractInfo(item, "=status=")
												});
											}
											break;
										}
									}
								}
								else
								{
									list2.Clear();
									list3.Clear();
									try
									{
										if (this.WanStatusShowWifiAdditionalInfo || this.WanStatusShowMobileAdditionalInfo)
										{
											list4 = mK.Read(true, 1);
										}
									}
									catch
									{
										continue;
									}
								}
								if (this.requestLTERunningParam)
								{
									mK.Send("/interface/lte/print");
									mK.Send(".tag=16", true);
								}
								if (!this.StopWanStatusUpdateFlag)
								{
									if (list4.Count <= 0)
									{
										goto IL_0cea;
									}
									if (list4[0].IndexOf(".tag=16") != -1)
									{
										if (yrUtils.ExtractInfo(list4[0], "=name=") == list[1])
										{
											if (list4[0].Contains("=running=true"))
											{
												this.LTERunning = 1;
											}
											else
											{
												this.LTERunning = -1;
											}
											this.LTERunningPreviousData = this.LTERunning;
										}
										this.LTERunning = this.LTERunningPreviousData;
									}
									if (list4[0].IndexOf(".tag=15") != -1)
									{
										num = 0;
										string empty = string.Empty;
										string text = yrUtils.ExtractInfo(list4[0], "=current-operator").Replace('-', ' ');
										if (text != string.Empty)
										{
											this.mobileLastOperator = text;
										}
										if (text == string.Empty)
										{
											text = this.mobileLastOperator;
										}
										if (text.IndexOf('(') != -1)
										{
											text = text.Substring(0, text.IndexOf('('));
										}
										string text2 = yrUtils.ExtractInfo(list4[0], "=imei").Replace('-', ' ');
										if (text2 == string.Empty)
										{
											text2 = yrUtils.ExtractInfo(list4[0], "=serial-number").Replace('-', ' ');
										}
										string text3 = string.Empty;
										if (list4[0].Contains("=rssi="))
										{
											this.requestLTERunningParam = true;
										}
										if (this.requestLTERunningParam)
										{
											if (this.LTERunning == -1)
											{
												text3 = "Connecting ";
											}
											if (this.LTERunning == 1)
											{
												text3 = "Connected ";
											}
										}
										else
										{
											text3 = yrUtils.ExtractInfo(list4[0], "=status").Replace('-', ' ');
										}
										empty = ((!yrUtils.ExtractInfo(list4[0], "=pin-status").Contains("no password req") && !list4[0].Contains("=functionality=full") && !(yrUtils.ExtractInfo(list4[0], "=access-technology") != string.Empty)) ? yrUtils.ExtractInfo(list4[0], "=pin-status").Replace('-', ' ') : (text3 + "  " + text + " " + yrUtils.ExtractInfo(list4[0], "=access-technology").Replace('-', ' ').Replace("GSM compact", "2G")
											.Replace("Evolved 3G (LTE)", "4G")));
										if (empty.ToLower().IndexOf("error") != -1)
										{
											empty = empty.ToLower().Replace("error", string.Empty);
										}
										if (list4[0].ToLower().Contains("sim failure"))
										{
											empty = "SIM Failure";
										}
										if (yrUtils.ExtractInfo(list4[0], "=pin-status").Replace('-', ' ').Contains("not inserted"))
										{
											empty = yrUtils.ExtractInfo(list4[0], "=pin-status").Replace('-', ' ').Replace("+CME", string.Empty)
												.Replace("ERROR: ", string.Empty);
										}
										string text4 = yrUtils.ExtractInfo(list4[0], "=pin-status").Replace('-', ' ');
										if (text4.Trim() != string.Empty)
										{
											this.lastPinStatus = text4;
										}
										else
										{
											text4 = this.lastPinStatus;
										}
										list3.Add("Pin Status#" + this.lastPinStatus);
										string text5 = yrUtils.ExtractInfo(list4[0], "=functionality").Replace('-', ' ');
										if (text5.Trim() != string.Empty)
										{
											this.lastFunctionality = text5;
										}
										else
										{
											text5 = this.lastFunctionality;
										}
										list3.Add("Functionality#" + text5);
										list3.Add("Current Operator#" + text);
										string text6 = yrUtils.ExtractInfo(list4[0], "=signal-streng").Replace("-s", " s") + yrUtils.ExtractInfo(list4[0], "=rssi");
										if (text6.Trim() != string.Empty)
										{
											this.lastSignalStrength = text6;
										}
										else
										{
											text6 = this.lastSignalStrength;
										}
										list3.Add("Signal Strengh#" + text6);
										list3.Add("Network Mode#" + yrUtils.ExtractInfo(list4[0], "=access-technology").Replace('-', ' ').Replace("GSM compact", "2G")
											.Replace("Evolved 3G (LTE)", "4G"));
										list3.Add("IMEI#" + text2);
										if (empty.Trim() != string.Empty && !this.StopWanStatusUpdateFlag)
										{
											this.FireOnStatusUpdate(RouterStatuses.MobileStatus, new List<string>
											{
												empty
											});
										}
										if (!this.StopWanStatusUpdateFlag)
										{
											this.FireOnStatusUpdate(RouterStatuses.MobileDetailedStatus, list3);
										}
									}
									if (!this.StopWanStatusUpdateFlag)
									{
										if (list4[0].IndexOf(".tag=9") != -1)
										{
											string text7 = yrUtils.ExtractInfo(list4[0], "=status").Replace('-', ' ');
											string str = yrUtils.encodeSSID(yrUtils.ExtractInfo(list4[0], "=ssid="));
											if (text7.IndexOf("connected") != -1)
											{
												text7 = "connected to " + str;
											}
											if (text7.Contains("connected") && !this.boolStartedWorkingPasswordStart)
											{
												this.timeWorkingPasswordStart = DateTime.Now;
												this.WorkingPasswordLastStatus = "connected";
												this.WorkingPasswordChangeCounter = 0;
												this.boolStartedWorkingPasswordStart = true;
											}
											else if (text7.Contains("connected") && this.boolStartedWorkingPasswordStart)
											{
												if (this.WorkingPasswordLastStatus == "searching")
												{
													this.WorkingPasswordLastStatus = "connected";
													this.WorkingPasswordChangeCounter++;
												}
											}
											else if (text7.Contains("searching") && this.boolStartedWorkingPasswordStart && this.WorkingPasswordLastStatus == "connected")
											{
												this.WorkingPasswordLastStatus = "searching";
												this.WorkingPasswordChangeCounter++;
											}
											if (this.boolStartedWorkingPasswordStart && (DateTime.Now - this.timeWorkingPasswordStart).TotalSeconds > 10.0 && this.WorkingPasswordChangeCounter >= 4)
											{
												text7 = "wrong password";
											}
											list2.Add("ssid#" + str);
											if (yrUtils.ExtractInfo(list4[0], "=band=") != string.Empty)
											{
												list2.Add("band#" + yrUtils.ExtractInfo(list4[0], "=band="));
												list2.Add("frequency#" + yrUtils.ExtractInfo(list4[0], "=frequency="));
											}
											else
											{
												list2.Add("channel#" + yrUtils.ExtractInfo(list4[0], "=channel="));
											}
											list2.Add("wireless protocol#" + yrUtils.ExtractInfo(list4[0], "=wireless-protocol="));
											list2.Add("tx rate#" + yrUtils.ExtractInfo(list4[0], "=tx-rate=") + " Mbps");
											list2.Add("rx rate#" + yrUtils.ExtractInfo(list4[0], "=rx-rate=") + " Mbps");
											list2.Add("bssid#" + yrUtils.ExtractInfo(list4[0], "=bssid="));
											list2.Add("radio name#" + yrUtils.ExtractInfo(list4[0], "=radio-name="));
											list2.Add("signal strength#" + yrUtils.ExtractInfo(list4[0], "=signal-strength=") + " dBm");
											list2.Add("tx signal strength#" + yrUtils.ExtractInfo(list4[0], "=tx-signal-strength=") + " dBm");
											list2.Add("noise floor#" + yrUtils.ExtractInfo(list4[0], "=noise-floor=") + " dBm");
											list2.Add("signal to noise#" + yrUtils.ExtractInfo(list4[0], "=signal-to-noise=") + " dB");
											list2.Add("tx ccq#" + yrUtils.ExtractInfo(list4[0], "=tx-ccq=") + " %");
											list2.Add("rx ccq#" + yrUtils.ExtractInfo(list4[0], "=rx-ccq=") + " %");
											list2.Add("overall tx ccq#" + yrUtils.ExtractInfo(list4[0], "=overall-tx-ccq=") + " %");
											list2.Add("last ip#" + yrUtils.ExtractInfo(list4[0], "=last-ip="));
											list2.Add("authentication-type#" + yrUtils.ExtractInfo(list4[0], "=authentication-type="));
											list2.Add("group encryption#" + yrUtils.ExtractInfo(list4[0], "=group-encryption="));
											list2.Add("management protection#" + yrUtils.ExtractInfo(list4[0], "=management-protection="));
											list2.Add("compression#" + yrUtils.ExtractInfo(list4[0], "=compression="));
											if (!this.StopWanStatusUpdateFlag)
											{
												this.FireOnStatusUpdate(RouterStatuses.WanWifiConnectedStatus, new List<string>
												{
													text7
												});
											}
											if (!this.StopWanStatusUpdateFlag)
											{
												this.FireOnStatusUpdate(RouterStatuses.WanWifiConnectedDetailedStatus, list2);
											}
										}
										if (!this.StopWanStatusUpdateFlag)
										{
											goto IL_0cea;
										}
									}
								}
								goto end_IL_011c;
								IL_0cea:
								if (!this.StopWanStatusUpdateFlag)
								{
									this._curLogger.LogMessage("WanStatusUpdateGetResults CYCLE FINISHED");
									Thread.Sleep(100);
									goto IL_0d2a;
								}
								end_IL_011c:;
							}
							catch (Exception ex)
							{
								this._curLogger.LogException(ex);
								goto IL_0d2a;
							}
							break;
							IL_0d2a:
							if (this.WanStatusShowMobileAdditionalInfo)
							{
								num++;
								if (num > 5)
								{
									flag = true;
									break;
								}
							}
						}
						while (!this.StopWanStatusUpdateFlag && flag2);
						this._curLogger.LogMessage("WanStatusUpdateGetResults STOPPING");
						if (this.WanStatusShowWifiAdditionalInfo)
						{
							mK.Send("/cancel");
							mK.Send(".tag=9", true);
						}
						if (this.WanStatusShowMobileAdditionalInfo)
						{
							mK.Send("/cancel");
							mK.Send(".tag=15", true);
						}
						bool flag3 = false;
						while (!flag3)
						{
							try
							{
								List<string> list5 = mK.Read();
								Thread.Sleep(10);
							}
							catch
							{
								flag3 = true;
							}
						}
					}
				}
				catch (Exception ex2)
				{
					this._curLogger.LogException(ex2);
				}
				finally
				{
					mK.AccessToRouterLock.ExitWriteLock("WanStatusUpdateGetResults");
					mK.Close();
					mK = null;
					this.WanStatusUpdateGetResultsReallyReallyStopped = true;
				}
			}
			while (flag);
			this._curLogger.LogMessage("WanStatusUpdateGetResults STOPPED & EXITED");
		}

		public bool CheckIfMobileExpanderIsMissing()
		{
			bool result = false;
			try
			{
				int num = 0;
				goto IL_0028;
				IL_0028:
				if (num < this._Routers.Count)
				{
					MK router = this._Routers[num];
					return this.CheckIfWanWifiIsMissingForRouter(router, false);
				}
				return result;
				IL_0024:
				num++;
				goto IL_0028;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return result;
			}
		}

		private bool CheckIfMobileExpanderIsMissingForRouter(MK router, bool AssumeItIsMissing)
		{
			bool result = false;
			try
			{
				while (true)
				{
					int num = 0;
					while (true)
					{
						if (num < this.mainConfig.MobileWANs.Count)
						{
							YachtRouterConfigWANMobile yachtRouterConfigWANMobile = this.mainConfig.MobileWANs[num];
							if (router.RouterID == yachtRouterConfigWANMobile.RouterID)
							{
								if (AssumeItIsMissing)
								{
									break;
								}
								if (!router.ConnectedToRouter)
								{
									break;
								}
							}
							num++;
							continue;
						}
						return result;
					}
					this.mainConfig.MobileWANs.RemoveAt(num);
					this._Routers.Remove(router);
					this._IsModuleMissing = true;
					result = true;
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return result;
			}
		}

		public bool CheckIfWanWifiIsMissing()
		{
			try
			{
				int num = 0;
				goto IL_0026;
				IL_0026:
				if (num < this._Routers.Count)
				{
					MK router = this._Routers[num];
					return this.CheckIfWanWifiIsMissingForRouter(router, false);
				}
				goto end_IL_0000;
				IL_0022:
				num++;
				goto IL_0026;
				end_IL_0000:;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return false;
		}

		private bool CheckIfWanWifiIsMissingForRouter(MK router, bool AssumeItIsMissing)
		{
			try
			{
				for (int i = 0; i < this.mainConfig.WifiWANs.Count; i++)
				{
					YachtRouterConfigWANWifi yachtRouterConfigWANWifi = this.mainConfig.WifiWANs[i];
					if (router.RouterID == yachtRouterConfigWANWifi.RouterID && (AssumeItIsMissing || !router.EnsureConnection()))
					{
						this.mainConfig.WifiWANs.RemoveAt(i);
						this._Routers.Remove(router);
						this._IsModuleMissing = true;
						return true;
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return false;
		}

		public string GetYachtRouterGUIScreenPassword()
		{
			try
			{
				MK mK = this._Routers[0];
				return mK.GetYachtRouterGUIScreenPassword();
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return string.Empty;
		}

		public void SetYachtRouterGUIScreenPassword(string newPassword)
		{
			try
			{
				MK mK = this._Routers[0];
				mK.SetYachtRouterGUIScreenPassword(newPassword);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public string GetYachtRouterActiveWANLan()
		{
			try
			{
				MK mK = this._Routers[0];
				return mK.GetYachtRouterActiveWANLan();
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return string.Empty;
		}

		public void SetYachtRouterActiveWANLan(string newWAN)
		{
			try
			{
				MK mK = this._Routers[0];
				mK.SetYachtRouterActiveWANLan(newWAN);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public string GetYachtRouterActiveWANMobile()
		{
			try
			{
				MK mK = this._Routers[0];
				return mK.GetYachtRouterActiveWANMobile();
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return string.Empty;
		}

		public void SetYachtRouterActiveWANMobile(string newWAN)
		{
			try
			{
				MK mK = this._Routers[0];
				mK.SetYachtRouterActiveWANMobile(newWAN);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public string GetYachtRouterActiveWANWifi()
		{
			try
			{
				MK mK = this._Routers[0];
				return mK.GetYachtRouterActiveWANWifi();
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return string.Empty;
		}

		public void SetYachtRouterActiveWANWifi(string newWAN)
		{
			try
			{
				MK mK = this._Routers[0];
				mK.SetYachtRouterActiveWANWifi(newWAN);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public bool RouterConfigurationRestore(string BackupName)
		{
			try
			{
				this.SuspendUpdates = true;
				bool result = true;
				for (int i = 0; i < this._Routers.Count; i++)
				{
					MK mK = this._Routers[i];
					if (!mK.RouterConfigurationRestore(BackupName))
					{
						result = false;
					}
				}
				this.FireOnStatusUpdate(RouterStatuses.ConnectedToRouter, new List<string>
				{
					"False"
				});
				this.FireOnStatusUpdate(RouterStatuses.PleaseWaitMessage, true);
				return result;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			finally
			{
				Thread.Sleep(10000);
				this.SuspendUpdates = false;
			}
			return false;
		}

		public bool RouterConfigurationBackup(string BackupName)
		{
			try
			{
				bool result = true;
				for (int i = 0; i < this._Routers.Count; i++)
				{
					MK mK = this._Routers[i];
					if (!mK.RouterConfigurationsBackup(BackupName))
					{
						result = false;
					}
				}
				List<string> dhcpLeasesAndFixThem = this.GetRouterByRouterID(this._mainConfig.RouterConfigs[0].RouterID).GetDhcpLeasesAndFixThem(yrEngine.rootExtenderDHCPServer, yrEngine.extenderIdentity);
				for (int j = 0; j < dhcpLeasesAndFixThem.Count; j++)
				{
					try
					{
						if (this.CheckExtenderAvailability(dhcpLeasesAndFixThem[j]))
						{
							MK mK2 = new MK("extender", dhcpLeasesAndFixThem[j], this._curLogger, string.Empty);
							mK2.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
							if (mK2.EnsureConnection())
							{
								mK2.RouterConfigurationsBackup(BackupName);
							}
						}
					}
					catch (Exception ex)
					{
						this._curLogger.LogException(ex);
					}
				}
				return result;
			}
			catch (Exception ex2)
			{
				this._curLogger.LogException(ex2);
			}
			return false;
		}

		public string GetVNOutputPower()
		{
			return this.GetRouterByRouterID(this.mainConfig.WifiAPs[0].RouterID).GetVNOutputPower("shipPhysical");
		}

		public string GetWANOutputPower()
		{
			return this.GetRouterByRouterID(this.mainConfig.WifiWANs[0].RouterID).GetVNOutputPower(this.mainConfig.WifiWANs[0].InterfaceName);
		}

		public void SetWANOutputPower(string power)
		{
			try
			{
				if (power != this.GetRouterByRouterID(this.mainConfig.WifiWANs[0].RouterID).GetVNOutputPower(this.mainConfig.WifiWANs[0].InterfaceName))
				{
					this.GetRouterByRouterID(this.mainConfig.WifiWANs[0].RouterID).SetVNOutputPower(this.mainConfig.WifiWANs[0].InterfaceName, power);
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void SetVNOutputPower(string power)
		{
			try
			{
				if (power != this.GetRouterByRouterID(this.mainConfig.WifiAPs[0].RouterID).GetVNOutputPower("shipPhysical"))
				{
					this.GetRouterByRouterID(this.mainConfig.WifiAPs[0].RouterID).SetVNOutputPower("shipPhysical", power);
				}
				List<string> dhcpLeasesAndFixThem = this.GetRouterByRouterID(this._mainConfig.RouterConfigs[0].RouterID).GetDhcpLeasesAndFixThem(yrEngine.rootExtenderDHCPServer, yrEngine.extenderIdentity);
				foreach (string item in dhcpLeasesAndFixThem)
				{
					try
					{
						MK mK = new MK("Extender_" + item, item, this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
						mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
						mK.SetVNOutputPower("shipPhysical", power);
					}
					catch
					{
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void SetVNOutputPowerForWifiExtender(string RouterIP, string power)
		{
			try
			{
				try
				{
					MK mK = new MK("wifiExtender", RouterIP, this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
					mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
					mK.SetVNOutputPower(yrEngine.shipPhysicalWifiInterface, power);
					mK.Close();
				}
				catch (Exception ex)
				{
					this._curLogger.LogException(ex);
				}
			}
			catch (Exception ex2)
			{
				this._curLogger.LogException(ex2);
			}
		}

		public string GetVNOutputPowerForWifiExtender(string RouterIP)
		{
			try
			{
				try
				{
					MK mK = new MK("wifiExtender", RouterIP, this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
					mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
					string vNOutputPower = mK.GetVNOutputPower(yrEngine.shipPhysicalWifiInterface);
					mK.Close();
					return vNOutputPower;
				}
				catch (Exception ex)
				{
					this._curLogger.LogException(ex);
				}
			}
			catch (Exception ex2)
			{
				this._curLogger.LogException(ex2);
			}
			return string.Empty;
		}

		public void ConfigureAlwaysOnNetwork(YachtRouterConfigWANLan curConfig)
		{
		}

		private void ConfigureWifiApOnExtenders(string interfaceName, string wifiSecurityProfileName, bool IsEnabled, string newSSID, string newPassword, bool ChangeSSID, bool ChangePassowrd)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(this._mainConfig.RouterConfigs[0].RouterID);
				List<string> dhcpLeasesAndFixThem = routerByRouterID.GetDhcpLeasesAndFixThem(yrEngine.rootExtenderDHCPServer, yrEngine.extenderIdentity);
				int num = dhcpLeasesAndFixThem.Count;
				if (num > this.mainConfig.MaxNumberOfWifiExteders)
				{
					num = this.mainConfig.MaxNumberOfWifiExteders;
				}
				for (int i = 0; i < num; i++)
				{
					try
					{
						MK mK = new MK("Extender_" + dhcpLeasesAndFixThem[i], dhcpLeasesAndFixThem[i], this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
						mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
						mK.EnableDisableInterfacePhysical(interfaceName, IsEnabled);
						if (mK.GetIsDualFrequencyWIFISSIDisAvailable())
						{
							mK.EnableDisableInterfacePhysical(interfaceName + "Ex", IsEnabled);
						}
						if (ChangePassowrd)
						{
							mK.SetWifiInterfacePassword(wifiSecurityProfileName, newPassword, false);
						}
						if (ChangeSSID)
						{
							mK.SetWifiInterfaceSSID(interfaceName, newSSID);
						}
					}
					catch (Exception ex)
					{
						this._curLogger.LogException(ex);
					}
				}
			}
			catch (Exception ex2)
			{
				this._curLogger.LogException(ex2);
			}
		}

		public void ReconfigureExtenderSubsystem()
		{
			try
			{
				this.SuspendUpdates = true;
				int num = 0;
				int num2 = 1;
				this.FireNewInfo("Reconfigure WIFI Extender Subsystem Starting", true, 1);
				MK routerByRouterID = this.GetRouterByRouterID(this._mainConfig.RouterConfigs[0].RouterID);
				List<string> list = new List<string>();
				try
				{
					list = this.GetRouterByRouterID(this._mainConfig.RouterConfigs[0].RouterID).GetDhcpLeasesAndFixThem(yrEngine.rootExtenderDHCPServer, yrEngine.extenderIdentity);
					while (true)
					{
						int num3 = -1;
						int num4 = 0;
						while (num4 < list.Count)
						{
							if (num4 + 1 <= this.mainConfig.MaxNumberOfWifiExteders && this.CheckExtenderAvailability(list[num4]))
							{
								num4++;
								continue;
							}
							num3 = num4;
							break;
						}
						if (num3 == -1)
						{
							break;
						}
						list.RemoveAt(num3);
					}
				}
				catch (Exception ex)
				{
					this._curLogger.LogException(ex);
				}
				this.FireNewInfo("Number of WIFI Extenders Found: " + list.Count, true, 3);
				this.FireNewInfo("Cleaning existing connections", true, 1);
				this.CleanAllExtenders(list);
				this.UpdateVNConfiguration();
				for (num = 0; num < list.Count; num++)
				{
					MK mK = null;
					try
					{
						this.FireNewInfo("Configuring WIFI Extender " + (num + 1) + " / " + list.Count, true, 1);
						mK = new MK("Extender_" + list[num], list[num], this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
						mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
						for (int i = 0; i < this.mainConfig.VNs.Count; i++)
						{
							YachtRouterConfigWifiAP yachtRouterConfigWifiAP = this.mainConfig.VNs[i];
							mK.CreateVirtualAP(yrEngine.shipPhysicalWifiInterface, yachtRouterConfigWifiAP.InterfaceName, yachtRouterConfigWifiAP.WiFiAPN, yachtRouterConfigWifiAP.WiFiSecurityPassword);
							mK.CreateBridgePort("bridgeVN" + (i + 1), yachtRouterConfigWifiAP.InterfaceName);
							mK.EnableDisableInterfacePhysical(yachtRouterConfigWifiAP.InterfaceName, yachtRouterConfigWifiAP.WiFiEnabled);
							if (mK.GetIsDualFrequencyWIFISSIDisAvailable())
							{
								mK.CreateBridgePort("bridgeVN" + (i + 1), yachtRouterConfigWifiAP.InterfaceName + "Ex");
								mK.EnableDisableInterfacePhysical(yachtRouterConfigWifiAP.InterfaceName + "Ex", yachtRouterConfigWifiAP.WiFiEnabled);
							}
						}
					}
					catch (Exception ex2)
					{
						if (mK != null)
						{
							this.FireNewInfo("Configuring WIFI Extender FAILED: " + mK.RouterIP, true, 5);
						}
						this._curLogger.LogException(ex2);
					}
				}
				this.FireNewInfo("Configuring WIFI Extenders Initializing Extenders", true, 1);
				this.EnabledDisableVNWifi(1, true);
				this.FireNewInfo("Configuring WIFI Extenders Finished", true, 5);
			}
			catch (Exception ex3)
			{
				this._curLogger.LogException(ex3);
			}
			finally
			{
				this.SuspendUpdates = false;
			}
		}

		public List<string> GetWifiExtenders()
		{
			return this.GetWifiExtenders(yrEngine.extenderIdentity);
		}

		public List<string> GetWifiExtenders(string targetExtenderIdentity)
		{
			List<string> list = new List<string>();
			try
			{
				List<string> dhcpLeasesAndFixThem = this.GetRouterByRouterID(this._mainConfig.RouterConfigs[0].RouterID).GetDhcpLeasesAndFixThem(yrEngine.rootExtenderDHCPServer, targetExtenderIdentity);
				int num = 0;
				foreach (string item in dhcpLeasesAndFixThem)
				{
					if (num++ > this.mainConfig.MaxNumberOfWifiExteders)
					{
						return list;
					}
					string text = this.CheckExtenderAvailabilityAndGetIndentity(item);
					if (text != null && text != string.Empty)
					{
						list.Add(text);
					}
				}
				return list;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return list;
			}
		}

		public bool GetWifiExtendersPresentStatus()
		{
			List<string> list = new List<string>();
			try
			{
				List<string> dhcpLeasesAndFixThem = this.GetRouterByRouterID(this._mainConfig.RouterConfigs[0].RouterID).GetDhcpLeasesAndFixThem(yrEngine.rootExtenderDHCPServer, yrEngine.extenderIdentity);
				if (dhcpLeasesAndFixThem.Count > 0)
				{
					return true;
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return false;
		}

		private static string GetSSIDName(YachtRouterConfigWANBase curWAN, MK curMainRouter)
		{
			string result = curMainRouter.GetWanInterfaceTitle(curWAN.InterfaceName);
			if (curWAN is YachtRouterConfigWANWifi)
			{
				result = "Shore Wifi";
			}
			return result;
		}

		private void ConfigureExtenderToRouterConnection(int curTunnelID, MK curMainRouter, string InterfaceName, MK extender, string MainRouterBridge, string VirtualApName, string SSID, string Password)
		{
			try
			{
				extender.CreateBridge(yrEngine.bridgePrefix + InterfaceName);
				extender.CreateVirtualAP(yrEngine.shipPhysicalWifiInterface, VirtualApName, SSID, Password);
				extender.CreateEoipTunnel(yrEngine.eoipTunnelPrefix + InterfaceName + "_" + curTunnelID, extender.RouterIP, curMainRouter.RouterIP, curTunnelID.ToString());
				extender.CreateBridgePort(yrEngine.bridgePrefix + InterfaceName, VirtualApName);
				extender.CreateBridgePort(yrEngine.bridgePrefix + InterfaceName, yrEngine.eoipTunnelPrefix + InterfaceName + "_" + curTunnelID);
				curMainRouter.CreateEoipTunnel(yrEngine.eoipTunnelPrefix + InterfaceName + "_" + curTunnelID, curMainRouter.RouterIP, extender.RouterIP, curTunnelID.ToString());
				curMainRouter.CreateBridgePort(MainRouterBridge, yrEngine.eoipTunnelPrefix + InterfaceName + "_" + curTunnelID);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public bool CheckExtenderAvailability(string ExtenderIPAddress)
		{
			MK mK = null;
			return this.CheckExtenderAvailability(ExtenderIPAddress, out mK);
		}

		public bool CheckExtenderAvailability(string ExtenderIPAddress, out MK extender)
		{
			try
			{
				extender = new MK("Extender_" + ExtenderIPAddress, ExtenderIPAddress, this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
				extender.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
				return extender.EnsureConnection();
			}
			catch
			{
			}
			extender = null;
			return false;
		}

		private string CheckExtenderAvailabilityAndGetIndentity(string ExtenderIPAddress)
		{
			try
			{
				MK mK = new MK("Extender_" + ExtenderIPAddress, ExtenderIPAddress, this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
				mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
				if (mK.EnsureConnection())
				{
					return mK.GetIdentity();
				}
			}
			catch
			{
			}
			return string.Empty;
		}

		private void CleanAllExtenders(List<string> allExtenders)
		{
			try
			{
				for (int i = 0; i < allExtenders.Count; i++)
				{
					MK mK = new MK("Extender_" + allExtenders[i], allExtenders[i], this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
					mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
					mK.CleanEoipBridgesAndPorts();
					mK.CleanVirtualAPs("shipWIFI");
					mK.CleanAllWirelessSecurityProfiles();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		private void CleanMainRouters()
		{
			try
			{
				List<YachtRouterConfigWANBase> list = new List<YachtRouterConfigWANBase>();
				foreach (YachtRouterConfigWANLan lanWAN in this._mainConfig.LanWANs)
				{
					list.Add(lanWAN);
				}
				foreach (YachtRouterConfigWANWifi wifiWAN in this._mainConfig.WifiWANs)
				{
					list.Add(wifiWAN);
				}
				foreach (MK router in this._Routers)
				{
					router.CleanIpAddressesWithPrefix(yrEngine.bridgePrefix);
					router.CleanIpAddressPoolsWithPrefix(yrEngine.dhcpPoolNamePrefix);
					router.CleanDHCPServersWithPrefix(yrEngine.dhcpServerNamePrefix);
					router.CleanEoipBridgesAndPorts();
					router.CleanEOIPs();
					router.CleanVirtualAPs(yrEngine.virtualApPrefix);
					router.CleanFirewallMangleRoutingMarkRules(yrEngine.routingMarkPrefix);
					router.CleanRoutesWithRoutingMarks(yrEngine.routingMarkPrefix);
					router.CleanAllWirelessSecurityProfiles();
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public string GetStatisticsPointForInterface(object YachtRouterInterfaceObject, bool isAlwaysOnNetwork)
		{
			if (YachtRouterInterfaceObject is YachtRouterConfigWANBase)
			{
				if (isAlwaysOnNetwork)
				{
					return yrEngine.bridgePrefix + ((YachtRouterConfigInterfaceBase)YachtRouterInterfaceObject).InterfaceName;
				}
				return ((YachtRouterConfigInterfaceBase)YachtRouterInterfaceObject).InterfaceName;
			}
			if (YachtRouterInterfaceObject is YachtRouterConfigWifiAP)
			{
				return "bridge_" + ((YachtRouterConfigInterfaceBase)YachtRouterInterfaceObject).InterfaceName;
			}
			return string.Empty;
		}

		public string GetStatisticsVisibleNameForInterface(object YachtRouterInterfaceObject, bool isAlwaysOnNetwork)
		{
			if (YachtRouterInterfaceObject is YachtRouterConfigWANBase)
			{
				if (isAlwaysOnNetwork)
				{
					return "Vessel - Always On - " + ((YachtRouterConfigWANLan)YachtRouterInterfaceObject).AlwaysOnSSID;
				}
				return ((YachtRouterConfigInterfaceBase)YachtRouterInterfaceObject).Name;
			}
			if (YachtRouterInterfaceObject is YachtRouterConfigWifiAP)
			{
				return "Vessel - " + ((YachtRouterConfigWifiAP)YachtRouterInterfaceObject).WiFiAPN;
			}
			return string.Empty;
		}

		public string GetWanNameForInterface(string wanInterface)
		{
			try
			{
				foreach (YachtRouterConfigWANBase allWan in this.mainConfig.GetAllWans())
				{
					if (allWan.InterfaceName == wanInterface)
					{
						return allWan.Name;
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return string.Empty;
		}

		public List<YachtRouterConfigHotspotUser> GetHotspotUsers(string HotspotName)
		{
			List<YachtRouterConfigHotspotUser> result = new List<YachtRouterConfigHotspotUser>();
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				return routerByRouterID.GetHotspotUsers(HotspotName);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return result;
			}
		}

		public int[] GetHotspotUsersActiveAndRegistered(string HotspotName)
		{
			int[] result = new int[2];
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				return routerByRouterID.GetHotspotUsersActiveAndRegistered(HotspotName);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return result;
			}
		}

		public bool GetIsHotspotEnabledDisabled(string Server)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				return routerByRouterID.GetIsHotspotEnabledDisabled(Server);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return false;
		}

		public void HotspotEnableDisable(bool newState, string Server)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				routerByRouterID.HotspotEnableDisable(Server, newState);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void HotspotUserDelete(string Username, string Server)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				routerByRouterID.HotspotUserDelete(Username, Server);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void HotspotUserReset(string Username, string Server)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				routerByRouterID.HotspotUserReset(Username, Server);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void HotspotUsersAllDelete()
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				routerByRouterID.HotspotUsersAllDelete();
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void HotspotUsersAllReset(string Server)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				routerByRouterID.HotspotUsersAllReset(Server);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void HotspotUserEdit(string Username, string Password, string LimitTime, string LimitMegabytes, string Server)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				routerByRouterID.HotspotUserEdit(Username, Password, LimitTime, LimitMegabytes, Server);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void HotspotUserAdd(string Username, string Password, string LimitTime, string LimitMegabytes, string Server)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				routerByRouterID.HotspotUserAdd(Username, Password, LimitTime, LimitMegabytes, Server);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public static void EnableDisableScreenBacklight(bool newValue)
		{
		}

		private void ReportCurrentMemoryUsage()
		{
			GC.WaitForPendingFinalizers();
			GC.Collect();
			long totalMemory = GC.GetTotalMemory(true);
			this._curLogger.LogMessage("Current GC App Usage Memory: " + totalMemory);
		}

		private void ResetInterfaceUsage(string InterfaceName)
		{
		}

		public void EnableDisableWWWForAllRouters(bool newState)
		{
			try
			{
				foreach (MK router in this._Routers)
				{
					router.EnableDisableWWWService(newState);
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public string GetHTMLForGraphingForInterface(string InterfaceName, string PublicName, string RouterID)
		{
			try
			{
				string text = "http://" + this.GetRouterByRouterID(RouterID).RouterIP + "/graphs/iface/" + InterfaceName + "/";
				WebRequest webRequest = WebRequest.Create(text);
				using (WebResponse webResponse = webRequest.GetResponse())
				{
					using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream()))
					{
						string text2 = streamReader.ReadToEnd();
						text2 = text2.Replace(InterfaceName, PublicName);
						text2 = text2.Replace("<img src='", "<img src='" + text);
						text2 = text2.Replace("<a href=\"/graphs/\">Main page</a>", string.Empty);
						text2 = text2.Substring(text2.IndexOf("<body>") + 6);
						return text2.Substring(0, text2.IndexOf("</body>"));
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return string.Empty;
		}

		public void BandwithControlManualReset(string InterfaceName)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(this.GetRouterIDByWanInterfaceName(InterfaceName));
				routerByRouterID.ExecuteScript("script_" + InterfaceName + "_LogCounterReset");
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void SetBandwithControlLimits(string InterfaceName, string wanUsageLimit, string wanUsageWarning)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(this.GetRouterIDByWanInterfaceName(InterfaceName));
				routerByRouterID.SetWanInterfaceTitle("bridgeCounter_" + InterfaceName + "_Limit", wanUsageLimit);
				routerByRouterID.SetWanInterfaceTitle("bridgeCounter_" + InterfaceName + "_Warning", wanUsageWarning);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public string ResolveYachtRouterSupportIP()
		{
			return Dns.Resolve("yachtrouter.eu").AddressList[0].ToString();
		}

		public string ResolvePublicIP()
		{
			string empty = string.Empty;
			WebRequest webRequest = WebRequest.Create("http://checkip.dyndns.org/");
			using (WebResponse webResponse = webRequest.GetResponse())
			{
				using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream()))
				{
					empty = streamReader.ReadToEnd();
					empty = empty.Substring(empty.IndexOf(':') + 1);
					return empty.Substring(0, empty.IndexOf('<')).Trim();
				}
			}
		}

		public List<string> CheckStatusOfYachtRouterSupportNetwork()
		{
			return this._Routers[0].CheckYachtRouterVPNConnection("sstp-out1");
		}

		public void ConnectToYachtRouterSupportNetwork(string InterfaceName, string YachtRouterSupportIP, bool NewValue)
		{
			this._Routers[0].SetYachtRouterSupportIP(InterfaceName, YachtRouterSupportIP);
			this._Routers[0].EnableDisableInterfacePhysical(InterfaceName, NewValue);
		}

		public string GetStatusOfYachtRouterSupportNetwork(string InterfaceName)
		{
			switch (this._Routers[0].CheckIsInterfaceEnabledPhysicalByInterface(InterfaceName))
			{
			case false:
				return "disabled";
			default:
			{
				List<string> list = this._Routers[0].CheckYachtRouterVPNConnection(InterfaceName);
				int num = list.Count - 1;
				while (num > 0)
				{
					string text = yrUtils.ExtractInfo(list[num], "status=");
					if (text != null && !(text == "connected"))
					{
						num--;
						continue;
					}
					string text2 = yrUtils.ExtractInfo(list[num], "local-address=");
					return text2.Substring(text2.LastIndexOf('.') + 1);
				}
				return "notconnected";
			}
			}
		}

		public List<string> RetrieveLogs()
		{
			List<string> list = new List<string>();
			for (int i = 0; i < this._Routers.Count; i++)
			{
				list.AddRange(this._Routers[i].GetRouterLog());
			}
			return list;
		}

		public void RedirectVesselNetworkToWan(string RoutingMark, string wanInterface)
		{
			string routerIDByWanInterfaceName = this.GetRouterIDByWanInterfaceName(wanInterface);
			foreach (MK router in this._Routers)
			{
				MK routerByRouterID = this.GetRouterByRouterID(routerIDByWanInterfaceName);
				if (routerIDByWanInterfaceName == router.RouterID)
				{
					router.RouteSetTargetTo(RoutingMark, wanInterface);
				}
				else
				{
					router.RouteSetTargetTo(RoutingMark, routerByRouterID.RouterIP);
				}
			}
		}

		private string GetRouterIDByWanInterfaceName(string wanInterface)
		{
			foreach (YachtRouterConfigWANLan lanWAN in this._mainConfig.LanWANs)
			{
				if (lanWAN.InterfaceName == wanInterface)
				{
					return lanWAN.RouterID;
				}
			}
			foreach (YachtRouterConfigWANWifi wifiWAN in this._mainConfig.WifiWANs)
			{
				if (wifiWAN.InterfaceName == wanInterface)
				{
					return wifiWAN.RouterID;
				}
			}
			foreach (YachtRouterConfigWANMobile mobileWAN in this._mainConfig.MobileWANs)
			{
				if (mobileWAN.InterfaceName == wanInterface)
				{
					return mobileWAN.RouterID;
				}
			}
			return string.Empty;
		}

		public List<string> GetInterfaceStats(string Interface)
		{
			string routerID = string.Empty;
			foreach (YachtRouterConfigWANBase allWan in this._mainConfig.GetAllWans())
			{
				if (allWan.InterfaceName == Interface)
				{
					routerID = allWan.RouterID;
				}
			}
			MK routerByRouterID = this.GetRouterByRouterID(routerID);
			return routerByRouterID.GetInterfaceStats(Interface);
		}

		public bool CheckWanInternetStatus(YachtRouterConfigWANBase wan)
		{
			MK routerByRouterID = this.GetRouterByRouterID(wan.RouterID);
			return routerByRouterID.CheckWanInternetStatus(wan.CheckInternetStatusTargetIP);
		}

		public void SetInterfaceBridge(string RouterID, string InterfaceName, string BridgeToAssignTo)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(RouterID);
				routerByRouterID.SetInterfaceBridge(InterfaceName, BridgeToAssignTo);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public string GetInterfaceBridge(string RouterID, string InterfaceName)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(RouterID);
				return routerByRouterID.GetInterfaceBridge(InterfaceName);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return string.Empty;
		}

		public string GetEthernetPortStatus(string RouterID, string InterfaceName)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(RouterID);
				return this.ParseCableTestResults(routerByRouterID.GetEthernetPortStatus(InterfaceName));
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return string.Empty;
		}

		public string GetEthernetPortStatusForWifiExtender(string RouterIP, string InterfaceName)
		{
			try
			{
				MK mK = new MK("wifiExtender", RouterIP, this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
				mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
				string result = this.ParseCableTestResults(mK.GetEthernetPortStatus(InterfaceName));
				mK.Close();
				return result;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return string.Empty;
		}

		private string ParseCableTestResults(string rawData)
		{
			string empty = string.Empty;
			empty = empty + "Status: " + yrUtils.ExtractInfo(rawData, "status") + Environment.NewLine;
			empty = empty + "Rate: " + yrUtils.ExtractInfo(rawData, "rate") + Environment.NewLine;
			return empty + "Full Duplex: " + yrUtils.ExtractInfo(rawData, "full-duplex") + Environment.NewLine;
		}

		public void SetInterfaceBridgeForWifiExtender(string RouterIP, string InterfaceName, string BridgeToAssignTo)
		{
			try
			{
				MK mK = new MK("wifiExtender", RouterIP, this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
				mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
				mK.SetInterfaceBridge(InterfaceName, BridgeToAssignTo);
				mK.Close();
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public string GetInterfaceBridgeForWifiExtender(string RouterIP, string InterfaceName)
		{
			try
			{
				MK mK = new MK("wifiExtender", RouterIP, this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
				mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
				string interfaceBridge = mK.GetInterfaceBridge(InterfaceName);
				mK.Close();
				return interfaceBridge;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return string.Empty;
		}

		public string SetExtenderIdentity(string curWifiExtenderIP, string newIdentity)
		{
			try
			{
				MK mK = new MK("wifiExtender", curWifiExtenderIP, this._curLogger, this.mainConfig.HighSpeedSSIDSuffix);
				mK.InitializeRouter(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
				mK.SetIdentity(newIdentity);
				mK.Close();
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return string.Empty;
		}

		public void AddPortForward(string ip, string DevicePort, string CloudPort, string CloudPortComment)
		{
			try
			{
				string empty = string.Empty;
				empty = this.GetLoadbalancerModuleName(empty);
				foreach (YachtRouterConfigWANBase allWan in this.mainConfig.GetAllWans())
				{
					MK routerByRouterID = this.GetRouterByRouterID(allWan.RouterID);
					if (routerByRouterID.RouterID != empty)
					{
						routerByRouterID.AddPortForward(allWan.InterfaceName, ip, DevicePort, CloudPort, CloudPortComment, true);
						routerByRouterID.AddPortForward("vpn_" + allWan.InterfaceName, ip, DevicePort, CloudPort, CloudPortComment, false);
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public List<string[]> GetPortForwards()
		{
			List<string[]> list = new List<string[]>();
			try
			{
				string empty = string.Empty;
				empty = this.GetLoadbalancerModuleName(empty);
				foreach (MK router in this._Routers)
				{
					if (router.RouterID != empty)
					{
						list.AddRange(router.GetPortForwards());
					}
				}
				return list;
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
				return list;
			}
		}

		private string GetLoadbalancerModuleName(string LoadBalancer)
		{
			foreach (YachtRouterConfigWANMobile mobileWAN in this.mainConfig.MobileWANs)
			{
				if (mobileWAN.BondedInterface)
				{
					LoadBalancer = mobileWAN.RouterID;
				}
			}
			return LoadBalancer;
		}

		public void PortForwardDelete(string cloudPort)
		{
			try
			{
				foreach (MK router in this._Routers)
				{
					router.PortForwardDelete(cloudPort);
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void PortForwardEnableDisable(string interafaceName, string cloudPort, bool Enabled)
		{
			try
			{
				foreach (MK router in this._Routers)
				{
					router.PortForwardEnableDisable(interafaceName, cloudPort, Enabled);
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void AutoswitcherSetScript(int VesselNetwork, string newScript)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(this._mainConfig.VNs[VesselNetwork - 1].RouterID);
				routerByRouterID.SetWanInterfaceTitle("Autoswitch_VN" + VesselNetwork, newScript);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public string GetAutoswitcherSelectedScript(int VesselNetwork)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				return routerByRouterID.GetWanInterfaceTitle("Autoswitch_VN" + VesselNetwork);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return string.Empty;
		}

		public List<string> GetAutoswitcherAllScripts()
		{
			try
			{
				MK mK = this._Routers[0];
				return mK.GetAutoswitcherAllScripts();
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return new List<string>();
		}

		public bool CheckIsEnabledDisableAutoswitcher(int VesselNetwork)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID("Main");
				return routerByRouterID.CheckIsInterfaceEnabledPhysicalByInterface("Autoswitch_VN" + VesselNetwork);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return false;
		}

		public void SetCloudWanState(string interfaceName, bool newState)
		{
			try
			{
				string @interface = "vpn_" + interfaceName;
				MK routerByRouterID = this.GetRouterByRouterID(this.GetRouterIDByWanInterfaceName(interfaceName));
				routerByRouterID.EnableDisableInterfacePhysical(@interface, newState);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public bool GetCloudWanState(string interfaceName)
		{
			try
			{
				string interfaceName2 = "vpn_" + interfaceName;
				MK routerByRouterID = this.GetRouterByRouterID(this.GetRouterIDByWanInterfaceName(interfaceName));
				return routerByRouterID.CheckIsInterfaceEnabledPhysicalByInterface(interfaceName2);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return false;
		}

		public string GetCloudWanTitle(string interfaceName)
		{
			try
			{
				string @interface = "vpn_" + interfaceName;
				MK routerByRouterID = this.GetRouterByRouterID(this.GetRouterIDByWanInterfaceName(interfaceName));
				return routerByRouterID.GetWanInterfaceTitle(@interface);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return string.Empty;
		}

		public bool CheckIfCloudIsAvailable(string interfaceName)
		{
			try
			{
				string interfaceName2 = "vpn_" + interfaceName;
				MK routerByRouterID = this.GetRouterByRouterID(this.GetRouterIDByWanInterfaceName(interfaceName));
				return routerByRouterID.CheckIsInterfaceExistingPhysicalByInterface(interfaceName2);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return false;
		}

		public bool CheckIfCloudIsConnected(string interfaceName)
		{
			try
			{
				MK routerByRouterID = this.GetRouterByRouterID(this.GetRouterIDByWanInterfaceName(interfaceName));
				List<string> list = routerByRouterID.CheckYachtRouterVPNConnection("vpn_" + interfaceName);
				for (int num = list.Count - 1; num > 0; num--)
				{
					string text = yrUtils.ExtractInfo(list[num], "status=");
					if (text == null || text == "connected")
					{
						return true;
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return false;
		}

		public void ApplyPatches()
		{
			try
			{
				this._curLogger.LogMessage("Apply Patches Starting");
				if (this.IsConnectedToRouter)
				{
					MK routerByRouterID = this.GetRouterByRouterID("Main");
					bool flag = false;
					string wanInterfaceTitle = routerByRouterID.GetWanInterfaceTitle("LastPatchVersionEx");
					foreach (MK router in this._Routers)
					{
						if (yrUtils.IsUpgradeRequiredFromApplication(router.GetWanInterfaceTitle("LastPatchVersionEx"), yrEngine.curAssemblyVersion))
						{
							flag = true;
							break;
						}
					}
					this._curLogger.LogMessage("Upgrade required: " + flag);
					if (yrUtils.IsUpgradeRequiredFromApplication(routerByRouterID.GetWanInterfaceTitle("LastPatchVersionEx"), yrEngine.curAssemblyVersion) || flag)
					{
						this.FireNewInfo(" UPGRADING. PLEASE WAIT!", true, 1);
						this.FireNewInfo("PATCHING 1", true, 1);
						this.PatchApiSSLAccessOnAllComponents();
						this._curLogger.LogMessage("PATCHING SSL Access");
						this.FireNewInfo("PATCHING 2", true, 1);
						this.PatchAdditionalRulesForInternalTouchPanelSoftwareDownload(routerByRouterID);
						this._curLogger.LogMessage("PATCHING Additional Rules Access");
						this.FireNewInfo("PATCHING 3", true, 1);
						this.Patch21319113740Backbone();
						this._curLogger.LogMessage("PATCHING Backbone");
						this.FireNewInfo("PATCHING 4", true, 1);
						this.PatchSupportNetworkRoutes();
						this._curLogger.LogMessage("PATCHING Network Support");
						this.FireNewInfo("PATCHING 5", true, 1);
						this.PatchDhcpClientRebindingScripts();
						this._curLogger.LogMessage("PATCHING Client Rebinding");
						this.FireNewInfo("PATCHING 6", true, 1);
						this.PatchMobileWanRecoveryScripts();
						this._curLogger.LogMessage("PATCHING Wan Recovery");
						this.FireNewInfo("PATCHING 7", true, 1);
						this.PatchWanWifiMac();
						this._curLogger.LogMessage("PATCHING WAN Wifi Mac");
						this.FireNewInfo("PATCHING 8", true, 1);
						this.PatchRecoveryEnforceStartupScripts();
						this._curLogger.LogMessage("PATCHING Startup Scripts");
						this.FireNewInfo("PATCHING 9", true, 1);
						this.PatchBackboneDataLeak();
						this._curLogger.LogMessage("PATCHING Backbone Data Leak");
						this.FireNewInfo("PATCHING 10", true, 1);
						this.PatchForceNewAutoswitcherRules();
						this._curLogger.LogMessage("PATCHING Autoswitcher Rules");
						this.FireNewInfo("PATCHING 11", true, 1);
						int num = 1;
						foreach (MK router2 in this._Routers)
						{
							this.FireNewInfo("PATCHING 11." + num++, true, 1);
							if (router2 == routerByRouterID)
							{
								router2.CreateBridge("LastPatchVersion");
								router2.SetWanInterfaceTitle("LastPatchVersion", "3.2.0.2");
								router2.EnableDisableInterfacePhysical("LastPatchVersion", false);
							}
							router2.CreateBridge("LastPatchVersionEx");
							router2.SetWanInterfaceTitle("LastPatchVersionEx", yrEngine.curAssemblyVersion);
							router2.EnableDisableInterfacePhysical("LastPatchVersionEx", false);
						}
						this.FireNewInfo(" UPGRADE FINISHED", true, 1);
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		private string RetrieveMobileModemName(MK router, string interfaceName)
		{
			try
			{
				return router.GetMobileModemName(interfaceName);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
			return string.Empty;
		}

		public void Patch21319113740Backbone()
		{
			try
			{
				foreach (MK router in this._Routers)
				{
					router.RouteSetTargetToNew("213.191.137.40", "0.0.0.0/0", "backbone");
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void PatchSupportNetworkRoutes()
		{
			try
			{
				foreach (YachtRouterConfigWANBase allWan in this._mainConfig.GetAllWans())
				{
					MK routerByRouterID = this.GetRouterByRouterID(allWan.RouterID);
					if (routerByRouterID.RouterID != "Main")
					{
						routerByRouterID.EnsureWorkingRouteToIP("10.10.10.0/24", "10.80.0.1");
					}
					else
					{
						routerByRouterID.EnsureWorkingRouteToIP("10.10.10.0/24", "10.10.10.1");
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void PatchDhcpClientRebindingScripts()
		{
			foreach (MK router in this._Routers)
			{
				router.EnsureDhcpRecoveryScripts();
			}
		}

		public void PatchMobileWanRecoveryScripts()
		{
			try
			{
				int num = 0;
				foreach (YachtRouterConfigWANMobile mobileWAN in this._mainConfig.MobileWANs)
				{
					if (!mobileWAN.BondedInterface)
					{
						num++;
						MK routerByRouterID = this.GetRouterByRouterID(mobileWAN.RouterID);
						routerByRouterID.CreateBridge("PermitRoaming_" + mobileWAN.InterfaceName);
						routerByRouterID.EnableDisableInterfacePhysical("PermitRoaming_" + mobileWAN.InterfaceName, false);
						this.FireNewInfo("PATCHING 6." + num + ".1", true, 1);
						string mobileModemName = routerByRouterID.GetMobileModemName(mobileWAN.InterfaceName);
						string text = "AT^SYSCONFIG=16,3,0,4";
						string text2 = "ATI";
						if (mobileModemName == "ME909s-120")
						{
							text = "AT^SYSCFGEX=\\\"99\\\",3FFFFFFF,0,4,7FFFFFFFFFFFFFFF,,";
							text2 = "AT^SYSCFGEX=\\\"99\\\",3FFFFFFF,1,4,7FFFFFFFFFFFFFFF,,";
						}
						this.FireNewInfo("PATCHING 6." + num + ".2", true, 1);
						string scriptSource = ":local lteState [/int lte get " + mobileWAN.InterfaceName + " disabled]\r\n:local lteStateRoaming \"" + text2 + "\"\r\n:local lteStateRoamingRequired [/int bridge get PermitRoaming_" + mobileWAN.InterfaceName + " comment]\r\n\r\n:if ($lteStateRoamingRequired=false) do={ :set $lteStateRoaming \"" + text + "\" } else={ :set $lteStateRoaming \"" + text2 + "\" }\r\n/int lte set " + mobileWAN.InterfaceName + " modem-init=$lteStateRoaming\r\n:if ( $lteState = false ) do={\r\n:if ([/ping 8.8.8.8 interface=" + mobileWAN.InterfaceName + " count=5]>0)  do={   } else={\r\n      /int lte set 0 modem-init=\"AT+CFUN=0\"\r\n      :delay 1000ms\r\n      /int lte disable " + mobileWAN.InterfaceName + "\r\n      :delay 1000ms\r\n      /int lte enable " + mobileWAN.InterfaceName + "\r\n      :delay 1000ms\r\n      /int lte set 0 modem-init=\"AT+CFUN=1\"\r\n      :delay 1000ms\r\n      /int lte disable " + mobileWAN.InterfaceName + "\r\n      :delay 1000ms\r\n      /int lte enable " + mobileWAN.InterfaceName + "\r\n      :delay 1000ms\r\n      /int lte set 0 modem-init=$lteStateRoaming\r\n      /int lte disable " + mobileWAN.InterfaceName + "\r\n      :delay 1000ms\r\n      /int lte enable " + mobileWAN.InterfaceName + "\r\n      /log info \"Restarting " + mobileWAN.InterfaceName + " Finished\"\r\n   }\r\n}";
						if (routerByRouterID.GetIsReloadSimAvailable())
						{
							string routerModelName = routerByRouterID.GetRouterModelName();
							int num2 = mobileWAN.ReloadSimBus;
							if (mobileWAN.ReloadSimBus == 0)
							{
								num2 = 1;
							}
							if (mobileWAN.ReloadSimBus == 0 && routerModelName.Contains("922UAGS"))
							{
								num2 = 2;
							}
							scriptSource = ":local lteState [/int lte get " + mobileWAN.InterfaceName + " disabled]\r\n:if ( $lteState = false ) do={\r\n:if ([/ping 8.8.8.8 interface=" + mobileWAN.InterfaceName + " count=5]>0)  do={   } else={\r\n      /system routerboard usb power-reset bus=" + num2 + " duration=20\r\n /log info \"Restarting " + mobileWAN.InterfaceName + " Finished\"\r\n   }\r\n}";
						}
						this.FireNewInfo("PATCHING 6." + num + ".3", true, 1);
						routerByRouterID.EnsureScript("scriptRecovery_" + mobileWAN.InterfaceName, scriptSource, "schedulerRecovery_" + mobileWAN.InterfaceName, "300s", "yes", true);
						scriptSource = ":local lteState [/int lte get " + mobileWAN.InterfaceName + " disabled]\r\n:local lteStateRoaming \"" + text2 + "\"\r\n:local lteStateRoamingRequired [/int bridge get PermitRoaming_" + mobileWAN.InterfaceName + " comment]\r\n\r\n:if ($lteStateRoamingRequired=false) do={ :set $lteStateRoaming \"" + text + "\" } else={ :set $lteStateRoaming \"" + text2 + "\" }\r\n/int lte set " + mobileWAN.InterfaceName + " modem-init=$lteStateRoaming";
						routerByRouterID.EnsureScript("scriptRecovery_" + mobileWAN.InterfaceName + "_ModemInit", scriptSource, "schedulerRecovery_" + mobileWAN.InterfaceName, "300s", "yes", false);
						this.FireNewInfo("PATCHING 6." + num + ".4", true, 1);
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void PatchWanWifiMac()
		{
			try
			{
				foreach (YachtRouterConfigWANWifi wifiWAN in this._mainConfig.WifiWANs)
				{
					MK routerByRouterID = this.GetRouterByRouterID(wifiWAN.RouterID);
					routerByRouterID.UpdateMacAddressForWirelessInterfaceWithPrefix(wifiWAN.InterfaceName, "00:15:5D", "Locomarine", "japan", true);
					routerByRouterID.UpdateWIFItoAutoFrequency(wifiWAN.InterfaceName);
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void PatchRecoveryEnforceStartupScripts()
		{
			try
			{
				foreach (YachtRouterRouterConfig routerConfig in this._mainConfig.RouterConfigs)
				{
					MK routerByRouterID = this.GetRouterByRouterID(routerConfig.RouterID);
					if (routerConfig.RouterIP == "10.80.0.1")
					{
						routerByRouterID.EnsureRecoveryEnforceStartupScripts(false);
					}
					else if (routerConfig.RouterIP == "10.80.0.2")
					{
						routerByRouterID.EnsureRecoveryEnforceStartupScripts(false);
					}
					else if (routerConfig.RouterIP == "10.80.0.3")
					{
						routerByRouterID.EnsureRecoveryEnforceStartupScripts(false);
					}
					else if (!(routerConfig.RouterIP == "10.80.0.10"))
					{
						routerByRouterID.EnsureRecoveryEnforceStartupScripts(true);
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void PatchBackboneDataLeak()
		{
			try
			{
				foreach (MK router in this._Routers)
				{
					if (!router.RouterID.Contains("MobileExpanderLB"))
					{
						if (router.RouterID.Contains("MobileExpander"))
						{
							foreach (YachtRouterConfigWANMobile mobileWAN in this.mainConfig.MobileWANs)
							{
								if (mobileWAN.RouterID == router.RouterID)
								{
									router.RouteSetTargetToNewByComment(mobileWAN.InterfaceName, "backbone");
									break;
								}
							}
						}
						else
						{
							router.DeleteAllRoutes("0.0.0.0/0", "backbone");
							router.EnsureWorkingRoute("5.10.81.50", "backbone", "100");
							router.EnsureWorkingRoute("8.8.8.8", "backbone", "100");
							if (router.RouterID == "Main")
							{
								router.AdjustDNS("10.80.0.3,10.80.0.2,8.8.8.8");
							}
							else
							{
								router.AdjustDNS(string.Empty);
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void PatchAdditionalRulesForInternalTouchPanelSoftwareDownload(MK router)
		{
			try
			{
				router.CreateFirewallMangleAcceptRule("10.10.10.0/24", "Support Network Touch Panel Tunneling");
				router.CreateFirewallNatRule("sstp-out1", "Support Network Touch Panel Tunneling");
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void PatchHotspotDNSFix()
		{
		}

		public void PatchForceNewAutoswitcherRules()
		{
			try
			{
				this.UpdateVNConfiguration();
				for (int i = 0; i < this._mainConfig.VNs.Count; i++)
				{
					YachtRouterConfigWifiAP yachtRouterConfigWifiAP = this._mainConfig.VNs[i];
					if (yachtRouterConfigWifiAP.AutoswitchAvailable)
					{
						bool autoswitchEnabled = yachtRouterConfigWifiAP.AutoswitchEnabled;
						this.EnabledDisableAutoswitcher(i + 1, false);
						if (autoswitchEnabled)
						{
							this.EnabledDisableAutoswitcher(i + 1, true);
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void PatchApiSSLAccessOnAllComponents()
		{
			string identity = "YR_WIFI_EXTENDER";
			string identity2 = "YR_LAN_EXPANDER";
			try
			{
				foreach (MK router in this._Routers)
				{
					router.InitializeApiSSLAccess(false);
				}
				List<string> dhcpLeasesAndFixThem = this.GetRouterByRouterID(this.mainConfig.RouterConfigs[0].RouterID).GetDhcpLeasesAndFixThem(yrEngine.rootExtenderDHCPServer, identity);
				dhcpLeasesAndFixThem.AddRange(this.GetRouterByRouterID(this.mainConfig.RouterConfigs[0].RouterID).GetDhcpLeasesAndFixThem(yrEngine.rootExtenderDHCPServer, identity2));
				for (int i = 0; i < dhcpLeasesAndFixThem.Count; i++)
				{
					MK mK = null;
					if (this.CheckExtenderAvailability(dhcpLeasesAndFixThem[i], out mK))
					{
						mK.InitializeApiSSLAccess(false);
					}
				}
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		public void PatchApiSSLAccess(MK router)
		{
			try
			{
				router.InitializeApiSSLAccess(false);
			}
			catch (Exception ex)
			{
				this._curLogger.LogException(ex);
			}
		}

		private void ScanWANWiFiStartGetResultsSSH(object Params)
		{
			try
			{
				List<string> list = Params as List<string>;
				MK routerByRouterID = this.GetRouterByRouterID(list[0]);
				JSch jSch = new JSch();
				Session session = jSch.getSession(yrEngine.RouterConfig_Username, routerByRouterID.RouterIP, 22);
				UserInfo userInfo = new MyUserInfo(yrEngine.RouterConfig_Password);
				session.setUserInfo(userInfo);
				session.connect();
				ChannelShell channelShell = (ChannelShell)session.openChannel("shell");
				InputStream reader = channelShell.getInputStream();
				Stream outputStream = channelShell.getOutputStream();
				this.ready = false;
				List<string> curVisibleWifiNetworks = new List<string>();
				int MaxCountOfVisibleNetworks = 0;
				int nSlowDownCounter = 0;
				Thread thread = new Thread((ThreadStart)delegate
				{
					string text = string.Empty;
					string empty = string.Empty;
					while (!this.StopScanning)
					{
						byte[] array = new byte[100000];
						int num = reader.Read(array, 0, 100000);
						if (num > 0)
						{
							text += Encoding.ASCII.GetString(array, 0, num);
							if (text.IndexOf(yrEngine.RouterConfig_Username + "@") != -1)
							{
								this.ready = true;
							}
							text = text.Replace('\u001b' + string.Empty, string.Empty);
							text = text.Replace("[m", string.Empty);
							text = text.Replace("[1m", string.Empty);
							int num2 = -1;
							int length = -1;
							int num3 = -1;
							int length2 = -1;
							while (text.Length > 25 && text.IndexOf("\r\n") != -1)
							{
								empty = text.Substring(0, text.IndexOf("\r\n"));
								text = text.Substring(text.IndexOf("\r\n") + 2);
								if (empty.Contains("SSID") && empty.Contains("SNR") && num2 == -1 && num3 == -1)
								{
									num2 = empty.IndexOf("SSID");
									string text2 = empty.Substring(num2);
									int num4 = 4;
									while (num4 < text2.Length)
									{
										if (text2[num4] == ' ')
										{
											num4++;
											continue;
										}
										length = num4;
										break;
									}
									num3 = empty.IndexOf("SNR");
									text2 = empty.Substring(num3);
									int num5 = 3;
									while (num5 < text2.Length)
									{
										if (text2[num5] == ' ')
										{
											num5++;
											continue;
										}
										length2 = num5;
										break;
									}
								}
								if (empty.Length >= 25 && num2 != -1 && num3 != -1)
								{
									string text3 = empty.Substring(8, 25);
									if (text3.IndexOf(':') != text3.LastIndexOf(':'))
									{
										try
										{
											string text4 = empty.Substring(0, 7);
											string text5 = empty.Substring(num2, length).Trim();
											string text6 = empty.Substring(num3, length2).Trim();
											while (empty.IndexOf("  ") != -1)
											{
												empty = empty.Replace("  ", " ");
											}
											string[] array2 = empty.Split(' ');
											string empty2 = string.Empty;
											string empty3 = string.Empty;
											string empty4 = string.Empty;
											string empty5 = string.Empty;
											string text7 = yrUtils.encodeSSID(text5);
											string text8 = text7 + "#" + empty2 + "#" + empty3 + "#" + empty4 + "#" + empty5 + "#" + text6 + "#" + text4;
											if (!(text5 == string.Empty))
											{
												bool flag = false;
												foreach (YachtRouterConfigWifiAP vN in this.mainConfig.VNs)
												{
													if (vN.WiFiAPN == text5)
													{
														flag = true;
													}
												}
												if (!flag)
												{
													bool flag2 = false;
													for (int i = 0; i < curVisibleWifiNetworks.Count; i++)
													{
														if (curVisibleWifiNetworks[i].Split('#')[0] == text7)
														{
															curVisibleWifiNetworks[i] = text8;
															flag2 = true;
														}
													}
													if (!flag2)
													{
														curVisibleWifiNetworks.Add(text8);
													}
													if (MaxCountOfVisibleNetworks == curVisibleWifiNetworks.Count)
													{
														if (nSlowDownCounter % (curVisibleWifiNetworks.Count * 10) == 0 && !this.StopScanning)
														{
															this.FireOnStatusUpdate(RouterStatuses.WanWifiNewNetworkFound, curVisibleWifiNetworks);
														}
													}
													else
													{
														if (!this.StopScanning)
														{
															this.FireOnStatusUpdate(RouterStatuses.WanWifiNewNetworkFound, curVisibleWifiNetworks);
														}
														nSlowDownCounter = 0;
													}
													nSlowDownCounter++;
													MaxCountOfVisibleNetworks = curVisibleWifiNetworks.Count;
												}
											}
										}
										catch (Exception ex)
										{
											this._curLogger.LogException(ex);
										}
									}
								}
							}
						}
						Thread.Sleep(100);
					}
				});
				thread.Name = "SSH Scanning Thread";
				thread.IsBackground = true;
				channelShell.connect();
				Console.WriteLine("-- Shell channel is connected using the {0} cipher", session.getCipher());
				thread.Start();
				while (!channelShell.isClosed() && !this.ready)
				{
					Thread.Sleep(500);
				}
				channelShell.setPtySize(200, 100, 1200, 800);
				string s = "/int wireless scan " + list[1] + "\r\n";
				byte[] bytes = Encoding.ASCII.GetBytes(s);
				outputStream.Write(bytes, 0, bytes.Count());
				while (!this.StopScanning)
				{
					Thread.Sleep(500);
				}
				channelShell.disconnect();
				session.disconnect();
				thread.Abort();
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}
	}
}
