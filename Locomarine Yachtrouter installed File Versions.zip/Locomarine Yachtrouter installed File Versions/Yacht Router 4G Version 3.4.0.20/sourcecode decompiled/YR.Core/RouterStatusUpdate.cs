namespace YR.Core
{
	public delegate void RouterStatusUpdate(string RouterID, RouterStatuses ChangedStatus);
}
