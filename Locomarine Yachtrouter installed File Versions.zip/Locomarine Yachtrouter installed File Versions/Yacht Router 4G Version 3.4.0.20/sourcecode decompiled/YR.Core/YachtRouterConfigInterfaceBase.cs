using System;

namespace YR.Core
{
	[Serializable]
	public abstract class YachtRouterConfigInterfaceBase
	{
		private string _Name = string.Empty;

		private string _RouterID = string.Empty;

		private string _InterfaceName = string.Empty;

		private bool _IsEnabled;

		private bool _IsConfigurable = true;

		public string Name
		{
			get
			{
				return this._Name;
			}
			set
			{
				this._Name = value;
			}
		}

		public string RouterID
		{
			get
			{
				return this._RouterID;
			}
			set
			{
				this._RouterID = value;
			}
		}

		public string InterfaceName
		{
			get
			{
				return this._InterfaceName;
			}
			set
			{
				this._InterfaceName = value;
			}
		}

		public bool IsEnabled
		{
			get
			{
				return this._IsEnabled;
			}
			set
			{
				this._IsEnabled = value;
			}
		}

		public bool IsConfigurable
		{
			get
			{
				return this._IsConfigurable;
			}
			set
			{
				this._IsConfigurable = value;
			}
		}

		public bool UseDHCPClient
		{
			get;
			set;
		}

		public string DHCPClientName
		{
			get
			{
				return string.Format("{0}", this.InterfaceName);
			}
		}

		public string RouteDescription
		{
			get
			{
				return string.Format("{0}", this.InterfaceName);
			}
		}

		public string IP
		{
			get;
			set;
		}

		public string Subnet
		{
			get;
			set;
		}

		public string GatewayAddress
		{
			get;
			set;
		}

		public string DNS1Address
		{
			get;
			set;
		}

		public string DNS2Address
		{
			get;
			set;
		}
	}
}
