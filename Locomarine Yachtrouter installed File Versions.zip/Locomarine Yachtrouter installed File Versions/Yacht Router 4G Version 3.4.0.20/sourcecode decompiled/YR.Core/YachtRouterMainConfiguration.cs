using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Xml;
using System.Xml.Serialization;
using Tamir.SharpSsh.java.io;
using Tamir.SharpSsh.jsch;

namespace YR.Core
{
	[Serializable]
	public class YachtRouterMainConfiguration
	{
		private const string YACHTROUTER_DEVICE_CONFIGURATION = "\\Storage Card\\YachtRouter\\YachtRouterConfig.xml";

		private const string YACHTROUTER_DESKTOP_CONFIGURATION = ".\\YachtRouterGen3.xml";

		public List<YachtRouterRouterConfig> RouterConfigs = new List<YachtRouterRouterConfig>();

		public List<YachtRouterConfigWANLan> LanWANs = new List<YachtRouterConfigWANLan>();

		public List<YachtRouterConfigWANWifi> WifiWANs = new List<YachtRouterConfigWANWifi>();

		public List<YachtRouterConfigWANMobile> MobileWANs = new List<YachtRouterConfigWANMobile>();

		public string ApplicationBrand = "YACHT ROUTER";

		public List<YachtRouterConfigWifiAP> WifiAPs = new List<YachtRouterConfigWifiAP>();

		[XmlIgnore]
		public List<YachtRouterConfigLAN> LANs = new List<YachtRouterConfigLAN>();

		private List<YachtRouterConfigWANBase> allWans;

		public bool EnableLanWANs;

		public bool EnableLanWANsAlwaysOn;

		public bool EnableWifiWANs = true;

		public bool EnableWifiWANsAlwaysOn;

		public bool EnableMobileWANs = true;

		public bool EnableMobileWANsAlwaysOn;

		public bool EnableLans = true;

		public bool EnableWifis = true;

		public bool ShowDiagnosticInfo;

		public bool EnableStatistics;

		public bool EnableWifiExtenders;

		public int MaxNumberOfWifiExteders = 1;

		public string HighSpeedSSIDSuffix = " AC";

		public bool VesselNetworkBandwidthLimitsAvailable;

		[XmlIgnore]
		public List<YachtRouterConfigWifiAP> VNs
		{
			get
			{
				return this.WifiAPs;
			}
			set
			{
				this.WifiAPs = value;
			}
		}

		private static string GetConfigTroughSFTP()
		{
			string text = string.Empty;
			string password = yrEngine.RouterConfig_Password;
			int num = 0;
			do
			{
				try
				{
					JSch jSch = new JSch();
					Session session = jSch.getSession(yrEngine.RouterConfig_Username, "10.80.0.1", 22);
					UserInfo userInfo = new yrEngine.MyUserInfo(password);
					session.setUserInfo(userInfo);
					session.connect();
					ChannelSftp channelSftp = (ChannelSftp)session.openChannel("sftp");
					channelSftp.connect();
					using (InputStream inputStream = channelSftp.get("YachtRouterGen3.xml"))
					{
						int num2 = 20971520;
						int num3 = 0;
						byte[] array = new byte[num2];
						while (true)
						{
							int num4 = 1048576;
							byte[] array2 = new byte[num4];
							int num5 = inputStream.Read(array2, 0, num4);
							array2.CopyTo(array, num3);
							if (num5 != -1)
							{
								num3 += num5;
								continue;
							}
							break;
						}
						text += Encoding.Unicode.GetString(array, 0, num3);
						if (!text.Contains("YachtRouterMainConfiguration"))
						{
							text = Encoding.ASCII.GetString(array, 0, num3);
						}
					}
					channelSftp.disconnect();
				}
				catch (Exception ex)
				{
					if (ex.Message.Contains("error") && ex.Message.Contains("530"))
					{
						goto IL_0161;
					}
					if (ex.Message.Contains("Auth fail"))
					{
						goto IL_0161;
					}
					throw new Exception("Yacht Router Initial Connection Failed");
					IL_0161:
					if (num == yrEngine.RouterConfig_PasswordOlds.Count)
					{
						password = yrEngine.RouterConfig_Password;
						num = 0;
					}
					password = yrEngine.RouterConfig_PasswordOlds[num];
					num++;
				}
				Thread.Sleep(100);
			}
			while (text == string.Empty);
			return text;
		}

		public static bool SetConfigTroughFTP(string ConfigurationXML)
		{
			try
			{
				WebRequest webRequest = WebRequest.Create(yrEngine.RouterConfig_FtpPath);
				webRequest.Method = "STOR";
				webRequest.Credentials = new NetworkCredential(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
				webRequest.Timeout = 5000;
				byte[] bytes = Encoding.UTF8.GetBytes(ConfigurationXML);
				webRequest.ContentLength = bytes.Length;
				Stream requestStream = webRequest.GetRequestStream();
				requestStream.Write(bytes, 0, bytes.Length);
				requestStream.Close();
				WebResponse response = webRequest.GetResponse();
				response.Close();
				return true;
			}
			catch (Exception)
			{
				return false;
			}
		}

		public static Stream GetSupportInfoTroughFTP()
		{
			string empty = string.Empty;
			try
			{
				FtpRequestCreator creator = new FtpRequestCreator();
				WebRequest.RegisterPrefix("ftp:", creator);
				WebRequest webRequest = WebRequest.Create(yrEngine.RouterSupportInfo_FtpPath);
				try
				{
					webRequest.Method = "get";
				}
				catch
				{
				}
				webRequest.Timeout = 5000;
				webRequest.Credentials = new NetworkCredential(yrEngine.RouterConfig_Username, yrEngine.RouterConfig_Password);
				WebResponse response = webRequest.GetResponse();
				return response.GetResponseStream();
			}
			catch (Exception)
			{
				throw new Exception("Yacht Router Support Info Retrieve Failed");
			}
		}

		public bool LoadConfiguration(bool WorkingInDeviceMode)
		{
			string empty = string.Empty;
			try
			{
				empty = YachtRouterMainConfiguration.GetConfigTroughSFTP();
				empty = empty.Substring(empty.IndexOf('<'));
			}
			catch
			{
				return false;
			}
			XmlSerializer xmlSerializer = new XmlSerializer(base.GetType());
			XmlTextReader xmlTextReader = null;
			xmlTextReader = new XmlTextReader(new StringReader(empty));
			xmlSerializer.UnknownAttribute += this.serializer_UnknownAttribute;
			xmlSerializer.UnknownElement += this.serializer_UnknownElement;
			xmlSerializer.UnknownNode += this.serializer_UnknownNode;
			xmlSerializer.UnreferencedObject += this.serializer_UnreferencedObject;
			object newObject = xmlSerializer.Deserialize(xmlTextReader);
			this.LoadFromDeserializedObject(newObject);
			xmlTextReader.Close();
			return true;
		}

		private void serializer_UnreferencedObject(object sender, UnreferencedObjectEventArgs e)
		{
		}

		private void serializer_UnknownNode(object sender, XmlNodeEventArgs e)
		{
		}

		private void serializer_UnknownElement(object sender, XmlElementEventArgs e)
		{
		}

		private void serializer_UnknownAttribute(object sender, XmlAttributeEventArgs e)
		{
		}

		protected void LoadFromDeserializedObject(object newObject)
		{
			YachtRouterMainConfiguration yachtRouterMainConfiguration = newObject as YachtRouterMainConfiguration;
			this.RouterConfigs = yachtRouterMainConfiguration.RouterConfigs;
			this.WifiWANs = yachtRouterMainConfiguration.WifiWANs;
			this.WifiAPs = yachtRouterMainConfiguration.WifiAPs;
			this.MobileWANs = yachtRouterMainConfiguration.MobileWANs;
			this.LanWANs = yachtRouterMainConfiguration.LanWANs;
			this.LANs = yachtRouterMainConfiguration.LANs;
			this.ApplicationBrand = yachtRouterMainConfiguration.ApplicationBrand;
			this.ShowDiagnosticInfo = yachtRouterMainConfiguration.ShowDiagnosticInfo;
			this.ShowDiagnosticInfo = yachtRouterMainConfiguration.ShowDiagnosticInfo;
			this.EnableStatistics = yachtRouterMainConfiguration.EnableStatistics;
			this.MaxNumberOfWifiExteders = yachtRouterMainConfiguration.MaxNumberOfWifiExteders;
			this.HighSpeedSSIDSuffix = yachtRouterMainConfiguration.HighSpeedSSIDSuffix;
			this.VesselNetworkBandwidthLimitsAvailable = yachtRouterMainConfiguration.VesselNetworkBandwidthLimitsAvailable;
		}

		public void InitializeStaticConfig()
		{
			YachtRouterRouterConfig yachtRouterRouterConfig = new YachtRouterRouterConfig();
			yachtRouterRouterConfig.RouterID = "Main";
			yachtRouterRouterConfig.RouterIP = "10.80.0.1";
			this.RouterConfigs.Add(yachtRouterRouterConfig);
			yachtRouterRouterConfig = new YachtRouterRouterConfig();
			yachtRouterRouterConfig.RouterID = "MainLan";
			yachtRouterRouterConfig.RouterIP = "10.80.0.2";
			this.RouterConfigs.Add(yachtRouterRouterConfig);
			YachtRouterConfigWANLan yachtRouterConfigWANLan = new YachtRouterConfigWANLan();
			yachtRouterConfigWANLan.Name = "Inmarsat";
			yachtRouterConfigWANLan.RouterID = "MainLan";
			yachtRouterConfigWANLan.InterfaceName = "etherWAN1";
			yachtRouterConfigWANLan.UseDHCPClient = true;
			yachtRouterConfigWANLan.IP = "192.168.1.17";
			yachtRouterConfigWANLan.Subnet = "255.255.255.0";
			yachtRouterConfigWANLan.GatewayAddress = "192.168.1.1";
			yachtRouterConfigWANLan.DNS1Address = "8.8.8.8";
			yachtRouterConfigWANLan.DNS2Address = "8.8.4.4";
			this.LanWANs.Add(yachtRouterConfigWANLan);
			yachtRouterConfigWANLan = new YachtRouterConfigWANLan();
			yachtRouterConfigWANLan.Name = "VSat";
			yachtRouterConfigWANLan.RouterID = "MainLan";
			yachtRouterConfigWANLan.UseDHCPClient = false;
			yachtRouterConfigWANLan.InterfaceName = "etherWAN2";
			yachtRouterConfigWANLan.IP = "192.168.1.17";
			yachtRouterConfigWANLan.Subnet = "255.255.255.0";
			yachtRouterConfigWANLan.GatewayAddress = "192.168.1.1";
			yachtRouterConfigWANLan.DNS1Address = "8.8.8.8";
			yachtRouterConfigWANLan.DNS2Address = "8.8.4.4";
			this.LanWANs.Add(yachtRouterConfigWANLan);
			YachtRouterConfigWANWifi yachtRouterConfigWANWifi = new YachtRouterConfigWANWifi();
			yachtRouterConfigWANWifi.Name = "WAN Wifi to Shore 1";
			yachtRouterConfigWANWifi.RouterID = "MainLan";
			yachtRouterConfigWANWifi.UseDHCPClient = true;
			yachtRouterConfigWANWifi.InterfaceName = "wanWIFI";
			yachtRouterConfigWANWifi.WiFiSecurityProfile = "WanWifiSecProfile";
			yachtRouterConfigWANWifi.IP = "192.168.1.17";
			yachtRouterConfigWANWifi.Subnet = "255.255.255.0";
			yachtRouterConfigWANWifi.GatewayAddress = "192.168.1.1";
			yachtRouterConfigWANWifi.DNS1Address = "8.8.8.8";
			yachtRouterConfigWANWifi.DNS2Address = "8.8.4.4";
			yachtRouterConfigWANWifi.WiFiUseWep = false;
			this.WifiWANs.Add(yachtRouterConfigWANWifi);
			YachtRouterConfigWANMobile yachtRouterConfigWANMobile = new YachtRouterConfigWANMobile();
			yachtRouterConfigWANMobile.Name = "WAN Mobile1";
			yachtRouterConfigWANMobile.RouterID = "Main";
			yachtRouterConfigWANMobile.InterfaceName = "wanMobile1";
			yachtRouterConfigWANMobile.MobileNetworkAPN = "data.vip.hr";
			yachtRouterConfigWANMobile.MobileNetworkDialCommand = "Dial Command";
			yachtRouterConfigWANMobile.MobileNetworkModemInit = "Modem Init";
			yachtRouterConfigWANMobile.MobileNetworkOperator = "Operator";
			yachtRouterConfigWANMobile.MobileNetworkPassword = "Password";
			yachtRouterConfigWANMobile.MobileNetworkPhoneNumber = "38591";
			yachtRouterConfigWANMobile.MobileNetworkUsername = "Username";
			yachtRouterConfigWANMobile.MobileNetworkSIMCardPin = "1234";
			yachtRouterConfigWANMobile.DirectIP = true;
			yachtRouterConfigWANMobile.BondedInterface = false;
			this.MobileWANs.Add(yachtRouterConfigWANMobile);
			yachtRouterConfigWANMobile = new YachtRouterConfigWANMobile();
			yachtRouterConfigWANMobile.Name = "WAN Mobile2";
			yachtRouterConfigWANMobile.RouterID = "Main";
			yachtRouterConfigWANMobile.InterfaceName = "wanMobile2";
			yachtRouterConfigWANMobile.MobileNetworkAPN = "data.vip.hr";
			yachtRouterConfigWANMobile.MobileNetworkDialCommand = "Dial Command";
			yachtRouterConfigWANMobile.MobileNetworkModemInit = "Modem Init";
			yachtRouterConfigWANMobile.MobileNetworkOperator = "Operator";
			yachtRouterConfigWANMobile.MobileNetworkPassword = "Password";
			yachtRouterConfigWANMobile.MobileNetworkPhoneNumber = "38591";
			yachtRouterConfigWANMobile.MobileNetworkUsername = "Username";
			yachtRouterConfigWANMobile.MobileNetworkSIMCardPin = "1234";
			yachtRouterConfigWANMobile.NetworkMode = "auto";
			yachtRouterConfigWANMobile.DirectIP = true;
			yachtRouterConfigWANMobile.BondedInterface = false;
			this.MobileWANs.Add(yachtRouterConfigWANMobile);
			yachtRouterConfigWANMobile = new YachtRouterConfigWANMobile();
			yachtRouterConfigWANMobile.Name = "WAN Mobile Bonded";
			yachtRouterConfigWANMobile.RouterID = "Main";
			yachtRouterConfigWANMobile.InterfaceName = "wanMobile2";
			yachtRouterConfigWANMobile.MobileNetworkAPN = "data.vip.hr";
			yachtRouterConfigWANMobile.MobileNetworkDialCommand = "Dial Command";
			yachtRouterConfigWANMobile.MobileNetworkModemInit = "Modem Init";
			yachtRouterConfigWANMobile.MobileNetworkOperator = "Operator";
			yachtRouterConfigWANMobile.MobileNetworkPassword = "Password";
			yachtRouterConfigWANMobile.MobileNetworkPhoneNumber = "38591";
			yachtRouterConfigWANMobile.MobileNetworkUsername = "Username";
			yachtRouterConfigWANMobile.MobileNetworkSIMCardPin = "1234";
			yachtRouterConfigWANMobile.NetworkMode = "auto";
			yachtRouterConfigWANMobile.DirectIP = true;
			yachtRouterConfigWANMobile.BondedInterface = true;
			this.MobileWANs.Add(yachtRouterConfigWANMobile);
			YachtRouterConfigWifiAP yachtRouterConfigWifiAP = new YachtRouterConfigWifiAP();
			yachtRouterConfigWifiAP.Name = "Ship WIFI AP 1";
			yachtRouterConfigWifiAP.WiFiNumber = 0;
			yachtRouterConfigWifiAP.RouterID = "Main";
			yachtRouterConfigWifiAP.InterfaceName = "shipWIFI1";
			yachtRouterConfigWifiAP.WiFiAPN = "Ship VIP AP";
			yachtRouterConfigWifiAP.WiFiSecurityPassword = "default";
			yachtRouterConfigWifiAP.WiFiSecurityProfile = "SecurityProfileShipWifi1";
			yachtRouterConfigWifiAP.WiFiEnabled = false;
			this.WifiAPs.Add(yachtRouterConfigWifiAP);
			yachtRouterConfigWifiAP = new YachtRouterConfigWifiAP();
			yachtRouterConfigWifiAP.Name = "Ship WIFI AP 2";
			yachtRouterConfigWifiAP.WiFiNumber = 1;
			yachtRouterConfigWifiAP.RouterID = "Main";
			yachtRouterConfigWifiAP.InterfaceName = "shipWIFI2";
			yachtRouterConfigWifiAP.WiFiAPN = "Ship GUEST AP";
			yachtRouterConfigWifiAP.WiFiSecurityPassword = "default";
			yachtRouterConfigWifiAP.WiFiSecurityProfile = "SecurityProfileShipWifi2";
			yachtRouterConfigWifiAP.WiFiEnabled = false;
			this.WifiAPs.Add(yachtRouterConfigWifiAP);
			yachtRouterConfigWifiAP = new YachtRouterConfigWifiAP();
			yachtRouterConfigWifiAP.Name = "Ship WIFI AP 3";
			yachtRouterConfigWifiAP.WiFiNumber = 2;
			yachtRouterConfigWifiAP.RouterID = "Main";
			yachtRouterConfigWifiAP.InterfaceName = "shipWIFI3";
			yachtRouterConfigWifiAP.WiFiAPN = "Ship Navigation";
			yachtRouterConfigWifiAP.WiFiSecurityPassword = "default";
			yachtRouterConfigWifiAP.WiFiSecurityProfile = "SecurityProfileShipWifi3";
			yachtRouterConfigWifiAP.WiFiEnabled = true;
			this.WifiAPs.Add(yachtRouterConfigWifiAP);
		}

		public string SaveConfiguration()
		{
			XmlSerializer xmlSerializer = new XmlSerializer(base.GetType());
			StringWriter stringWriter = new StringWriter();
			xmlSerializer.Serialize(stringWriter, this);
			return stringWriter.ToString();
		}

		public List<YachtRouterConfigWANBase> GetAllWans()
		{
			if (this.allWans == null)
			{
				this.allWans = new List<YachtRouterConfigWANBase>();
				foreach (YachtRouterConfigWANLan lanWAN in this.LanWANs)
				{
					this.allWans.Add(lanWAN);
				}
				foreach (YachtRouterConfigWANMobile mobileWAN in this.MobileWANs)
				{
					this.allWans.Add(mobileWAN);
				}
				foreach (YachtRouterConfigWANWifi wifiWAN in this.WifiWANs)
				{
					this.allWans.Add(wifiWAN);
				}
			}
			return this.allWans;
		}
	}
}
