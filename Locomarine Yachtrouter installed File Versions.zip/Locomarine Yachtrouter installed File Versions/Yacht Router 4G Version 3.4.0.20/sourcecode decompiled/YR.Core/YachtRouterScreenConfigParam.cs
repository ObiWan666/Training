using System;

namespace YR.Core
{
	[Serializable]
	public class YachtRouterScreenConfigParam
	{
		public YachtRouterScreenConfigParamType ParamType = YachtRouterScreenConfigParamType.Text;

		public string Name
		{
			get;
			set;
		}

		public string Value
		{
			get;
			set;
		}

		public string Description
		{
			get;
			set;
		}

		public string MultipleOptions
		{
			get;
			set;
		}

		public object Configuration
		{
			get;
			set;
		}

		public string SetCommands
		{
			get;
			set;
		}

		public string GetCommands
		{
			get;
			set;
		}

		public YachtRouterScreenConfigParam(string Name, string Value, string Description, YachtRouterScreenConfigParamType ParamType, string MultipleOptions, string SetCommands, string GetCommands, object Configuration)
		{
			this.Name = Name;
			this.Value = Value;
			this.Description = Description;
			this.ParamType = ParamType;
			this.SetCommands = SetCommands;
			this.GetCommands = GetCommands;
			this.MultipleOptions = MultipleOptions;
			this.Configuration = Configuration;
		}
	}
}
