using System;

namespace YR.Core
{
	[Serializable]
	public class YachtRouterConfigLAN : YachtRouterConfigInterfaceBase
	{
		private string _FirewallRule = string.Empty;

		public string FirewallRule
		{
			get
			{
				return this._FirewallRule;
			}
			set
			{
				this._FirewallRule = value;
			}
		}
	}
}
