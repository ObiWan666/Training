using System;

namespace YR.Core
{
	[Serializable]
	public class YachtRouterConfigWANLan : YachtRouterConfigWANBase
	{
		public bool AlwaysOnEnabled
		{
			get;
			set;
		}

		public string AlwaysOnSSID
		{
			get;
			set;
		}

		public string AlwaysOnPassword
		{
			get;
			set;
		}
	}
}
