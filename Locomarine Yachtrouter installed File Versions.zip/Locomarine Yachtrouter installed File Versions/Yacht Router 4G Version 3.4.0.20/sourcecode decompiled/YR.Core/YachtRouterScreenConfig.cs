using System;
using System.Collections.Generic;

namespace YR.Core
{
	[Serializable]
	public class YachtRouterScreenConfig
	{
		public List<YachtRouterScreenConfigParam> allParams = new List<YachtRouterScreenConfigParam>();

		public string Name
		{
			get;
			set;
		}

		public string Description
		{
			get;
			set;
		}

		public string Type
		{
			get;
			set;
		}

		public string InterfaceName
		{
			get;
			set;
		}
	}
}
