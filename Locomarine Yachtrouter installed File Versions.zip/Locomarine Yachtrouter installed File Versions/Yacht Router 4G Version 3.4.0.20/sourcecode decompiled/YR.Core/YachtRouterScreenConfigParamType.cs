using System;

namespace YR.Core
{
	[Serializable]
	public enum YachtRouterScreenConfigParamType
	{
		ReadOnly,
		Text,
		SingleChoice,
		Number,
		NumberAllowEmpty,
		IPAddress,
		WiFiStation,
		WiFiPassowrd,
		HotspotUserList,
		MobileNetwork,
		MultipleOptionsSingleChoice,
		MultipleOptionsSingleChoiceFromConfiguration,
		MultipleOptionsSingleChoiceFromYachtRouterConfiguration
	}
}
