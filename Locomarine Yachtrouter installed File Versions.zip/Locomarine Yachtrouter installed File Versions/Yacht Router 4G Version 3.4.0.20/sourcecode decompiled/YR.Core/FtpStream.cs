using System;
using System.IO;

namespace YR.Core
{
	internal class FtpStream : Stream
	{
		private Stream m_Stream;

		private bool m_fCanRead;

		private bool m_fCanWrite;

		private bool m_fCanSeek;

		private bool m_fClosedByUser;

		public override bool CanRead
		{
			get
			{
				return this.m_fCanRead;
			}
		}

		public override bool CanWrite
		{
			get
			{
				return this.m_fCanWrite;
			}
		}

		public override bool CanSeek
		{
			get
			{
				return this.m_fCanSeek;
			}
		}

		public override long Length
		{
			get
			{
				throw new NotSupportedException("This stream cannot be seeked");
			}
		}

		public override long Position
		{
			get
			{
				throw new NotSupportedException("This stream cannot be seeked");
			}
			set
			{
				throw new NotSupportedException("This stream cannot be seeked");
			}
		}

		internal long InternalPosition
		{
			get
			{
				return this.m_Stream.Position;
			}
			set
			{
				this.m_Stream.Position = value;
			}
		}

		internal long InternalLength
		{
			get
			{
				return this.m_Stream.Length;
			}
		}

		internal FtpStream()
		{
			this.m_Stream = null;
		}

		internal FtpStream(Stream stream, bool canread, bool canwrite, bool canseek)
		{
			this.m_Stream = stream;
			this.m_fCanRead = canread;
			this.m_fCanWrite = canwrite;
			this.m_fCanSeek = canseek;
			this.m_fClosedByUser = false;
		}

		public override long Seek(long offset, SeekOrigin origin)
		{
			throw new NotSupportedException("This stream cannot be seeked");
		}

		public override void Flush()
		{
		}

		public override void SetLength(long value)
		{
			throw new NotSupportedException("This stream cannot be seeked");
		}

		public override void Close()
		{
			this.m_fClosedByUser = true;
		}

		public override void Write(byte[] buffer, int offset, int length)
		{
			if (this.m_fClosedByUser)
			{
				throw new IOException("Cannot operate on a closed stream");
			}
			this.InternalWrite(buffer, offset, length);
		}

		internal void InternalWrite(byte[] buffer, int offset, int length)
		{
			this.m_Stream.Write(buffer, offset, length);
		}

		public override int Read(byte[] buffer, int offset, int length)
		{
			if (this.m_fClosedByUser)
			{
				throw new IOException("Cannot operate on a closed stream");
			}
			return this.InternalRead(buffer, offset, length);
		}

		internal int InternalRead(byte[] buffer, int offset, int length)
		{
			return this.m_Stream.Read(buffer, offset, length);
		}

		internal void InternalClose()
		{
			this.m_Stream.Close();
		}

		internal Stream GetStream()
		{
			return this.m_Stream;
		}
	}
}
