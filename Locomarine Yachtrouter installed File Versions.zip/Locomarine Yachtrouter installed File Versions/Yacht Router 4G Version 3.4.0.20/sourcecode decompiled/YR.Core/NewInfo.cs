namespace YR.Core
{
	public delegate void NewInfo(string newInfo, bool ShowOnScreen);
}
