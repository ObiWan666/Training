namespace YR.Core
{
	public delegate void StatusUpdate(RouterStatuses ChangedStatus, object newValue);
}
