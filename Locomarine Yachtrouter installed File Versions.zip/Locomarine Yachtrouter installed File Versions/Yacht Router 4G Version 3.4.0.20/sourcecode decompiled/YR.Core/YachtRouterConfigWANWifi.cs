using System;

namespace YR.Core
{
	[Serializable]
	public class YachtRouterConfigWANWifi : YachtRouterConfigWANLan
	{
		public string WiFiAPN
		{
			get;
			set;
		}

		public string WiFiSecurityProfile
		{
			get;
			set;
		}

		public string WiFiSecurityPassword
		{
			get;
			set;
		}

		public bool WiFiUseWep
		{
			get;
			set;
		}

		public bool WIFISelectBandAvailable
		{
			get;
			set;
		}

		public string WIFISelectedBand
		{
			get;
			set;
		}

		public string WiFiWepHidden
		{
			get;
			set;
		}

		public YachtRouterConfigWANWifi()
		{
			this.WiFiWepHidden = "True";
		}
	}
}
