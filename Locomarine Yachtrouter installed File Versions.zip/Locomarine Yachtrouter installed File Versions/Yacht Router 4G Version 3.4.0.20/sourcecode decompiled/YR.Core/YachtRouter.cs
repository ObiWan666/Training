using System;
using System.Collections.Generic;
using System.Threading;
using System.Timers;
using YachtRouterEngine;

namespace YR.Core
{
	public class YachtRouter
	{
		private class HandleCommandParams
		{
			public string Command
			{
				get;
				set;
			}

			public List<string> CommandParams
			{
				get;
				set;
			}
		}

		public delegate void ExecuteJavascriptDelegate(string jsCommand, object[] args);

		private yrEngine curEngine;

		private yrLogger curLogger = new yrLogger();

		private bool curDynamicStatusUpdating = true;

		private string curPage = "lockscreen";

		private string curVN = "1";

		private string curWAN = "etherWAN1";

		private bool _SuspendUserInput;

		private System.Timers.Timer timerInfoLockBreaker;

		private System.Timers.Timer timerNoActivityLocker;

		private bool curInitialLoad = true;

		private bool firstEngineInitialization = true;

		private bool _StartEmbedded;

		private bool LockScreenNotifiedOnRouterIsAvailable;

		private string LastWanStatusUpdateRouterID = string.Empty;

		private string LastWanStatusWanInterfaceName = string.Empty;

		private bool LastWanStatusWifiAdditionalInfo;

		private bool LastWanStatusMobileAdditionalInfo;

		public bool SuspendUserInput
		{
			get
			{
				return this._SuspendUserInput;
			}
			set
			{
				try
				{
					this._SuspendUserInput = value;
					if (this._SuspendUserInput)
					{
						this.ProcessStatusUpdate(RouterStatuses.GeneralInfoMessagePleaseWaitStart, null);
					}
					else
					{
						this.ProcessStatusUpdate(RouterStatuses.GeneralInfoMessagePleaseWaitStop, null);
					}
					this.curLogger.LogMessage("SUSPEND USER INPUT: " + value);
				}
				catch (Exception ex)
				{
					this.curLogger.LogException(ex);
				}
			}
		}

		public bool StartEmbedded
		{
			get
			{
				return this._StartEmbedded;
			}
			set
			{
				this._StartEmbedded = value;
			}
		}

		public event ExecuteJavascriptDelegate OnExecuteJavascript
		{
			add
			{
				ExecuteJavascriptDelegate executeJavascriptDelegate = this.OnExecuteJavascript;
				ExecuteJavascriptDelegate executeJavascriptDelegate2;
				do
				{
					executeJavascriptDelegate2 = executeJavascriptDelegate;
					executeJavascriptDelegate = Interlocked.CompareExchange<ExecuteJavascriptDelegate>(ref this.OnExecuteJavascript, (ExecuteJavascriptDelegate)Delegate.Combine(executeJavascriptDelegate2, value), executeJavascriptDelegate);
				}
				while (executeJavascriptDelegate != executeJavascriptDelegate2);
			}
			remove
			{
				ExecuteJavascriptDelegate executeJavascriptDelegate = this.OnExecuteJavascript;
				ExecuteJavascriptDelegate executeJavascriptDelegate2;
				do
				{
					executeJavascriptDelegate2 = executeJavascriptDelegate;
					executeJavascriptDelegate = Interlocked.CompareExchange<ExecuteJavascriptDelegate>(ref this.OnExecuteJavascript, (ExecuteJavascriptDelegate)Delegate.Remove(executeJavascriptDelegate2, value), executeJavascriptDelegate);
				}
				while (executeJavascriptDelegate != executeJavascriptDelegate2);
			}
		}

		public void InitYachtRouter(bool DynamicStatusUpdating)
		{
			try
			{
				this.curLogger.LogMessage("Yacht Router Initializing");
				this.curDynamicStatusUpdating = DynamicStatusUpdating;
				this.timerInfoLockBreaker = new System.Timers.Timer(60000.0);
				this.timerInfoLockBreaker.AutoReset = false;
				this.timerInfoLockBreaker.Enabled = false;
				this.timerInfoLockBreaker.Elapsed += this.timerInfoLockBreaker_Elapsed;
				this.timerNoActivityLocker = new System.Timers.Timer(600000.0);
				this.timerNoActivityLocker.AutoReset = false;
				this.timerNoActivityLocker.Enabled = false;
				this.timerNoActivityLocker.Elapsed += this.timerNoActivityLocker_Elapsed;
				this.firstEngineInitialization = true;
				this.CreateNewEngine();
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void timerInfoLockBreaker_Elapsed(object sender, ElapsedEventArgs e)
		{
			this.SuspendUserInput = false;
		}

		private void timerNoActivityLocker_Elapsed(object sender, ElapsedEventArgs e)
		{
			this.ProcessGoToLockScreen();
		}

		private void CreateNewEngine()
		{
			if (!this.firstEngineInitialization)
			{
				this.ShutdownEngine();
			}
			this.curEngine = new yrEngine();
			this.curEngine.OnNewInfo += this.HandleOnNewInfo;
			this.curEngine.OnStatusUpdate += this.HandleOnStatusUpdate;
		}

		internal void ShutdownEngine()
		{
			if (this.curEngine != null)
			{
				this.curEngine.DestroyEngine();
				this.curEngine.OnNewInfo -= this.HandleOnNewInfo;
				this.curEngine.OnStatusUpdate -= this.HandleOnStatusUpdate;
				this.curEngine = null;
			}
			this._SuspendUserInput = false;
		}

		private void UpdateVesselNetworkConfigurations()
		{
			try
			{
				this.curLogger.LogMessage("Updating Vessel Network Info");
				while (!this.curEngine.LateConfigurationLoadFinished)
				{
					Thread.Sleep(100);
				}
				for (int i = 1; i <= this.curEngine.mainConfig.VNs.Count; i++)
				{
					this.ProcessStatusUpdate(RouterStatuses.VesselNetworkAvailable, new List<string>
					{
						i.ToString(),
						"True"
					});
					this.ProcessStatusUpdate(RouterStatuses.VesselNetworkConfigName, new List<string>
					{
						i.ToString(),
						this.curEngine.mainConfig.VNs[i - 1].Name
					});
					this.ProcessStatusUpdate(RouterStatuses.VesselNetworkConfigLans, new List<string>
					{
						i.ToString(),
						this.GetWanConfigs(this.curEngine.mainConfig.LanWANs, i, "wanselect")
					});
					this.ProcessStatusUpdate(RouterStatuses.VesselNetworkConfigMobiles, new List<string>
					{
						i.ToString(),
						this.GetWanConfigs(this.curEngine.mainConfig.MobileWANs, i, "wanselect")
					});
					this.ProcessStatusUpdate(RouterStatuses.VesselNetworkConfigWifis, new List<string>
					{
						i.ToString(),
						this.GetWanConfigs(this.curEngine.mainConfig.WifiWANs, i, "wanselect")
					});
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private static string GetStringConfigSelectAction(int vn, string curWanName, string curWanInterface, string usage, string connection)
		{
			return "{ \"title\": \"" + curWanName + "\", \"action\" : \"http://yachtrouter/#" + (1080 + vn).ToString() + "_" + curWanInterface + "\", \"usage\" : \"" + usage + "\", \"connection\" : \"" + connection + "\" },";
		}

		private static string GetStringConfigAction(string curWanName, string curWanInterface)
		{
			string empty = string.Empty;
			string text = "checking";
			return "{ \"title\": \"" + curWanName + "\", \"action\" : \"javascript:NavigateToWanSetupScreen(\\'" + curWanInterface + "\\')\", \"usage\" : \"" + empty + "\", \"connection\" : \"" + text + "\" },";
		}

		private string GetWanConfigs(object wanList, int vn, string actionType)
		{
			string text = string.Empty;
			if (wanList is List<YachtRouterConfigWANLan>)
			{
				foreach (YachtRouterConfigWANLan item in wanList as List<YachtRouterConfigWANLan>)
				{
					if (actionType == "wanselect")
					{
						text += YachtRouter.GetStringConfigSelectAction(vn, item.Name, item.InterfaceName, item.Usage, item.Connection);
					}
					if (actionType == "wanconfig")
					{
						text += YachtRouter.GetStringConfigAction(item.Name, item.InterfaceName);
					}
				}
			}
			if (wanList is List<YachtRouterConfigWANMobile>)
			{
				foreach (YachtRouterConfigWANMobile item2 in wanList as List<YachtRouterConfigWANMobile>)
				{
					if (actionType == "wanselect")
					{
						text += YachtRouter.GetStringConfigSelectAction(vn, item2.Name, item2.InterfaceName, item2.Usage, item2.Connection);
					}
					if (actionType == "wanconfig" && !item2.BondedInterface)
					{
						text += YachtRouter.GetStringConfigAction(item2.Name, item2.InterfaceName);
					}
				}
			}
			if (wanList is List<YachtRouterConfigWANWifi>)
			{
				foreach (YachtRouterConfigWANWifi item3 in wanList as List<YachtRouterConfigWANWifi>)
				{
					if (actionType == "wanselect")
					{
						text += YachtRouter.GetStringConfigSelectAction(vn, item3.Name, item3.InterfaceName, item3.Usage, item3.Connection);
					}
					if (actionType == "wanconfig")
					{
						text += YachtRouter.GetStringConfigAction(item3.Name, item3.InterfaceName);
					}
				}
			}
			text = text.TrimEnd(',');
			return '[' + text + ']';
		}

		private string GetVNsConfig(List<YachtRouterConfigWifiAP> VNs)
		{
			string text = string.Empty;
			for (int i = 0; i < VNs.Count; i++)
			{
				string text2 = text;
				text = text2 + "{ \"name\": \"" + VNs[i].Name + "\", \"vn\" : \"" + (i + 1).ToString() + "\" },";
			}
			text = text.TrimEnd(',');
			return '[' + text + ']';
		}

		private static string GetStringConfigActionWanWifis(string ssid, string signal, string locked)
		{
			return "{ \"ssid\": \"" + ssid + "\", \"locked\" : \"" + locked + "\", \"signal\" : \"" + signal + "\" },";
		}

		private string GetVisibleWifiNetworkConfigs(List<string> visibleNetworks)
		{
			string text = string.Empty;
			foreach (string visibleNetwork in visibleNetworks)
			{
				string[] array = visibleNetwork.Split('#');
				string locked = "yes";
				if (array[6].IndexOf('P') == -1)
				{
					locked = "no";
				}
				text += YachtRouter.GetStringConfigActionWanWifis(array[0], " signal: " + array[5] + " dB", locked);
			}
			text = text.TrimEnd(',');
			return '[' + text + ']';
		}

		private static string GetStringDetailesStatus(string title, string data)
		{
			return "{ \"title\": \"" + title + "\", \"data\" : \"" + data + "\" },";
		}

		private string GetDetailesStatus(List<string> detailedStatuses)
		{
			string text = string.Empty;
			foreach (string detailedStatus in detailedStatuses)
			{
				string[] array = detailedStatus.Split('#');
				text += YachtRouter.GetStringDetailesStatus(array[0], array[1]);
			}
			text = text.TrimEnd(',');
			return '[' + text + ']';
		}

		private string GetWifiExtenderJS(List<string> wifiExtenders)
		{
			string text = string.Empty;
			foreach (string wifiExtender in wifiExtenders)
			{
				text = text + "{ \"serial\": \"" + wifiExtender.Substring("YR_WIFI_EXTENDER_".Length) + "\", \"ip\" : \"\" , \"wifiEnabled\" : \"True\" },";
			}
			text = text.TrimEnd(',');
			return '[' + text + ']';
		}

		private string GetDhcpClientList(List<string[]> dhcpLeases)
		{
			string text = string.Empty;
			foreach (string[] dhcpLease in dhcpLeases)
			{
				string text2 = text;
				text = text2 + "{ \"mac\": \"" + dhcpLease[0] + "\", \"ip\" : \"" + dhcpLease[1] + "\", \"host\": \"" + dhcpLease[2] + "\", \"static\": \"" + dhcpLease[3].ToLower() + "\" },";
			}
			text = text.TrimEnd(',');
			return '[' + text + ']';
		}

		private string GetHotspotUsersJson(List<YachtRouterConfigHotspotUser> hotspotUsers)
		{
			string text = string.Empty;
			foreach (YachtRouterConfigHotspotUser hotspotUser in hotspotUsers)
			{
				string text2 = text;
				text = text2 + "{ \"name\": \"" + hotspotUser.Name + "\", \"password\" : \"" + hotspotUser.Password + "\", \"timeUsed\" : \"" + hotspotUser.UsedTimeLimit + "\", \"timeLimit\" : \"" + hotspotUser.TimeLimit + "\", \"dataUsed\" : \"" + hotspotUser.UsedByteLimit + "\", \"dataLimit\" : \"" + hotspotUser.ByteLimit + "\" },";
			}
			text = text.TrimEnd(',');
			return '[' + text + ']';
		}

		private string GetAutoswtichingScriptsJS(List<string> AutoswitchingScripts)
		{
			string text = string.Empty;
			foreach (string AutoswitchingScript in AutoswitchingScripts)
			{
				text = text + "{ \"name\": \"" + AutoswitchingScript.Substring(AutoswitchingScript.IndexOf('_') + 1) + "\" },";
			}
			text = text.TrimEnd(',');
			return '[' + text + ']';
		}

		private string GetPortForwardsJson(List<string[]> allPortForwards)
		{
			string text = string.Empty;
			List<string> list = new List<string>();
			allPortForwards.Sort(delegate(string[] x, string[] y)
			{
				if (x[0].StartsWith("vpn_") && !y[0].StartsWith("vpn_"))
				{
					return -1;
				}
				if (!x[0].StartsWith("vpn_") && y[0].StartsWith("vpn_"))
				{
					return 1;
				}
				return x[0].CompareTo(y[0]);
			});
			foreach (string[] allPortForward in allPortForwards)
			{
				if (!list.Contains(allPortForward[1]))
				{
					list.Add(allPortForward[1]);
					string text2 = text;
					text = text2 + "{  \"comment\": \"" + allPortForward[5] + "\", \"cloudPort\" : \"" + allPortForward[1] + "\", \"deviceIP\" : \"" + allPortForward[2] + "\", \"devicePort\" : \"" + allPortForward[3] + "\", \"wans\" : [";
					foreach (string[] allPortForward2 in allPortForwards)
					{
						if (allPortForward2[1] == allPortForward[1])
						{
							string empty = string.Empty;
							empty = ((!allPortForward2[0].StartsWith("vpn_")) ? this.curEngine.GetWanNameForInterface(allPortForward2[0]) : ("Cloud " + this.curEngine.GetWanNameForInterface(allPortForward2[0].Replace("vpn_", string.Empty))));
							string empty2 = string.Empty;
							empty2 = ((!(allPortForward2[4].ToLower() == "true")) ? "True" : "False");
							text2 = text;
							text = text2 + "{ \"title\" : \"" + empty + "\", \"interface\" : \"" + allPortForward2[0] + "\", \"enabled\" : \"" + empty2 + "\" }, ";
						}
					}
					text = text.TrimEnd(',', ' ');
					text += "]  }, ";
				}
			}
			text = text.TrimEnd(',', ' ');
			return '[' + text + ']';
		}

		private void UpdateVesselNetworkSingleConfig(string VesselNetwork)
		{
			try
			{
				this.curEngine.UpdateVNConfiguration();
				this.curEngine.UpdateWifiApConfiguration();
				this.curLogger.LogMessage("Updating Vessel Network Info");
				int num = Convert.ToInt16(VesselNetwork);
				this.ProcessStatusUpdate(RouterStatuses.VesselNetworkMainConfig, new List<string>
				{
					VesselNetwork,
					this.curEngine.mainConfig.VNs[num - 1].Name,
					this.curEngine.mainConfig.VNs[num - 1].WiFiAPN,
					this.curEngine.mainConfig.VNs[num - 1].WiFiSecurityPassword,
					this.curEngine.mainConfig.VNs[num - 1].WiFiEnabled.ToString(),
					this.curEngine.GetWifiExtendersPresentStatus().ToString()
				});
				List<string[]> allDhcpClients = this.curEngine.GetAllDhcpClients(num);
				this.ProcessStatusUpdate(RouterStatuses.VesselNetworkDhcpClients, new List<string>
				{
					VesselNetwork,
					this.GetDhcpClientList(allDhcpClients)
				});
				this.ProcessStatusUpdate(RouterStatuses.AutoswitchAvailable, new List<string>
				{
					this.curEngine.mainConfig.VNs[num - 1].AutoswitchAvailable.ToString()
				});
				if (this.curEngine.mainConfig.VNs[num - 1].AutoswitchAvailable)
				{
					if (this.curEngine.CheckIsEnabledDisableAutoswitcher(num))
					{
						this.ProcessStatusUpdate(RouterStatuses.AutoswitchEnabled, new List<string>
						{
							"enabled"
						});
					}
					else
					{
						this.ProcessStatusUpdate(RouterStatuses.AutoswitchEnabled, new List<string>
						{
							"disabled"
						});
					}
					this.ProcessStatusUpdate(RouterStatuses.AutoswitchSelectedScript, new List<string>
					{
						this.curEngine.GetAutoswitcherSelectedScript(num)
					});
					this.ProcessStatusUpdate(RouterStatuses.AutoswitchScripts, this.curEngine.GetAutoswitcherAllScripts());
				}
				if (this.curEngine.mainConfig.VNs[num - 1].ClientIsolationAvailable)
				{
					if (this.curEngine.GetIsolationState(num))
					{
						this.ProcessStatusUpdate(RouterStatuses.ClientIsolationEnabled, new List<string>
						{
							"enabled"
						});
					}
					else
					{
						this.ProcessStatusUpdate(RouterStatuses.ClientIsolationEnabled, new List<string>
						{
							"disabled"
						});
					}
				}
				this.ProcessStatusUpdate(RouterStatuses.ClientIsolationAvailable, new List<string>
				{
					this.curEngine.mainConfig.VNs[num - 1].ClientIsolationAvailable.ToString()
				});
				if (this.curEngine.mainConfig.VNs[num - 1].HotspotAvailable)
				{
					this.UpdateHotspotUserOnScreen(num.ToString());
					if (this.curEngine.GetIsHotspotEnabledDisabled("VN" + num))
					{
						this.ProcessStatusUpdate(RouterStatuses.HotspotEnabled, new List<string>
						{
							"enabled"
						});
					}
					else
					{
						this.ProcessStatusUpdate(RouterStatuses.HotspotEnabled, new List<string>
						{
							"disabled"
						});
					}
					this.ProcessStatusUpdate(RouterStatuses.HotspotAvailable, new List<string>
					{
						"true"
					});
				}
				else
				{
					this.ProcessStatusUpdate(RouterStatuses.HotspotAvailable, new List<string>
					{
						"false"
					});
				}
				if (this.curEngine.mainConfig.VesselNetworkBandwidthLimitsAvailable)
				{
					Dictionary<string, string> vesselNetworkBandwithControlStatus = this.curEngine.GetVesselNetworkBandwithControlStatus(num);
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"bandwithControlAvailable",
						"true"
					});
					this.ProcessStatusUpdate(RouterStatuses.VesselNetworkBandwidthLimits, new List<string>
					{
						vesselNetworkBandwithControlStatus["vesselNetworkBandwithControlLimit_TX_Enabled"],
						vesselNetworkBandwithControlStatus["vesselNetworkBandwithControlLimit_TX"],
						vesselNetworkBandwithControlStatus["vesselNetworkBandwithControlLimit_RX_Enabled"],
						vesselNetworkBandwithControlStatus["vesselNetworkBandwithControlLimit_RX"]
					});
				}
				else
				{
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"bandwithControlAvailable",
						"false"
					});
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void UpdateHotspotUserOnScreen(string vn)
		{
			try
			{
				List<YachtRouterConfigHotspotUser> hotspotUsers = this.curEngine.GetHotspotUsers("VN" + vn);
				this.ProcessStatusUpdate(RouterStatuses.HotspotUsers, new List<string>
				{
					this.GetHotspotUsersJson(hotspotUsers)
				});
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void UpdateSetupGeneralScreen()
		{
			try
			{
				this.ProcessStatusUpdate(RouterStatuses.VesselNetworkWifiPowerConfig, new List<string>
				{
					this.curEngine.GetWANOutputPower(),
					this.curEngine.GetVNOutputPower()
				});
				List<string> wifiExtenders = this.curEngine.GetWifiExtenders();
				this.ProcessStatusUpdate(RouterStatuses.RouterLockPasswordSetup, new List<string>
				{
					this.curEngine.GetYachtRouterGUIScreenPassword()
				});
				this.ProcessStatusUpdate(RouterStatuses.WifiExtenders, wifiExtenders);
				this.ProcessStatusUpdate(RouterStatuses.SoftwareVersionControl, new List<string>
				{
					this._StartEmbedded.ToString()
				});
				this.UpdatePortForwards();
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void UpdatePortForwards()
		{
			try
			{
				List<string[]> portForwards = this.curEngine.GetPortForwards();
				this.ProcessStatusUpdate(RouterStatuses.PortForwards, new List<string>
				{
					this.GetPortForwardsJson(portForwards)
				});
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void UpdateMainSetupScreen()
		{
			try
			{
				this.ProcessStatusUpdate(RouterStatuses.VesselNetworkList, new List<string>
				{
					this.GetVNsConfig(this.curEngine.mainConfig.VNs)
				});
				this.ProcessStatusUpdate(RouterStatuses.VesselNetworkConfigLans, new List<string>
				{
					"0",
					this.GetWanConfigs(this.curEngine.mainConfig.LanWANs, 0, "wanconfig")
				});
				this.ProcessStatusUpdate(RouterStatuses.VesselNetworkConfigMobiles, new List<string>
				{
					"0",
					this.GetWanConfigs(this.curEngine.mainConfig.MobileWANs, 0, "wanconfig")
				});
				this.ProcessStatusUpdate(RouterStatuses.VesselNetworkConfigWifis, new List<string>
				{
					"0",
					this.GetWanConfigs(this.curEngine.mainConfig.WifiWANs, 0, "wanconfig")
				});
				this.ProcessStatusUpdate(RouterStatuses.RemoteSupportStatus, new List<string>
				{
					this.curEngine.GetStatusOfYachtRouterSupportNetwork("sstp-out1").ToString()
				});
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void UpdateWanSetupScreen(string interfaceName)
		{
			try
			{
				this.curLogger.LogMessage("Updating Wan Setup");
				List<YachtRouterConfigWANBase> allWans = this.curEngine.mainConfig.GetAllWans();
				foreach (YachtRouterConfigWANBase item2 in allWans)
				{
					if (item2.InterfaceName == interfaceName)
					{
						this.ProcessStatusUpdate(RouterStatuses.WanNetworkConfig, new List<string>
						{
							item2.Name,
							item2.UseDHCPClient.ToString(),
							item2.IP,
							item2.Subnet,
							item2.GatewayAddress,
							item2.DNS1Address,
							item2.DNS2Address
						});
						List<string> interfaceStats = this.curEngine.GetInterfaceStats(interfaceName);
						this.ProcessStatusUpdate(RouterStatuses.WanNetworkStats, new List<string>
						{
							interfaceName,
							interfaceStats[0],
							interfaceStats[1],
							interfaceStats[2],
							interfaceStats[3]
						});
						if (item2.IsEnabled)
						{
							this.ProcessStatusUpdate(RouterStatuses.WanNetworkEnabled, new List<string>
							{
								"enabled"
							});
						}
						else
						{
							this.ProcessStatusUpdate(RouterStatuses.WanNetworkEnabled, new List<string>
							{
								"disabled"
							});
						}
						if (this.curEngine.CheckIfCloudIsAvailable(item2.InterfaceName))
						{
							this.ProcessStatusUpdate(RouterStatuses.CloudAvailable, new List<string>
							{
								"true"
							});
							if (this.curEngine.GetCloudWanState(interfaceName))
							{
								this.ProcessStatusUpdate(RouterStatuses.CloudEnabled, new List<string>
								{
									"enabled"
								});
							}
							else
							{
								this.ProcessStatusUpdate(RouterStatuses.CloudEnabled, new List<string>
								{
									"disabled"
								});
							}
							this.ProcessStatusUpdate(RouterStatuses.CloudTitle, new List<string>
							{
								this.curEngine.GetCloudWanTitle(interfaceName)
							});
							this.ProcessStatusUpdate(RouterStatuses.CloudConnected, new List<string>
							{
								this.curEngine.CheckIfCloudIsConnected(interfaceName).ToString()
							});
						}
						else
						{
							this.ProcessStatusUpdate(RouterStatuses.CloudAvailable, new List<string>
							{
								"false"
							});
						}
						if (item2 is YachtRouterConfigWANWifi)
						{
							this.curEngine.UpdateWanWifiConfiguration((YachtRouterConfigWANWifi)item2);
							this.ProcessStatusUpdate(RouterStatuses.WanWiFiAP, new List<string>
							{
								((YachtRouterConfigWANWifi)item2).WiFiAPN,
								((YachtRouterConfigWANWifi)item2).WiFiSecurityPassword,
								((YachtRouterConfigWANWifi)item2).WiFiUseWep.ToString(),
								((YachtRouterConfigWANWifi)item2).WIFISelectBandAvailable.ToString(),
								((YachtRouterConfigWANWifi)item2).WIFISelectedBand.ToString(),
								((YachtRouterConfigWANWifi)item2).WiFiWepHidden.ToString()
							});
							this.CheckInternetStatus(item2);
							this.StartWanStatusUpdate(item2.RouterID, item2.InterfaceName, true, false);
						}
						else if (item2 is YachtRouterConfigWANMobile)
						{
							this.curEngine.UpdateWanMobileConfiguration((YachtRouterConfigWANMobile)item2);
							YachtRouterConfigWANMobile yachtRouterConfigWANMobile = item2 as YachtRouterConfigWANMobile;
							string item = this.curEngine.CheckEnabledDisabledScheduler(yachtRouterConfigWANMobile.RouterID, "schedulerRecovery_" + item2.InterfaceName);
							this.ProcessStatusUpdate(RouterStatuses.WanNetworkMobileConfig, new List<string>
							{
								yachtRouterConfigWANMobile.MobileNetworkAPN,
								yachtRouterConfigWANMobile.MobileNetworkSIMCardPin,
								yachtRouterConfigWANMobile.MobileNetworkPhoneNumber,
								yachtRouterConfigWANMobile.MobileNetworkUsername,
								yachtRouterConfigWANMobile.MobileNetworkPassword,
								yachtRouterConfigWANMobile.MobileNetworkModemInit,
								yachtRouterConfigWANMobile.NetworkMode,
								item,
								yachtRouterConfigWANMobile.ReloadSimAvailable.ToString()
							});
							if (!yachtRouterConfigWANMobile.BondedInterface && yachtRouterConfigWANMobile.DirectIP)
							{
								this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
								{
									"showDhcpConfig",
									"True"
								});
							}
							if (!yachtRouterConfigWANMobile.BondedInterface && !yachtRouterConfigWANMobile.DirectIP)
							{
								this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
								{
									"showDhcpConfig",
									"False"
								});
							}
							this.CheckInternetStatus(item2);
							this.StartWanStatusUpdate(item2.RouterID, item2.InterfaceName, false, true);
						}
						else if (item2 is YachtRouterConfigWANLan)
						{
							this.CheckInternetStatus(item2);
							this.StartWanStatusUpdate(item2.RouterID, item2.InterfaceName, false, false);
						}
						if (item2.TrafficControlAwailable)
						{
							MK routerByRouterID = this.curEngine.GetRouterByRouterID(item2.RouterID);
							long num = Convert.ToInt64(routerByRouterID.GetWanInterfaceTitle("bridgeCounter_" + item2.InterfaceName + "_BootRX"));
							long num2 = Convert.ToInt64(routerByRouterID.GetWanInterfaceTitle("bridgeCounter_" + item2.InterfaceName + "_RX"));
							long num3 = Convert.ToInt64(routerByRouterID.GetWanInterfaceTitle("bridgeCounter_" + item2.InterfaceName + "_BootTX"));
							long num4 = Convert.ToInt64(routerByRouterID.GetWanInterfaceTitle("bridgeCounter_" + item2.InterfaceName + "_TX"));
							this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
							{
								"wanUsageAvailable",
								"true"
							});
							this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
							{
								"wanUsage_RX",
								(num2 + num).ToString()
							});
							this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
							{
								"wanUsage_TX",
								(num4 + num3).ToString()
							});
							this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
							{
								"wanUsageLimit",
								routerByRouterID.GetWanInterfaceTitle("bridgeCounter_" + item2.InterfaceName + "_Limit")
							});
							this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
							{
								"wanUsageWarning",
								routerByRouterID.GetWanInterfaceTitle("bridgeCounter_" + item2.InterfaceName + "_Warning")
							});
							this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
							{
								"wanUsageLastReset",
								routerByRouterID.GetWanInterfaceTitle("bridgeCounter_" + item2.InterfaceName + "_LastReset")
							});
							this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
							{
								"wanUsageLimitEnabled",
								routerByRouterID.CheckIsInterfaceEnabledPhysicalByInterface("bridgeCounter_" + item2.InterfaceName + "_Limit")
							});
							this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
							{
								"wanUsageWarningEnabled",
								routerByRouterID.CheckIsInterfaceEnabledPhysicalByInterface("bridgeCounter_" + item2.InterfaceName + "_Warning")
							});
							this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
							{
								"wanUsageAutoresetEnabled",
								routerByRouterID.CheckEnabledDisabledScheduler("scheduleScript_" + item2.InterfaceName + "_LogCounterAutoReset")
							});
						}
						else
						{
							this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
							{
								"wanUsageAvailable",
								"false"
							});
						}
						break;
					}
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void CheckInternetStatus(YachtRouterConfigWANBase wan)
		{
			try
			{
				bool flag = this.curEngine.CheckWanInternetStatus(wan);
				this.ProcessStatusUpdate(RouterStatuses.ConnectedToInternet, new List<string>
				{
					flag.ToString()
				});
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		public void HandleCommand(string Command, List<string> CommandParams)
		{
			Thread thread = new Thread(this.HandleCommandProc);
			thread.IsBackground = true;
			thread.Name = "Handle Command Back Thread";
			thread.Start(new HandleCommandParams
			{
				Command = Command,
				CommandParams = CommandParams
			});
			this.timerNoActivityLocker.Stop();
			this.timerNoActivityLocker.Start();
		}

		public void HandleCommandProc(object paramCommand)
		{
			HandleCommandParams handleCommandParams = paramCommand as HandleCommandParams;
			string command = handleCommandParams.Command;
			command = Uri.UnescapeDataString(command);
			if (!this.SuspendUserInput)
			{
				this.SuspendUserInput = true;
				this.curLogger.LogMessage("PROCESS COMMAND START: " + command);
				try
				{
					if (command.IndexOf("#108") != -1)
					{
						string[] array = command.Split('_');
						string text = array[0].Substring(array[0].IndexOf('#') + 1);
						int num = Convert.ToInt16(text) - 1080;
						string cmdInterface = array[1];
						this.RedirectVesselNetworkToWan(text, num.ToString(), cmdInterface);
					}
					else if (command.IndexOf("#SetKeepAliveMobileConnection") != -1)
					{
						string wanInterfaceName = this.curWAN;
						string newState = yrUtils.ExtractUrlParamInfo(command, "newState");
						this.ProcessSetKeepAliveMobileConnection(wanInterfaceName, newState);
					}
					else if (command.IndexOf("#ReloadSimCard") != -1)
					{
						string wanInterfaceName2 = this.curWAN;
						this.ProcessReloadSimCard(wanInterfaceName2);
					}
					else if (command.IndexOf("#SetIsolationState") != -1)
					{
						this.ProcessSetIsolationState(command);
					}
					else if (command.IndexOf("#UpdateWanBandwidthLimits") != -1)
					{
						this.ProcessUpdateWanBandwidthLimits(command);
					}
					else if (command.IndexOf("#SetWanBandwidthControlStatus") != -1)
					{
						this.ProcessSetWanBandwidthControlStatus(command);
					}
					else if (command.IndexOf("#BandwithControlManualReset") != -1)
					{
						this.ProcessBandwithControlManualReset(command);
					}
					else if (command.IndexOf("#SetVesselBandwithLimitEnabled") != -1)
					{
						this.ProcessSetVesselBandwithLimitsEnabled(command);
					}
					else if (command.IndexOf("#SetVesselBandwithLimits") != -1)
					{
						this.ProcessSetVesselBandwithLimits(command);
					}
					else if (command.IndexOf("#RecoverySetVN1WIFIPassword") != -1)
					{
						this.ProcessRecoverySetVN1WIFIPassword();
					}
					else if (command.IndexOf("#SetVN") != -1)
					{
						this.curVN = yrUtils.ExtractUrlParamInfo(command, "vn");
						this.FireExecuteJavascript("SetDocumentLocation", new object[1]
						{
							"VesselNetworkSetup.html"
						});
					}
					else if (command.IndexOf("#SetWAN") != -1)
					{
						this.curWAN = yrUtils.ExtractUrlParamInfo(command, "wan");
						this.FireExecuteJavascript("SetDocumentLocation", new object[1]
						{
							"WanSetupScreen.html"
						});
					}
					else if (command.IndexOf("#RefreshInternetStatus") != -1)
					{
						this.UpdateRefreshInternetStatus();
					}
					else if (command.IndexOf("#ResetHotspotUsageForAll") != -1)
					{
						this.curEngine.HotspotUsersAllReset("VN" + this.curVN);
						this.UpdateHotspotUserOnScreen(this.curVN);
					}
					else if (command.IndexOf("#CreateNewHotspotUser") != -1)
					{
						this.curEngine.HotspotUserAdd(yrUtils.ExtractUrlParamInfo(command, "name"), yrUtils.ExtractUrlParamInfo(command, "password"), yrUtils.ExtractUrlParamInfo(command, "days") + "d " + yrUtils.ExtractUrlParamInfo(command, "hours") + ":00:00", yrUtils.ExtractUrlParamInfo(command, "megabytes"), "VN" + this.curVN);
						this.UpdateHotspotUserOnScreen(this.curVN);
					}
					else if (command.IndexOf("#SetHotspotEnableDisable") != -1)
					{
						if (yrUtils.ExtractUrlParamInfo(command, "newState") == "enabled")
						{
							this.curEngine.HotspotEnableDisable(true, "VN" + this.curVN);
						}
						else
						{
							this.curEngine.HotspotEnableDisable(false, "VN" + this.curVN);
						}
					}
					else if (command.IndexOf("#ResetHotspotUserUsage") != -1)
					{
						this.curEngine.HotspotUserReset(yrUtils.ExtractUrlParamInfo(command, "name"), "VN" + this.curVN);
					}
					else if (command.IndexOf("#DeleteHotspotUser") != -1)
					{
						this.curEngine.HotspotUserDelete(yrUtils.ExtractUrlParamInfo(command, "name"), "VN" + this.curVN);
					}
					else if (command.IndexOf("#ConnectToSupportNetwork") != -1)
					{
						this.curEngine.ConnectToYachtRouterSupportNetwork("sstp-out1", this.curEngine.ResolveYachtRouterSupportIP(), true);
						this.ProcessStatusUpdate(RouterStatuses.RemoteSupportStatus, new List<string>
						{
							this.curEngine.GetStatusOfYachtRouterSupportNetwork("sstp-out1").ToString()
						});
					}
					else if (command.IndexOf("#DisconnectFromSupportNetwork") != -1)
					{
						this.curEngine.ConnectToYachtRouterSupportNetwork("sstp-out1", this.curEngine.ResolveYachtRouterSupportIP(), false);
						this.ProcessStatusUpdate(RouterStatuses.RemoteSupportStatus, new List<string>
						{
							this.curEngine.GetStatusOfYachtRouterSupportNetwork("sstp-out1").ToString()
						});
					}
					else if (command.IndexOf("#SetWanEnabledState") != -1)
					{
						this.ProcessSetWanEnabledState(command);
					}
					else if (command.IndexOf("#SetVesselNetworkPasswordAndPower") != -1)
					{
						this.curEngine.SetYachtRouterGUIScreenPassword(yrUtils.ExtractUrlParamInfo(command, "password"));
						this.curEngine.SetWANOutputPower(yrUtils.ExtractUrlParamInfo(command, "power"));
						this.curEngine.SetVNOutputPower(yrUtils.ExtractUrlParamInfo(command, "powerVN"));
					}
					else if (command.IndexOf("#DhcpLeaseDelete") != -1)
					{
						this.curEngine.DhcpLeaseDelete(yrUtils.ExtractUrlParamInfo(command, "ip"));
					}
					else if (command.IndexOf("#DhcpLeaseMakeStatic") != -1)
					{
						this.curEngine.DhcpLeaseMakeStatic(yrUtils.ExtractUrlParamInfo(command, "ip"));
					}
					else if (command.IndexOf("#RefreshDhcpIpAddress") != -1)
					{
						this.ProcessRefreeshDhcpIpAddress();
					}
					else if (command.IndexOf("#RenewDhcpIpAddress") != -1)
					{
						this.ProcessRenewDhcpIpAddress();
					}
					else if (command.IndexOf("#ReconfigureWifiExtenders") != -1)
					{
						this.curEngine.ReconfigureExtenderSubsystem();
						this.FireExecuteJavascript("SetDocumentLocation", new object[1]
						{
							"default.html"
						});
					}
					else if (command.IndexOf("#ResetConfigToFactoryDefaults") != -1)
					{
						this.curEngine.RouterConfigurationRestore("LocoDefaults");
						this.ProcessGoToLockScreen();
					}
					else if (command.IndexOf("#ResetConfigToUserConfiguration") != -1)
					{
						this.curEngine.RouterConfigurationRestore("UserConfig");
						this.ProcessGoToLockScreen();
					}
					else if (command.IndexOf("#SaveUserConfiguration") != -1)
					{
						this.curEngine.RouterConfigurationBackup("UserConfig");
						this.FireExecuteJavascript("SetDocumentLocation", new object[1]
						{
							"default.html"
						});
					}
					else if (command.IndexOf("#SetVesselNetworkWifiState") != -1)
					{
						this.ProcessSetVesselNetworkWifiState(command);
					}
					else if (command.IndexOf("#SetMobileNetworkMode") != -1)
					{
						this.PauseWanStatusUpdate();
						this.ProcessUpdateMobileNetworkMode(command);
						this.ContinueWanStatusUpdate();
					}
					else if (command.IndexOf("#UpdateMobileConfig") != -1)
					{
						this.PauseWanStatusUpdate();
						this.ProcessUpdateMobileConfig(command);
						this.ContinueWanStatusUpdate();
					}
					else if (command.IndexOf("#SetVesselNetworkMainConfig") != -1)
					{
						this.ProcessSetVesselNetworkMainConfig(command);
					}
					else if (command.IndexOf("#ResetUsage") == -1)
					{
						if (command.IndexOf("#SetDhcpState") != -1)
						{
							this.ProcessSetWanInterfaceIpDhcpAnGateway(command);
						}
						else if (command.IndexOf("#SetWanInterfaceName") != -1)
						{
							this.ProcessSetWanInterfaceName(command);
						}
						else if (command.IndexOf("#SetWIFIBand") != -1)
						{
							this.PauseWanStatusUpdate();
							this.ProcessSetWIFIBand(command);
							this.ContinueWanStatusUpdate();
						}
						else if (command.IndexOf("#StartScanning") != -1)
						{
							this.StartContinuousWifiScan(this.curEngine.mainConfig.WifiWANs[0].RouterID, this.curEngine.mainConfig.WifiWANs[0].InterfaceName);
						}
						else if (command.IndexOf("#StopScanning") != -1)
						{
							this.StopContinuousWifiScan();
						}
						else if (command.IndexOf("#SetWepState") != -1)
						{
							this.PauseWanStatusUpdate();
							this.ProcessSetWepState(command);
							this.ContinueWanStatusUpdate();
						}
						else if (command.IndexOf("#WanConfigConnectToWifiNetwork") != -1)
						{
							this.ProcessWanConfigConnectToWifiNetwork(command);
						}
						else if (command.IndexOf("#loadConfigs") != -1)
						{
							this.UpdateVesselNetworkConfigurations();
						}
						else if (command.IndexOf("#UpdateSoftware") != -1)
						{
							this.curEngine.ConnectToYachtRouterSupportNetwork("sstp-out1", this.curEngine.ResolveYachtRouterSupportIP(), true);
							Thread.Sleep(5000);
							yrUpgrader yrUpgrader = new yrUpgrader();
							yrUpgrader.NewInfo += this.curUpgrader_NewInfo;
							yrUpgrader.CheckIsWebUpdateAvailable();
						}
						else if (command.IndexOf("#ResetSoftwareToUserConfiguration") != -1)
						{
							yrUpgrader yrUpgrader2 = new yrUpgrader();
							yrUpgrader2.NewInfo += this.curUpgrader_NewInfo;
							yrUpgrader2.RestoreToPreviousVersion();
						}
						else if (command.IndexOf("#ResetSoftwareToFactoryDefaults") != -1)
						{
							yrUpgrader yrUpgrader3 = new yrUpgrader();
							yrUpgrader3.NewInfo += this.curUpgrader_NewInfo;
							yrUpgrader3.RestoreToFactoryDefaultsVersion();
						}
						else if (command.IndexOf("#AddPortForward") != -1)
						{
							this.ProcessAddPortForward(command);
						}
						else if (command.IndexOf("#SetPortForwardState") != -1)
						{
							string cloudPort = yrUtils.ExtractUrlParamInfo(command, "cloudPort");
							string text2 = yrUtils.ExtractUrlParamInfo(command, "newState");
							string interafaceName = yrUtils.ExtractUrlParamInfo(command, "interface");
							if (text2.ToLower() == "enable")
							{
								this.curEngine.PortForwardEnableDisable(interafaceName, cloudPort, true);
							}
							else
							{
								this.curEngine.PortForwardEnableDisable(interafaceName, cloudPort, false);
							}
							this.UpdatePortForwards();
						}
						else if (command.IndexOf("#DeletePortForward") != -1)
						{
							string cloudPort2 = yrUtils.ExtractUrlParamInfo(command, "cloudPort");
							this.curEngine.PortForwardDelete(cloudPort2);
							this.UpdatePortForwards();
						}
						else if (command.IndexOf("#SelectAutoswitchScript") != -1)
						{
							string value = this.curVN;
							string newScript = yrUtils.ExtractUrlParamInfo(command, "newScript");
							int vesselNetwork = Convert.ToInt16(value);
							this.curEngine.AutoswitcherSetScript(vesselNetwork, newScript);
						}
						else if (command.IndexOf("#SetAutoswitchingState") != -1)
						{
							string value2 = this.curVN;
							string text3 = yrUtils.ExtractUrlParamInfo(command, "newState");
							int vesselNetwork2 = Convert.ToInt16(value2);
							if (text3.ToLower() == "enabled")
							{
								this.curEngine.EnabledDisableAutoswitcher(vesselNetwork2, true);
							}
							else
							{
								this.curEngine.EnabledDisableAutoswitcher(vesselNetwork2, false);
							}
						}
						else if (command.IndexOf("#SetCloudState") != -1)
						{
							string interfaceName = this.curWAN;
							string a = yrUtils.ExtractUrlParamInfo(command, "newState");
							if (a == "enabled")
							{
								this.curEngine.SetCloudWanState(interfaceName, true);
							}
							else
							{
								this.curEngine.SetCloudWanState(interfaceName, false);
							}
						}
						else if (command.IndexOf("#GoToLockScreen") != -1)
						{
							this.ProcessGoToLockScreen();
						}
						else if (command.IndexOf("UpdateConfiguration") != -1)
						{
							this.ProcessChangePage(handleCommandParams.CommandParams, true);
						}
					}
				}
				catch (Exception ex)
				{
					this.curLogger.LogException(ex);
				}
				finally
				{
					this.curLogger.LogMessage("PROCESS COMMAND STOP: " + command);
					this.SuspendUserInput = false;
				}
			}
		}

		private void ProcessSetIsolationState(string Command)
		{
			try
			{
				string text = this.curWAN;
				string a = yrUtils.ExtractUrlParamInfo(Command, "status");
				bool newStatus = false;
				if (a == "enabled")
				{
					newStatus = true;
				}
				this.curEngine.SetIsolationState(this.curVN, newStatus);
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessUpdateWanBandwidthLimits(string Command)
		{
			try
			{
				string interfaceName = this.curWAN;
				string wanUsageWarning = yrUtils.ExtractUrlParamInfo(Command, "UsageWarning");
				string wanUsageLimit = yrUtils.ExtractUrlParamInfo(Command, "UsageLimit");
				this.curEngine.SetBandwithControlLimits(interfaceName, wanUsageLimit, wanUsageWarning);
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessSetWanBandwidthControlStatus(string Command)
		{
			try
			{
				string text = this.curWAN;
				string a = yrUtils.ExtractUrlParamInfo(Command, "ControlType");
				string text2 = yrUtils.ExtractUrlParamInfo(Command, "Status");
				bool newState = false;
				bool.TryParse(text2, out newState);
				foreach (YachtRouterConfigWANBase allWan in this.curEngine.mainConfig.GetAllWans())
				{
					if (allWan.InterfaceName == text)
					{
						if (a == "wanUsageAutoresetEnabled")
						{
							this.curEngine.EnableDisableSchedulers(allWan.RouterID, "scheduleScript_" + text + "_LogCounterAutoReset", text2);
						}
						else if (a == "wanUsageLimitEnabled")
						{
							this.curEngine.GetRouterByRouterID(allWan.RouterID).EnableDisableInterfacePhysical("bridgeCounter_" + text + "_Limit", newState);
						}
						else if (a == "wanUsageWarningEnabled")
						{
							this.curEngine.GetRouterByRouterID(allWan.RouterID).EnableDisableInterfacePhysical("bridgeCounter_" + text + "_Warning", newState);
						}
						break;
					}
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessBandwithControlManualReset(string Command)
		{
			try
			{
				string text = this.curWAN;
				this.curEngine.BandwithControlManualReset(text);
				foreach (YachtRouterConfigWANBase allWan in this.curEngine.mainConfig.GetAllWans())
				{
					if (allWan.InterfaceName == text)
					{
						MK routerByRouterID = this.curEngine.GetRouterByRouterID(allWan.RouterID);
						this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
						{
							"wanUsageLastReset",
							routerByRouterID.GetWanInterfaceTitle("bridgeCounter_" + allWan.InterfaceName + "_LastReset")
						});
					}
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessSetVesselBandwithLimitsEnabled(string Command)
		{
			try
			{
				string text = this.curWAN;
				string text2 = yrUtils.ExtractUrlParamInfo(Command, "band");
				string value = this.curVN;
				int vesselNetwork = Convert.ToInt16(value);
				string direction = yrUtils.ExtractUrlParamInfo(Command, "direction");
				bool newStatus = Convert.ToBoolean(yrUtils.ExtractUrlParamInfo(Command, "status"));
				this.curEngine.SetVesselNetworkBandwithControlEnabledStatus(vesselNetwork, direction, newStatus);
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessSetVesselBandwithLimits(string Command)
		{
			try
			{
				string text = this.curWAN;
				string text2 = yrUtils.ExtractUrlParamInfo(Command, "band");
				string value = this.curVN;
				int vesselNetwork = Convert.ToInt16(value);
				int tXLimit = Convert.ToInt32(yrUtils.ExtractUrlParamInfo(Command, "bandwithTXLimit"));
				int rXLimit = Convert.ToInt32(yrUtils.ExtractUrlParamInfo(Command, "bandwithRXLimit"));
				this.curEngine.SetVesselNetworkBandwithControlLimits(vesselNetwork, tXLimit, rXLimit);
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessSetWIFIBand(string Command)
		{
			try
			{
				string text = this.curWAN;
				string text2 = yrUtils.ExtractUrlParamInfo(Command, "band");
				foreach (YachtRouterConfigWANWifi wifiWAN in this.curEngine.mainConfig.WifiWANs)
				{
					if (wifiWAN.InterfaceName == text)
					{
						wifiWAN.WIFISelectedBand = text2;
						this.curEngine.SetInterfaceBand(wifiWAN.RouterID, text, text2);
						break;
					}
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessGoToLockScreen()
		{
			try
			{
				if (!this.curEngine.ShowDiagnosticInfo)
				{
					this.FireExecuteJavascript("SetDocumentLocation", new object[1]
					{
						"LockScreen.html"
					});
				}
				else
				{
					this.FireExecuteJavascript("SetDocumentLocation", new object[1]
					{
						"diagnostics.html"
					});
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessReloadSimCard(string wanInterfaceName)
		{
			this.PauseWanStatusUpdate();
			try
			{
				foreach (YachtRouterConfigWANMobile mobileWAN in this.curEngine.mainConfig.MobileWANs)
				{
					if (mobileWAN.InterfaceName == wanInterfaceName)
					{
						MK routerByRouterID = this.curEngine.GetRouterByRouterID(mobileWAN.RouterID);
						routerByRouterID.ProcessReloadSimCard(wanInterfaceName, mobileWAN.ReloadSimBus);
						break;
					}
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
			finally
			{
				try
				{
					this.ContinueWanStatusUpdate();
				}
				catch (Exception ex2)
				{
					this.curLogger.LogException(ex2);
				}
				this.UpdateRefreshInternetStatus();
			}
		}

		private void ProcessSetKeepAliveMobileConnection(string wanInterfaceName, string newState)
		{
			this.PauseWanStatusUpdate();
			try
			{
				foreach (YachtRouterConfigWANMobile mobileWAN in this.curEngine.mainConfig.MobileWANs)
				{
					if (mobileWAN.InterfaceName == wanInterfaceName)
					{
						MK routerByRouterID = this.curEngine.GetRouterByRouterID(mobileWAN.RouterID);
						routerByRouterID.EnableDisableSchedulers("schedulerRecovery_" + wanInterfaceName, newState);
						break;
					}
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
			finally
			{
				try
				{
					this.ContinueWanStatusUpdate();
				}
				catch (Exception ex2)
				{
					this.curLogger.LogException(ex2);
				}
			}
		}

		private void UpdateRefreshInternetStatus()
		{
			this.PauseWanStatusUpdate();
			foreach (YachtRouterConfigWANBase allWan in this.curEngine.mainConfig.GetAllWans())
			{
				if (allWan.InterfaceName == this.curWAN)
				{
					bool flag = this.curEngine.CheckWanInternetStatus(allWan);
					this.ProcessStatusUpdate(RouterStatuses.ConnectedToInternet, new List<string>
					{
						flag.ToString()
					});
				}
			}
			this.ProcessStatusUpdate(RouterStatuses.CloudConnected, new List<string>
			{
				this.curEngine.CheckIfCloudIsConnected(this.curWAN).ToString()
			});
		}

		private void ProcessRenewDhcpIpAddress()
		{
			this.PauseWanStatusUpdate();
			try
			{
				this.curEngine.DhcpClientRenew(this.curWAN);
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
			finally
			{
				try
				{
					this.ContinueWanStatusUpdate();
				}
				catch (Exception ex2)
				{
					this.curLogger.LogException(ex2);
				}
			}
		}

		private void ProcessRefreeshDhcpIpAddress()
		{
			try
			{
				this.PauseWanStatusUpdate();
				foreach (YachtRouterConfigWANBase allWan in this.curEngine.mainConfig.GetAllWans())
				{
					if (allWan.InterfaceName == this.curWAN)
					{
						if (allWan is YachtRouterConfigWANWifi)
						{
							this.curEngine.UpdateWanWifiConfiguration((YachtRouterConfigWANWifi)allWan);
						}
						else if (allWan is YachtRouterConfigWANMobile)
						{
							this.curEngine.UpdateWanMobileConfiguration((YachtRouterConfigWANMobile)allWan);
						}
						else if (allWan is YachtRouterConfigWANLan)
						{
							this.curEngine.UpdateWanSatConfiguration((YachtRouterConfigWANLan)allWan);
						}
						this.ProcessStatusUpdate(RouterStatuses.WanNetworkConfig, new List<string>
						{
							allWan.Name,
							allWan.UseDHCPClient.ToString(),
							allWan.IP,
							allWan.Subnet,
							allWan.GatewayAddress,
							allWan.DNS1Address,
							allWan.DNS2Address
						});
						break;
					}
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
			finally
			{
				try
				{
					this.ContinueWanStatusUpdate();
				}
				catch (Exception ex2)
				{
					this.curLogger.LogException(ex2);
				}
			}
		}

		private void curUpgrader_NewInfo(string newInfo, bool ShowOnScreen)
		{
			this.ProcessStatusUpdate(RouterStatuses.GeneralInfoMessage, new List<string>
			{
				newInfo
			});
		}

		private void ProcessSetWepState(string Command)
		{
			try
			{
				string text = this.curWAN;
				string a = yrUtils.ExtractUrlParamInfo(Command, "newState").ToLower();
				bool flag = false;
				if (a == "true")
				{
					flag = true;
				}
				this.curEngine.UpdateWanWifiConfigurationForAllWans();
				foreach (YachtRouterConfigWANWifi wifiWAN in this.curEngine.mainConfig.WifiWANs)
				{
					if (wifiWAN.InterfaceName == text)
					{
						if (wifiWAN.WiFiUseWep != flag)
						{
							wifiWAN.WiFiUseWep = flag;
							wifiWAN.WiFiSecurityPassword = yrUtils.ExtractUrlParamInfo(Command, "password");
							this.curEngine.SetWanWifiConfiguration(text, wifiWAN);
						}
						break;
					}
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessChangePage(List<string> CommandParams, bool ForceChangeOverUserLock = false)
		{
			try
			{
				string text = CommandParams[0].Substring(CommandParams[0].LastIndexOf('/') + 1).ToLower();
				text = text.Substring(0, text.IndexOf('.'));
				if (text == "diagnostics")
				{
					this.curEngine.mainConfig.ApplicationBrand = "SHIP ROUTER";
				}
				if (!string.IsNullOrEmpty(this.curEngine.mainConfig.ApplicationBrand) && (text == "lockscreen" || text == "default" || text == "diagnostics"))
				{
					this.FireExecuteJavascript("$('meta[property=originalTitle]').attr('content', '" + this.curEngine.mainConfig.ApplicationBrand + "');", new object[0]);
				}
				this.FireExecuteJavascript("$('meta[property=appBrand]').attr('content', '" + this.curEngine.mainConfig.ApplicationBrand + "');", new object[0]);
				if (!(this.curPage == "contactusscreen") || !(text == "lockscreen") || CommandParams[0].IndexOf("BackFromTheContactUs") != -1)
				{
					if (this.curPage == "lockscreen" && this.curPage == text)
					{
						Thread.Sleep(5000);
					}
					this.curPage = text;
					this.StopContinuousWifiScan();
					this.StopWanStatusUpdatePermanently();
					this.curEngine.PerformDiagnostics = false;
					this.curLogger.LogMessage("Change Screen: " + this.curPage);
					string text2 = this.curPage;
					if (text2 != null)
					{
						if (YachtRouter._003C_003Ef__switch_0024map2 == null)
						{
							Dictionary<string, int> dictionary = new Dictionary<string, int>(8);
							dictionary.Add("lockscreen", 0);
							dictionary.Add("contactusscreen", 1);
							dictionary.Add("default", 2);
							dictionary.Add("vesselnetworksetup", 3);
							dictionary.Add("mainsetupscreen", 4);
							dictionary.Add("setupgeneral", 5);
							dictionary.Add("wansetupscreen", 6);
							dictionary.Add("diagnostics", 7);
							YachtRouter._003C_003Ef__switch_0024map2 = dictionary;
						}
						int num = default(int);
						if (YachtRouter._003C_003Ef__switch_0024map2.TryGetValue(text2, out num))
						{
							switch (num)
							{
							case 1:
								break;
							case 0:
								this.timerNoActivityLocker.Stop();
								if (!this.firstEngineInitialization)
								{
									this.CreateNewEngine();
								}
								this.firstEngineInitialization = false;
								this.curEngine.SuspendUpdates = true;
								this.LockScreenNotifiedOnRouterIsAvailable = false;
								if (!this.curEngine.IsConnectedToRouter)
								{
									this.curEngine.InitEngine(false, this.curInitialLoad, false);
									this.curInitialLoad = false;
								}
								this.CheckAndShowLockPassword(false);
								this.CheckIfWanWifiIsMissing();
								break;
							case 2:
								this.curEngine.SuspendUpdates = false;
								this.UpdateVesselNetworkConfigurations();
								break;
							case 3:
								this.UpdateVesselNetworkSingleConfig(this.curVN);
								this.curEngine.SuspendUpdatesQuiet();
								break;
							case 4:
								this.UpdateMainSetupScreen();
								this.curEngine.SuspendUpdatesQuiet();
								break;
							case 5:
								this.UpdateSetupGeneralScreen();
								this.curEngine.SuspendUpdatesQuiet();
								break;
							case 6:
							{
								string text3 = this.curWAN;
								foreach (YachtRouterConfigWANBase allWan in this.curEngine.mainConfig.GetAllWans())
								{
									if (allWan.InterfaceName == text3)
									{
										if (allWan is YachtRouterConfigWANWifi)
										{
											this.curEngine.UpdateWanWifiConfiguration((YachtRouterConfigWANWifi)allWan);
											break;
										}
										if (allWan is YachtRouterConfigWANMobile)
										{
											this.curEngine.UpdateWanMobileConfiguration((YachtRouterConfigWANMobile)allWan);
											break;
										}
										if (allWan is YachtRouterConfigWANLan)
										{
											this.curEngine.UpdateWanSatConfiguration((YachtRouterConfigWANLan)allWan);
											break;
										}
									}
								}
								this.UpdateWanSetupScreen(text3);
								this.curEngine.SuspendUpdatesQuiet();
								break;
							}
							case 7:
								this.InitDiagnostics();
								break;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void InitDiagnostics()
		{
			try
			{
				if (this.curEngine == null)
				{
					this.CreateNewEngine();
				}
				this.curEngine.SuspendUpdates = true;
				this.LockScreenNotifiedOnRouterIsAvailable = false;
				if (!this.curEngine.IsConnectedToRouter)
				{
					this.curEngine.InitEngine(false, this.curInitialLoad, false);
					this.curInitialLoad = false;
				}
				this.curEngine.PerformDiagnostics = true;
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void CheckIfWanWifiIsMissing()
		{
			try
			{
				if (this.curEngine.CheckIfWanWifiIsMissing())
				{
					this.CheckAndShowLockPassword(true);
					this.ProcessStatusUpdate(RouterStatuses.RouterMissingWanWifi, null);
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void CheckIfMobilExpanderIsMissing()
		{
			try
			{
				if (this.curEngine.CheckIfMobileExpanderIsMissing())
				{
					this.ProcessStatusUpdate(RouterStatuses.RouterMissingMobileExpander, null);
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void CheckAndShowLockPassword(bool overrideConnectionCheckForWifiMissingState = false)
		{
			try
			{
				if (this.curEngine.IsConnectedToRouter || overrideConnectionCheckForWifiMissingState)
				{
					string yachtRouterGUIScreenPassword = this.curEngine.GetYachtRouterGUIScreenPassword();
					this.ProcessStatusUpdate(RouterStatuses.RouterLockPassword, new List<string>
					{
						yachtRouterGUIScreenPassword
					});
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessSetVesselNetworkWifiState(string Command)
		{
			try
			{
				string value = this.curVN;
				string text = yrUtils.ExtractUrlParamInfo(Command, "newState");
				int vesselNetwork = Convert.ToInt16(value);
				if (text.ToLower() == "enabled")
				{
					this.curEngine.EnabledDisableVNWifi(vesselNetwork, true);
				}
				else
				{
					this.curEngine.EnabledDisableVNWifi(vesselNetwork, false);
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessUpdateMobileNetworkMode(string Command)
		{
			try
			{
				string text = this.curWAN;
				string networkMode = yrUtils.ExtractUrlParamInfo(Command, "newMode");
				foreach (YachtRouterConfigWANMobile mobileWAN in this.curEngine.mainConfig.MobileWANs)
				{
					if (mobileWAN.InterfaceName == text)
					{
						mobileWAN.NetworkMode = networkMode;
						this.curEngine.SetWanMobileConfiguration(text, mobileWAN, false);
						break;
					}
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessUpdateMobileConfig(string Command)
		{
			try
			{
				string text = this.curWAN;
				string mobileNetworkAPN = yrUtils.ExtractUrlParamInfo(Command, "apn");
				string mobileNetworkSIMCardPin = yrUtils.ExtractUrlParamInfo(Command, "pin");
				string mobileNetworkUsername = yrUtils.ExtractUrlParamInfo(Command, "user");
				string mobileNetworkPassword = yrUtils.ExtractUrlParamInfo(Command, "password");
				string mobileNetworkPhoneNumber = yrUtils.ExtractUrlParamInfo(Command, "phone");
				string text2 = yrUtils.ExtractUrlParamInfo(Command, "modeminit");
				foreach (YachtRouterConfigWANMobile mobileWAN in this.curEngine.mainConfig.MobileWANs)
				{
					if (mobileWAN.InterfaceName == text)
					{
						mobileWAN.MobileNetworkAPN = mobileNetworkAPN;
						mobileWAN.MobileNetworkSIMCardPin = mobileNetworkSIMCardPin;
						mobileWAN.MobileNetworkUsername = mobileNetworkUsername;
						mobileWAN.MobileNetworkPassword = mobileNetworkPassword;
						mobileWAN.MobileNetworkPhoneNumber = mobileNetworkPhoneNumber;
						bool isRecycleNeeded = false;
						if (mobileWAN.MobileNetworkModemInit != text2)
						{
							isRecycleNeeded = true;
						}
						mobileWAN.MobileNetworkModemInit = text2;
						this.curEngine.SetWanMobileConfiguration(text, mobileWAN, isRecycleNeeded);
						break;
					}
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessSetVesselNetworkMainConfig(string Command)
		{
			try
			{
				string name = yrUtils.ExtractUrlParamInfo(Command, "name");
				string text = yrUtils.ExtractUrlParamInfo(Command, "ssid");
				string text2 = yrUtils.ExtractUrlParamInfo(Command, "password");
				string value = this.curVN;
				int num = Convert.ToInt16(value);
				bool changeSSID = false;
				bool changePassowrd = false;
				YachtRouterConfigWifiAP yachtRouterConfigWifiAP = this.curEngine.mainConfig.VNs[num - 1];
				yachtRouterConfigWifiAP.Name = name;
				if (yachtRouterConfigWifiAP.WiFiAPN != text)
				{
					changeSSID = true;
				}
				yachtRouterConfigWifiAP.WiFiAPN = text;
				if (yachtRouterConfigWifiAP.WiFiSecurityPassword != text2)
				{
					changePassowrd = true;
				}
				yachtRouterConfigWifiAP.WiFiSecurityPassword = text2;
				this.curEngine.SetWifiApConfiguration(num - 1, yachtRouterConfigWifiAP, changeSSID, changePassowrd);
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessRecoverySetVN1WIFIPassword()
		{
			try
			{
				YachtRouterConfigWifiAP yachtRouterConfigWifiAP = this.curEngine.mainConfig.VNs[0];
				yachtRouterConfigWifiAP.WiFiSecurityPassword = "12345678";
				this.curEngine.SetWifiApConfiguration(0, yachtRouterConfigWifiAP, false, true);
				this.FireExecuteJavascript("SetDocumentLocation", new object[1]
				{
					"LockScreen.html"
				});
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessAddPortForward(string Command)
		{
			try
			{
				string ip = yrUtils.ExtractUrlParamInfo(Command, "ip");
				string devicePort = yrUtils.ExtractUrlParamInfo(Command, "DevicePort");
				string cloudPort = yrUtils.ExtractUrlParamInfo(Command, "CloudPort");
				string cloudPortComment = yrUtils.ExtractUrlParamInfo(Command, "CloudPortComment");
				this.curEngine.AddPortForward(ip, devicePort, cloudPort, cloudPortComment);
				if (this.curPage == "setupgeneral")
				{
					this.ProcessChangePage(new List<string>
					{
						"YRHTML/setupgeneral.html"
					}, false);
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessWanConfigConnectToWifiNetwork(string Command)
		{
			this.PauseWanStatusUpdate();
			try
			{
				string text = Command.Substring(Command.IndexOf("ssid") + 5);
				text = text.Substring(0, text.IndexOf("&password"));
				string wiFiSecurityPassword = yrUtils.ExtractUrlParamInfo(Command, "password");
				string a = yrUtils.ExtractUrlParamInfo(Command, "usewep").ToLower();
				bool wiFiUseWep = false;
				if (a == "true")
				{
					wiFiUseWep = true;
				}
				this.curEngine.UpdateWanWifiConfigurationForAllWans();
				foreach (YachtRouterConfigWANWifi wifiWAN in this.curEngine.mainConfig.WifiWANs)
				{
					if (wifiWAN.InterfaceName == this.curWAN)
					{
						YachtRouterConfigWANWifi yachtRouterConfigWANWifi = wifiWAN;
						yachtRouterConfigWANWifi.WiFiAPN = text;
						yachtRouterConfigWANWifi.WiFiSecurityPassword = wiFiSecurityPassword;
						yachtRouterConfigWANWifi.WiFiUseWep = wiFiUseWep;
						this.curEngine.SetWanWifiConfiguration(yachtRouterConfigWANWifi.InterfaceName, yachtRouterConfigWANWifi);
					}
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
			finally
			{
				this.ContinueWanStatusUpdate();
			}
		}

		private void ProcessSetWanInterfaceIpDhcpAnGateway(string Command)
		{
			this.PauseWanStatusUpdate();
			try
			{
				string text = this.curWAN;
				string ip = yrUtils.ExtractUrlParamInfo(Command, "ip");
				string subnet = yrUtils.ExtractUrlParamInfo(Command, "subnet");
				string gateway = yrUtils.ExtractUrlParamInfo(Command, "gateway");
				string dns = yrUtils.ExtractUrlParamInfo(Command, "dns1");
				string dns2 = yrUtils.ExtractUrlParamInfo(Command, "dns2");
				bool useDhcpClient = true;
				if (yrUtils.ExtractUrlParamInfo(Command, "newDhcpState") == "disabled")
				{
					useDhcpClient = false;
				}
				this.curEngine.SetIpAndDhcp(text, ip, subnet, gateway, dns, dns2, useDhcpClient);
				foreach (YachtRouterConfigWANBase allWan in this.curEngine.mainConfig.GetAllWans())
				{
					if (allWan.InterfaceName == text)
					{
						if (allWan is YachtRouterConfigWANWifi)
						{
							this.curEngine.UpdateWanWifiConfiguration((YachtRouterConfigWANWifi)allWan);
						}
						else if (allWan is YachtRouterConfigWANMobile)
						{
							this.curEngine.UpdateWanMobileConfiguration((YachtRouterConfigWANMobile)allWan);
						}
						else if (allWan is YachtRouterConfigWANLan)
						{
							this.curEngine.UpdateWanSatConfiguration((YachtRouterConfigWANLan)allWan);
						}
						break;
					}
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
			finally
			{
				try
				{
					this.ContinueWanStatusUpdate();
				}
				catch (Exception ex2)
				{
					this.curLogger.LogException(ex2);
				}
			}
		}

		private void ProcessSetWanInterfaceName(string Command)
		{
			this.PauseWanStatusUpdate();
			try
			{
				string b = this.curWAN;
				string name = yrUtils.ExtractUrlParamInfo(Command, "wanInterfaceName");
				foreach (YachtRouterConfigWANBase allWan in this.curEngine.mainConfig.GetAllWans())
				{
					if (allWan.InterfaceName == b)
					{
						if (allWan is YachtRouterConfigWANWifi)
						{
							this.curEngine.UpdateWanWifiConfiguration((YachtRouterConfigWANWifi)allWan);
							allWan.Name = name;
							this.curEngine.SetWanWifiConfiguration(allWan.InterfaceName, allWan as YachtRouterConfigWANWifi);
						}
						else if (allWan is YachtRouterConfigWANMobile)
						{
							this.curEngine.UpdateWanMobileConfiguration((YachtRouterConfigWANMobile)allWan);
							allWan.Name = name;
							this.curEngine.SetWanMobileConfiguration(allWan.InterfaceName, allWan as YachtRouterConfigWANMobile, false);
						}
						else if (allWan is YachtRouterConfigWANLan)
						{
							this.curEngine.UpdateWanSatConfiguration((YachtRouterConfigWANLan)allWan);
							allWan.Name = name;
							this.curEngine.SetWanSatConfiguration(allWan.InterfaceName, allWan as YachtRouterConfigWANLan);
						}
						break;
					}
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
			finally
			{
				this.ContinueWanStatusUpdate();
			}
		}

		private void ProcessSetWanEnabledState(string Command)
		{
			this.PauseWanStatusUpdate();
			try
			{
				string wanInterfaceName = this.curWAN;
				string a = yrUtils.ExtractUrlParamInfo(Command, "newState");
				if (a == "enabled")
				{
					this.curEngine.EnabledDisableWan(wanInterfaceName, true);
				}
				else
				{
					this.curEngine.EnabledDisableWan(wanInterfaceName, false);
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
			finally
			{
				this.ContinueWanStatusUpdate();
			}
		}

		private void ProcessStatusUpdate(RouterStatuses StatusUpdateType, List<string> StatusParams)
		{
			try
			{
				switch (StatusUpdateType)
				{
				case RouterStatuses.MobileNetworkOperator:
				case RouterStatuses.MobileNetworkType:
				case RouterStatuses.MobileNetworkSignalStrength:
				case RouterStatuses.MobileSimCardNotPresent:
				case RouterStatuses.MobilePinError:
				case RouterStatuses.MobilePukError:
				case RouterStatuses.MobilePinOk:
				case RouterStatuses.WanSatTitle:
				case RouterStatuses.WanWiFiSignalStrength:
				case RouterStatuses.ShipWiFiAP_1:
				case RouterStatuses.ShipWiFiAP_2:
				case RouterStatuses.PleaseWaitMessage:
				case RouterStatuses.DebugInfoMessage:
				case RouterStatuses.DiagnosticsVesselNetworkInfo:
				case RouterStatuses.DiagnosticsVesselNetworkSelectedWanInfo:
				case RouterStatuses.DiagnosticsAlarms:
					break;
				case RouterStatuses.DiagnosticsStarted:
					this.FireExecuteJavascript("$('meta[property=originalTitle]').attr('content', '" + this.curEngine.mainConfig.ApplicationBrand + "');", new object[0]);
					this.FireExecuteJavascript("SetGeneralInfoMessage", new object[1]
					{
						"PLEASE WAIT END"
					});
					break;
				case RouterStatuses.CloudConnected:
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"cloudConnected",
						StatusParams[0]
					});
					break;
				case RouterStatuses.CloudAvailable:
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"cloudAvailable",
						StatusParams[0]
					});
					break;
				case RouterStatuses.CloudEnabled:
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"cloudEnabled",
						StatusParams[0]
					});
					break;
				case RouterStatuses.CloudTitle:
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"cloudTitle",
						StatusParams[0]
					});
					break;
				case RouterStatuses.AutoswitchAvailable:
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"autoswtichingAvailable",
						StatusParams[0]
					});
					break;
				case RouterStatuses.VesselNetworkBandwidthLimits:
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"bandwithTXEnabled",
						StatusParams[0]
					});
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"bandwithTXLimit",
						StatusParams[1]
					});
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"bandwithRXEnabled",
						StatusParams[2]
					});
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"bandwithRXLimit",
						StatusParams[3]
					});
					break;
				case RouterStatuses.ClientIsolationAvailable:
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"isolationAvailable",
						StatusParams[0]
					});
					break;
				case RouterStatuses.ClientIsolationEnabled:
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"isolationEnabled",
						StatusParams[0]
					});
					break;
				case RouterStatuses.AutoswitchEnabled:
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"autoswtichingEnabled",
						StatusParams[0]
					});
					break;
				case RouterStatuses.AutoswitchSelectedScript:
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"autoswtichingSelectedScript",
						StatusParams[0]
					});
					break;
				case RouterStatuses.AutoswitchScripts:
					this.FireExecuteJavascript("SetVesselNetworkModelArray", new object[2]
					{
						"autoswitchingScript",
						this.GetAutoswtichingScriptsJS(StatusParams)
					});
					break;
				case RouterStatuses.PortForwards:
					this.FireExecuteJavascript("SetSetupScreenDataArray", new object[2]
					{
						"portForwards",
						StatusParams[0]
					});
					break;
				case RouterStatuses.RemoteSupportStatus:
					this.FireExecuteJavascript("ShowRemoteSupportStatus", new object[1]
					{
						StatusParams[0]
					});
					break;
				case RouterStatuses.VesselNetworkWifiPowerConfig:
					this.FireExecuteJavascript("SetSetupScreenDataSingle", new object[2]
					{
						"wifiPower",
						StatusParams[0]
					});
					this.FireExecuteJavascript("SetSetupScreenDataSingle", new object[2]
					{
						"wifiPowerVN",
						StatusParams[1]
					});
					break;
				case RouterStatuses.RouterLockPasswordSetup:
					this.FireExecuteJavascript("SetSetupScreenDataSingle", new object[2]
					{
						"password",
						StatusParams[0]
					});
					break;
				case RouterStatuses.WifiExtenders:
					this.FireExecuteJavascript("SetSetupScreenDataArray", new object[2]
					{
						"wifiextenders",
						this.GetWifiExtenderJS(StatusParams)
					});
					break;
				case RouterStatuses.RouterMissingWanWifi:
					this.FireExecuteJavascript("SetLockScreenSingle", new object[2]
					{
						"routerConnected",
						"WanWifiMissing"
					});
					break;
				case RouterStatuses.RouterMissingMobileExpander:
					this.FireExecuteJavascript("SetLockScreenSingle", new object[2]
					{
						"routerConnected",
						"MobileExpanderMissing"
					});
					break;
				case RouterStatuses.RouterMissing:
					this.ProcessRouterMissing();
					break;
				case RouterStatuses.RouterLockPassword:
					this.FireExecuteJavascript("SetLockScreenSingle", new object[2]
					{
						"lockPassword",
						StatusParams[0]
					});
					break;
				case RouterStatuses.ConnectedToRouter:
					if (this.curPage == "lockscreen" && !this.LockScreenNotifiedOnRouterIsAvailable)
					{
						this.CheckAndShowLockPassword(false);
						this.FireExecuteJavascript("SetLockScreenSingle", new object[2]
						{
							"routerConnected",
							StatusParams[0]
						});
						this.LockScreenNotifiedOnRouterIsAvailable = true;
					}
					break;
				case RouterStatuses.VesselNetworkList:
					this.FireExecuteJavascript("SetVesselNetworksVNsArray", new object[2]
					{
						"vesselNetworks",
						StatusParams[0]
					});
					break;
				case RouterStatuses.MobileStatus:
					this.FireExecuteJavascript("SetWanStatisticsConfigDataSingle", new object[2]
					{
						"modemstatus",
						StatusParams[0]
					});
					break;
				case RouterStatuses.MobileDetailedStatus:
					this.FireExecuteJavascript("SetWanStatisticsConfigDataArray", new object[2]
					{
						"detailedStatusMobile",
						this.GetDetailesStatus(StatusParams)
					});
					break;
				case RouterStatuses.WanNetworkMobileConfig:
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"apn",
						StatusParams[0]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"pin",
						StatusParams[1]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"phone",
						StatusParams[2]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"user",
						StatusParams[3]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"password",
						StatusParams[4]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"modeminit",
						StatusParams[5]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"networkMode",
						StatusParams[6]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"keepalive",
						StatusParams[7]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"reloadsimavailable",
						StatusParams[8]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"showMobileConfig",
						"True"
					});
					break;
				case RouterStatuses.HotspotUsers:
					this.FireExecuteJavascript("SetVesselNetworkModelArray", new object[2]
					{
						"hotspotUsers",
						StatusParams[0]
					});
					break;
				case RouterStatuses.HotspotAvailable:
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"hotspot_available",
						StatusParams[0]
					});
					break;
				case RouterStatuses.HotspotEnabled:
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"hotspot_enabled",
						StatusParams[0]
					});
					break;
				case RouterStatuses.VesselNetworkDhcpClients:
					this.FireExecuteJavascript("SetVesselNetworkModelArray", new object[2]
					{
						"dhcpClients",
						StatusParams[1]
					});
					break;
				case RouterStatuses.VesselNetworkMainConfig:
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"interface",
						StatusParams[0]
					});
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"name",
						StatusParams[1]
					});
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"wifi_ssid",
						StatusParams[2]
					});
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"wifi_password",
						StatusParams[3]
					});
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"wifi_enabled",
						StatusParams[4].ToLower()
					});
					this.FireExecuteJavascript("SetVesselNetworkModelSingle", new object[2]
					{
						"lanCableWarning",
						StatusParams[5].ToLower()
					});
					break;
				case RouterStatuses.VesselNetworkAvailable:
					this.FireExecuteJavascript("SetVesselNetworkDataSingle", new object[3]
					{
						StatusParams[0],
						"available",
						StatusParams[1]
					});
					break;
				case RouterStatuses.VesselNetworkWAN:
					this.FireExecuteJavascript("SetVesselNetworkDataSingle", new object[3]
					{
						StatusParams[0],
						"selectedWan",
						StatusParams[1]
					});
					break;
				case RouterStatuses.VesselNetworkWANStatus:
					this.UpdateVesselNetworkConfigurations();
					this.FireExecuteJavascript("SetVesselNetworkDataSingle", new object[3]
					{
						StatusParams[0],
						"internetAvailable",
						StatusParams[1]
					});
					break;
				case RouterStatuses.VesselNetworkConfigLans:
					this.FireExecuteJavascript("SetVesselNetworkDataArray", new object[3]
					{
						StatusParams[0],
						"lanWans",
						StatusParams[1]
					});
					break;
				case RouterStatuses.VesselNetworkConfigMobiles:
					this.FireExecuteJavascript("SetVesselNetworkDataArray", new object[3]
					{
						StatusParams[0],
						"mobileWans",
						StatusParams[1]
					});
					break;
				case RouterStatuses.VesselNetworkConfigWifis:
					this.FireExecuteJavascript("SetVesselNetworkDataArray", new object[3]
					{
						StatusParams[0],
						"wifiWans",
						StatusParams[1]
					});
					break;
				case RouterStatuses.VesselNetworkConfigName:
					this.FireExecuteJavascript("SetVesselNetworkDataSingle", new object[3]
					{
						StatusParams[0],
						"name",
						StatusParams[1]
					});
					break;
				case RouterStatuses.WanNetworkEnabled:
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"enabled",
						StatusParams[0]
					});
					break;
				case RouterStatuses.ConnectedToInternet:
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"internetAvailable",
						StatusParams[0]
					});
					break;
				case RouterStatuses.WanNetworkConfig:
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"name",
						StatusParams[0]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"dhcp_enabled",
						StatusParams[1]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"ip",
						StatusParams[2]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"subnet",
						StatusParams[3]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"gateway",
						StatusParams[4]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"dns1",
						StatusParams[5]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"dns2",
						StatusParams[6]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"dhcpChecking",
						"False"
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"showDhcpConfig",
						"True"
					});
					break;
				case RouterStatuses.WanWiFiAP:
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"showWifiScan",
						"True"
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"showDhcpConfig",
						"True"
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"wanwifinetworkssid",
						yrUtils.encodeSSID(StatusParams[0])
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"wanwifinetworkpassword",
						StatusParams[1]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"wanwifinetworkusewep",
						StatusParams[2]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"wanwifiselectbandavailable",
						StatusParams[3]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"wanwifiselectedband",
						StatusParams[4]
					});
					this.FireExecuteJavascript("SetWanConfigDataSingle", new object[2]
					{
						"wanwifiwephidden",
						StatusParams[5]
					});
					break;
				case RouterStatuses.WanNetworkStats:
					this.FireExecuteJavascript("SetWanStatisticsConfigDataSingle", new object[2]
					{
						"BytesReceived",
						StatusParams[1]
					});
					this.FireExecuteJavascript("SetWanStatisticsConfigDataSingle", new object[2]
					{
						"BytesSent",
						StatusParams[2]
					});
					this.FireExecuteJavascript("SetWanStatisticsConfigDataSingle", new object[2]
					{
						"CurrentDownloadSpeed",
						StatusParams[3]
					});
					this.FireExecuteJavascript("SetWanStatisticsConfigDataSingle", new object[2]
					{
						"CurrentUploadSpeed",
						StatusParams[4]
					});
					break;
				case RouterStatuses.WanWifiNewNetworkFound:
					this.FireExecuteJavascript("SetWanStatisticsConfigDataArray", new object[2]
					{
						"visibleWanWifiNetworks",
						this.GetVisibleWifiNetworkConfigs(StatusParams)
					});
					break;
				case RouterStatuses.WanWifiConnectedStatus:
					this.FireExecuteJavascript("SetWanStatisticsConfigDataSingle", new object[2]
					{
						"status",
						StatusParams[0]
					});
					break;
				case RouterStatuses.WanNetworkDhcpStatus:
					this.FireExecuteJavascript("SetWanStatisticsConfigDataSingle", new object[2]
					{
						"dhcpStatus",
						StatusParams[0]
					});
					break;
				case RouterStatuses.WanWifiConnectedDetailedStatus:
					this.FireExecuteJavascript("SetWanStatisticsConfigDataArray", new object[2]
					{
						"detailedStatus",
						this.GetDetailesStatus(StatusParams)
					});
					break;
				case RouterStatuses.GeneralInfoMessage:
					this.FireExecuteJavascript("SetGeneralInfoMessage", new object[1]
					{
						StatusParams[0]
					});
					this.timerInfoLockBreaker.Stop();
					this.timerInfoLockBreaker.Start();
					break;
				case RouterStatuses.GeneralInfoMessagePleaseWaitStart:
					this.FireExecuteJavascript("SetGeneralInfoMessage", new object[1]
					{
						"PLEASE WAIT START"
					});
					this.timerInfoLockBreaker.Start();
					break;
				case RouterStatuses.GeneralInfoMessagePleaseWaitStop:
					this.FireExecuteJavascript("SetGeneralInfoMessage", new object[1]
					{
						"PLEASE WAIT END"
					});
					this.timerInfoLockBreaker.Stop();
					break;
				case RouterStatuses.SoftwareVersionControl:
					this.FireExecuteJavascript("SetSoftwareVersionControlVisibility", new object[1]
					{
						StatusParams[0]
					});
					break;
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessStatusUpdateFromDictionaries(RouterStatuses StatusUpdateType, Dictionary<string, Dictionary<string, string>> StatusDictParams)
		{
			try
			{
				switch (StatusUpdateType)
				{
				case RouterStatuses.DiagnosticsVesselNetworkInfo:
					foreach (string key in StatusDictParams.Keys)
					{
						foreach (string key2 in StatusDictParams[key].Keys)
						{
							this.FireExecuteJavascript("SetDiagnosticsVesselNetworkDataSingle", new object[3]
							{
								key,
								key2,
								StatusDictParams[key][key2]
							});
						}
					}
					break;
				case RouterStatuses.DiagnosticsVesselNetworkSelectedWanInfo:
					foreach (string key3 in StatusDictParams.Keys)
					{
						foreach (string key4 in StatusDictParams[key3].Keys)
						{
							this.FireExecuteJavascript("SetDiagnosticsVesselNetworkDataSingle", new object[3]
							{
								key3,
								key4,
								StatusDictParams[key3][key4]
							});
						}
						this.FireExecuteJavascript("AddSelectedWanBandwithChartData", new object[4]
						{
							key3.ToString(),
							StatusDictParams[key3]["selectedWanBandwith_TX"],
							StatusDictParams[key3]["selectedWanBandwith_RX"],
							string.Empty
						});
					}
					break;
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void ProcessRouterMissing()
		{
			try
			{
				if (this.curPage != "contactusscreen" && this.curPage != "help")
				{
					this.LockScreenNotifiedOnRouterIsAvailable = false;
					this.ProcessGoToLockScreen();
				}
				if (this.curEngine.CheckIfWanWifiIsMissing())
				{
					this.ProcessStatusUpdate(RouterStatuses.RouterMissingWanWifi, null);
				}
				if (this.curEngine.CheckIfMobileExpanderIsMissing())
				{
					this.ProcessStatusUpdate(RouterStatuses.RouterMissingMobileExpander, null);
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void UpdateWanDhcpAndIpData(bool newDhcpState, string ip, string subnet, string gateway, string dns1, string dns2, YachtRouterConfigWANBase curWan)
		{
			try
			{
				curWan.UseDHCPClient = newDhcpState;
				curWan.IP = ip;
				curWan.Subnet = subnet;
				curWan.GatewayAddress = gateway;
				curWan.DNS1Address = dns1;
				curWan.DNS2Address = dns2;
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void RedirectVesselNetworkToWan(string VesselNetwork, string VesselNetworkId, string cmdInterface)
		{
			try
			{
				this.ProcessStatusUpdate(RouterStatuses.VesselNetworkWAN, new List<string>
				{
					VesselNetworkId.ToString(),
					this.curEngine.GetWanNameForInterface(cmdInterface)
				});
				this.ProcessStatusUpdate(RouterStatuses.VesselNetworkWANStatus, new List<string>
				{
					VesselNetworkId.ToString(),
					"checking"
				});
				this.curEngine.SuspendUpdates = true;
				this.curEngine.RedirectVesselNetworkToWan(VesselNetwork, cmdInterface);
				this.curEngine.SuspendUpdates = false;
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void HandleOnStatusUpdate(RouterStatuses ChangedStatus, object newValue)
		{
			try
			{
				if (newValue is List<string> || newValue == null)
				{
					this.ProcessStatusUpdate(ChangedStatus, newValue as List<string>);
				}
				if (newValue is Dictionary<string, Dictionary<string, string>>)
				{
					this.ProcessStatusUpdateFromDictionaries(ChangedStatus, newValue as Dictionary<string, Dictionary<string, string>>);
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void HandleOnNewInfo(string newInfo, bool ShowOnScreen)
		{
			try
			{
				if (ShowOnScreen)
				{
					this.ProcessStatusUpdate(RouterStatuses.GeneralInfoMessage, new List<string>
					{
						newInfo
					});
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		public void StartContinuousWifiScan(string RouterID, string WanWifiInterfaceName)
		{
			this.PauseWanStatusUpdate();
			this.curEngine.StartScanWANWiFi(RouterID, WanWifiInterfaceName);
		}

		public void StopContinuousWifiScan()
		{
			try
			{
				if (this.curEngine != null)
				{
					this.curEngine.StopScanWANWiFi();
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		public void ContinueWanStatusUpdate()
		{
			try
			{
				if (this.LastWanStatusUpdateRouterID != string.Empty && this.LastWanStatusWanInterfaceName != string.Empty)
				{
					this.StartWanStatusUpdate(this.LastWanStatusUpdateRouterID, this.LastWanStatusWanInterfaceName, this.LastWanStatusWifiAdditionalInfo, this.LastWanStatusMobileAdditionalInfo);
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		public void StartWanStatusUpdate(string RouterID, string WanInterfaceName, bool WifiAdditionalInfo, bool MobileAdditionalInfo)
		{
			try
			{
				this.LastWanStatusUpdateRouterID = RouterID;
				this.LastWanStatusWanInterfaceName = WanInterfaceName;
				this.LastWanStatusWifiAdditionalInfo = WifiAdditionalInfo;
				this.LastWanStatusMobileAdditionalInfo = MobileAdditionalInfo;
				this.curEngine.StartWanStatusUpdate(RouterID, WanInterfaceName, WifiAdditionalInfo, MobileAdditionalInfo, this.curDynamicStatusUpdating);
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		public void PauseWanStatusUpdate()
		{
			try
			{
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		public void StopWanStatusUpdatePermanently()
		{
			try
			{
				if (this.curEngine != null)
				{
					this.curEngine.StopWanStatusUpdate();
				}
				this.LastWanStatusUpdateRouterID = string.Empty;
				this.LastWanStatusWanInterfaceName = string.Empty;
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}

		private void FireExecuteJavascript(string jsCommand, object[] args)
		{
			try
			{
				if (this.OnExecuteJavascript != null)
				{
					this.OnExecuteJavascript(jsCommand, args);
				}
			}
			catch (Exception ex)
			{
				this.curLogger.LogException(ex);
			}
		}
	}
}
