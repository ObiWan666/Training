namespace YachtRouterEngine
{
	public delegate void NewInfo(string newInfo, bool ShowOnScreen);
}
