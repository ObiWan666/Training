using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Threading;

namespace YachtRouterEngine
{
	public class yrUpgrader
	{
		public const string YACHTROUTER_EXECUTER_PATH = "YachtRouterExecuter4G\\YachtRouterExecuter.exe";

		public const string YACHTROUTER_CURRENT_VERSION_EXECUTER = "C:\\Locomarine\\YachtRouter4G\\YachtRouter.exe";

		public const string YACHTROUTER_CURRENT_VERSION = "C:\\Locomarine\\YachtRouter4G";

		public const string YACHTROUTER_FACTORYDEFAULTS_VERSION = "C:\\Locomarine\\YachtRouterRepository4G\\YachtRouterFactoryDefaults";

		public const string YACHTROUTER_PREVIOUS_VERSION = "C:\\Locomarine\\YachtRouterRepository4G\\YachtRouterPrevious";

		public const string YACHTROUTER_FUTURE_VERSION_STORAGE = "C:\\Locomarine\\YachtRouterRepository4G\\YachtRouterFuture";

		public const string YACHTROUTER_FUTURE_VERSION_USB = "YachtRouterFuture4G";

		public const string YACHTROUTER_WEB_UPDATES_URL = "http://www.yachtrouter.com/updates/4g/updatelistce.txt";

		public event NewInfo NewInfo
		{
			add
			{
				NewInfo newInfo = this.NewInfo;
				NewInfo newInfo2;
				do
				{
					newInfo2 = newInfo;
					newInfo = Interlocked.CompareExchange<NewInfo>(ref this.NewInfo, (NewInfo)Delegate.Combine(newInfo2, value), newInfo);
				}
				while (newInfo != newInfo2);
			}
			remove
			{
				NewInfo newInfo = this.NewInfo;
				NewInfo newInfo2;
				do
				{
					newInfo2 = newInfo;
					newInfo = Interlocked.CompareExchange<NewInfo>(ref this.NewInfo, (NewInfo)Delegate.Remove(newInfo2, value), newInfo);
				}
				while (newInfo != newInfo2);
			}
		}

		private void ShowStatus(string newInfo, bool SleepAfterMessage)
		{
			if (this.NewInfo != null)
			{
				this.NewInfo(newInfo, true);
			}
			if (SleepAfterMessage)
			{
				Thread.Sleep(2000);
			}
		}

		public bool CheckAndExecuteYachtRouterExecuterIfPresent()
		{
			try
			{
				string str = this.RetrieveDrive("YachtRouterExecuter4G\\YachtRouterExecuter.exe", true);
				if (File.Exists(str + "YachtRouterExecuter4G\\YachtRouterExecuter.exe"))
				{
					Process.Start(str + "YachtRouterExecuter4G\\YachtRouterExecuter.exe", " /StartEmbedded");
					return true;
				}
			}
			catch
			{
			}
			return false;
		}

		public bool CheckForUpgradeAndUpgradeIfNeeded(string UpgradeVersion, bool DeleteFutureFiles, bool CheckAnyDrive)
		{
			try
			{
				string empty = string.Empty;
				if (CheckAnyDrive)
				{
					empty = this.RetrieveDrive(UpgradeVersion, false);
					UpgradeVersion = empty + UpgradeVersion;
				}
				if (Directory.Exists(UpgradeVersion))
				{
					string[] files = Directory.GetFiles(UpgradeVersion);
					if (files.Count() > 0)
					{
						this.ShowStatus("Upgrade version detected preforming upgrade", true);
						if (!this.CheckFutureVersionForConsistency(UpgradeVersion))
						{
							return false;
						}
						this.ShowStatus("Upgrade in progress", true);
						if (Directory.Exists("C:\\Locomarine\\YachtRouterRepository4G\\YachtRouterPrevious"))
						{
							string[] files2 = Directory.GetFiles("C:\\Locomarine\\YachtRouterRepository4G\\YachtRouterPrevious");
							string[] array = files2;
							foreach (string path in array)
							{
								try
								{
									File.Delete(path);
								}
								catch
								{
									this.ShowStatus("Exception in upgrade Cleaning Up old files", true);
								}
							}
						}
						else
						{
							Directory.CreateDirectory("C:\\Locomarine\\YachtRouterRepository4G\\YachtRouterPrevious");
						}
						string[] files3 = Directory.GetFiles("C:\\Locomarine\\YachtRouter4G");
						string[] array2 = files3;
						foreach (string text in array2)
						{
							try
							{
								string destFileName = "C:\\Locomarine\\YachtRouterRepository4G\\YachtRouterPrevious" + text.Substring(text.LastIndexOf('\\'));
								File.Copy(text, destFileName, true);
							}
							catch
							{
								this.ShowStatus("Exception backing up current version", true);
							}
						}
						string[] array3 = files;
						foreach (string text2 in array3)
						{
							try
							{
								string destFileName2 = "C:\\Locomarine\\YachtRouter4G" + text2.Substring(text2.LastIndexOf('\\'));
								File.Copy(text2, destFileName2, true);
							}
							catch
							{
								this.ShowStatus("Exception upgrading to new version", true);
							}
						}
						if (DeleteFutureFiles)
						{
							string[] array4 = files;
							foreach (string path2 in array4)
							{
								File.Delete(path2);
							}
						}
						this.ShowStatus("Upgrade Complete", true);
						return true;
					}
				}
			}
			catch
			{
				this.ShowStatus("Exception during upgrade", true);
			}
			return false;
		}

		public bool RestoreToFactoryDefaultsVersion()
		{
			this.PrepareFutureVersionFromGivenVersion("C:\\Locomarine\\YachtRouterRepository4G\\YachtRouterFactoryDefaults");
			this.SoftReset();
			return true;
		}

		public bool RestoreToPreviousVersion()
		{
			this.PrepareFutureVersionFromGivenVersion("C:\\Locomarine\\YachtRouterRepository4G\\YachtRouterPrevious");
			this.SoftReset();
			return true;
		}

		public Process ExecuteYachtRouter()
		{
			try
			{
				if (File.Exists("C:\\Locomarine\\YachtRouter4G\\YachtRouter.exe"))
				{
					return Process.Start("C:\\Locomarine\\YachtRouter4G\\YachtRouter.exe", "/StartEmbedded");
				}
			}
			catch
			{
			}
			return null;
		}

		public bool CheckIsWebUpdateAvailable()
		{
			string updateListFile = this.GetUpdateListFile();
			StringReader stringReader = new StringReader(updateListFile);
			string text = stringReader.ReadLine();
			text = text.Substring(text.IndexOf(':') + 1).Trim();
			string text2 = stringReader.ReadLine();
			int totalNumberOfFiles = Convert.ToInt32(text2.Substring(text2.IndexOf(':') + 1)) + 1;
			string text3 = Assembly.GetExecutingAssembly().GetName().Version.ToString();
			this.ShowStatus("Current Version : " + text3, true);
			this.ShowStatus("Downloadable version : " + text, true);
			if (text != text3)
			{
				try
				{
					int num = 1;
					string text4 = "http://www.yachtrouter.com/updates/4g/updatelistce.txt";
					long totalSizeOfFile = 0L;
					while (true)
					{
						string outputFileName = "C:\\Locomarine\\YachtRouterRepository4G\\YachtRouterFuture" + '\\' + text4.Substring(text4.LastIndexOf('/') + 1);
						this.DownloadFileToFutureStorage(outputFileName, text4, totalSizeOfFile, num, totalNumberOfFiles);
						num++;
						string text5 = stringReader.ReadLine();
						if (text5 != null)
						{
							string[] array = text5.Split(',');
							text4 = array[0];
							totalSizeOfFile = Convert.ToInt64(array[1]);
							continue;
						}
						break;
					}
					this.ShowStatus("Download complete - Rebooting", true);
					Thread.Sleep(3000);
					this.SoftReset();
					return true;
				}
				catch
				{
					this.ShowStatus("Error during download aborting upgrade", true);
					this.CleanFutureVersion();
				}
			}
			else
			{
				this.ShowStatus("Yacht Router is up to date", true);
			}
			return false;
		}

		private bool CheckFutureVersionForConsistency(string FutureVersionFolder)
		{
			try
			{
				using (TextReader textReader = File.OpenText(FutureVersionFolder + "\\updatelistce.txt"))
				{
					string text = textReader.ReadLine();
					if (text.IndexOf("NOCHECK") != -1)
					{
						return true;
					}
					text = text.Substring(text.IndexOf(':') + 1).Trim();
					string text2 = textReader.ReadLine();
					int num = Convert.ToInt32(text2.Substring(text2.IndexOf(':') + 1));
					this.ShowStatus("Checking Upgrade files for consistency", true);
					string text3 = "http://www.yachtrouter.com/updates/4g/updatelistce.txt";
					long num2 = 0L;
					while (true)
					{
						string text4 = textReader.ReadLine();
						if (text4 != null)
						{
							string[] array = text4.Split(',');
							text3 = array[0];
							num2 = Convert.ToInt64(array[1]);
							string fileName = FutureVersionFolder + '\\' + text3.Substring(text3.LastIndexOf('/') + 1);
							FileInfo fileInfo = new FileInfo(fileName);
							if (fileInfo.Length == num2)
							{
								continue;
							}
							throw new Exception("Inconsistent upgrade file size Aborting");
						}
						break;
					}
					this.ShowStatus("Consistency Check Complete", true);
					return true;
				}
			}
			catch
			{
				this.ShowStatus("Inconsistent upgrade file size Aborting", true);
				this.CleanFutureVersion();
			}
			return false;
		}

		private bool PrepareFutureVersionFromGivenVersion(string UpgradeVersion)
		{
			try
			{
				if (Directory.Exists(UpgradeVersion))
				{
					string[] files = Directory.GetFiles(UpgradeVersion);
					if (files.Count() > 0)
					{
						string[] array = files;
						foreach (string text in array)
						{
							string destFileName = "C:\\Locomarine\\YachtRouterRepository4G\\YachtRouterFuture" + text.Substring(text.LastIndexOf('\\'));
							File.Copy(text, destFileName, true);
						}
						this.ShowStatus("Upgrade Complete", true);
						return true;
					}
				}
			}
			catch
			{
				this.ShowStatus("Exception during upgrade", true);
				this.CleanFutureVersion();
			}
			return false;
		}

		private bool CleanFutureVersion()
		{
			try
			{
				this.ShowStatus("Removing upgrade version files", true);
				if (Directory.Exists("C:\\Locomarine\\YachtRouterRepository4G\\YachtRouterFuture"))
				{
					string[] files = Directory.GetFiles("C:\\Locomarine\\YachtRouterRepository4G\\YachtRouterFuture");
					if (files.Count() > 0)
					{
						string[] array = files;
						foreach (string path in array)
						{
							try
							{
								File.Delete(path);
							}
							catch
							{
								this.ShowStatus("Exception during upgrade", true);
							}
						}
						return true;
					}
				}
			}
			catch
			{
				this.ShowStatus("Exception during upgrade", true);
			}
			return false;
		}

		private string GetUpdateListFile()
		{
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create("http://www.yachtrouter.com/updates/4g/updatelistce.txt");
			WebResponse response = httpWebRequest.GetResponse();
			Stream responseStream = response.GetResponseStream();
			StreamReader streamReader = new StreamReader(responseStream);
			string result = streamReader.ReadToEnd();
			streamReader.Close();
			responseStream.Close();
			response.Close();
			return result;
		}

		private bool DownloadFileToFutureStorage(string outputFileName, string fileURL, long TotalSizeOfFile, int CurrentFileNumber, int TotalNumberOfFiles)
		{
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(fileURL);
			WebResponse response = httpWebRequest.GetResponse();
			Stream responseStream = response.GetResponseStream();
			long num = 0L;
			byte[] buffer = new byte[4096];
			int num2 = 0;
			using (FileStream fileStream = new FileStream(outputFileName, FileMode.Create))
			{
				for (int num3 = responseStream.Read(buffer, 0, 4096); num3 > 0; num3 = responseStream.Read(buffer, 0, 4096))
				{
					num += num3;
					this.ShowStatus("Downloading " + CurrentFileNumber + "/" + TotalNumberOfFiles + " : " + num / 1024 + " / " + TotalSizeOfFile / 1024 + " kB", false);
					fileStream.Write(buffer, 0, num3);
				}
				fileStream.Close();
			}
			responseStream.Close();
			response.Close();
			return true;
		}

		private string RetrieveDrive(string Target, bool CheckForFile)
		{
			string[] logicalDrives = Directory.GetLogicalDrives();
			string[] array = logicalDrives;
			foreach (string text in array)
			{
				if (CheckForFile)
				{
					if (File.Exists(text + Target))
					{
						return text;
					}
				}
				else if (Directory.Exists(text + Target))
				{
					return text;
				}
			}
			return string.Empty;
		}

		public void SoftReset()
		{
			ProcessStartInfo processStartInfo = new ProcessStartInfo("shutdown.exe");
			processStartInfo.Arguments = "-r -f -t 0";
			Process.Start(processStartInfo);
		}
	}
}
