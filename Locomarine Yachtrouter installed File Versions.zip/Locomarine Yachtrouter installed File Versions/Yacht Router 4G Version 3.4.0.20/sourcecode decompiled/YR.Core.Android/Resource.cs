using Android.Runtime;
using System.CodeDom.Compiler;

namespace YR.Core.Android
{
	[GeneratedCode("Xamarin.Android.Build.Tasks", "1.0.0.0")]
	public class Resource
	{
		public class Attribute
		{
			static Attribute()
			{
				ResourceIdManager.UpdateIdValues();
			}

			private Attribute()
			{
			}
		}

		public class String
		{
			public static int library_name;

			static String()
			{
				String.library_name = 2130837504;
				ResourceIdManager.UpdateIdValues();
			}

			private String()
			{
			}
		}

		static Resource()
		{
			ResourceIdManager.UpdateIdValues();
		}
	}
}
